# 22

## Compte local propre à chaque personne

Au premier lancement sur un nouvel ordinateur, l'interface demande la clé
d'activation, un nom d'utilisateur et un mot de passe. Les lancements suivants
demandent uniquement le nom d'utilisateur et le mot de passe.

Le compte, les paramètres et l'historique sont enregistrés dans le profil
Windows de chaque personne (`%LOCALAPPDATA%\SC4R`) et non dans ce dossier.
Le projet peut donc être partagé sans transmettre le compte du propriétaire.

## Installation

### 1. Clone / télécharge le projet

### 2. Crée un environnement virtuel
```bash
python -m venv venv
```

### 3. Active l'environnement virtuel

**Windows :**
```bash
venv\Scripts\activate
```

**Mac / Linux :**
```bash
source venv/bin/activate
```

### 4. Installe les modules
```bash
pip install -r requirements.txt
```

## Lancer le projet

```bash
python main.py
```
## Interface moderne PySide6

1. Lance `install_modules.bat` une première fois.
2. Lance ensuite `LuncherInterfaceSansCmd.bat`.
3. Le fichier principal de la nouvelle interface est `Interface_modern.py`.

L'interface reste entièrement écrite en Python. PySide6 fournit uniquement les composants graphiques modernes.

## Interface web locale

Lance `LancerInterfaceWeb.bat`. Python choisit automatiquement un port local
disponible et ouvre le navigateur à la bonne adresse. Cette version HTML affiche les outils du projet, lance
les scripts Python autorisés, transmet les saisies interactives, affiche les
résultats et conserve les paramètres dans le dossier local.

Les paramètres sont enregistrés dans `data/settings.json`. L'historique des
100 dernières exécutions est conservé dans `data/history.json`. Jusqu'à trois
outils peuvent fonctionner simultanément ; la console permet de passer de l'un
à l'autre sans arrêter les autres processus.

Lancement manuel :

```bash
pip install "Flask>=3.1,<4"
python web_app.py
```

## Comptes et licences

1. L'utilisateur ouvre l'interface et copie l'identifiant machine affiché.
2. Le propriétaire lance `GenerateurCle.py`, saisit cet identifiant et un nom,
   puis transmet la clé générée.
3. Lors de la première activation seulement, l'utilisateur saisit la clé et
   choisit un nom d'utilisateur et un mot de passe d'au moins 8 caractères.
4. Aux lancements suivants, le nom d'utilisateur et le mot de passe sont
   demandés. Le mot de passe est stocké sous forme de hash scrypt salé.
5. Le générateur permet de bloquer ou réactiver le compte. Le statut est vérifié
   par l'interface et par les scripts distribués.

Les fiches apparaissent dans Firebase sous `/users`, avec le pseudo donné lors
de la génération, le nom choisi à l'activation, le statut et la dernière
connexion. Ne publiez jamais le générateur propriétaire avec la version client.
