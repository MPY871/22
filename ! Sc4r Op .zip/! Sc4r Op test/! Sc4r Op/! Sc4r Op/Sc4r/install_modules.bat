@echo off
setlocal
title Installation des modules Python

rem Toujours travailler depuis le dossier contenant ce script.
cd /d "%~dp0"

echo ========================================
echo   Installation des modules du projet
echo ========================================
echo.

rem Chercher Python 3.12 en priorite, puis une installation Python standard.
set "PYTHON_CMD="
py -3.12 --version >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py -3.12"

if not defined PYTHON_CMD (
    python --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo ERREUR : Python est introuvable.
    echo Installez Python 3.12 depuis https://www.python.org/downloads/
    echo Pendant l'installation, cochez "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

if not exist "modules.txt" (
    echo ERREUR : le fichier modules.txt est introuvable.
    echo Placez modules.txt dans le meme dossier que ce fichier BAT.
    echo.
    pause
    exit /b 1
)

echo Python detecte :
%PYTHON_CMD% --version
echo.

echo Mise a jour de pip...
%PYTHON_CMD% -m pip install --upgrade pip
if errorlevel 1 (
    echo.
    echo ERREUR : impossible de mettre pip a jour.
    echo Verifiez votre connexion Internet et les droits de votre antivirus.
    pause
    exit /b 1
)

echo.
echo Installation des modules de modules.txt...
%PYTHON_CMD% -m pip install -r "modules.txt"
if errorlevel 1 (
    echo.
    echo ERREUR : au moins un module n'a pas pu etre installe.
    echo Lisez le message d'erreur affiche juste au-dessus.
    pause
    exit /b 1
)

echo.
echo ========================================
echo   Installation terminee avec succes !
echo ========================================
echo.
pause
exit /b 0
