"""Activation et connexion locale synchronisées avec Firebase Realtime Database."""
import hashlib
import json
import os
import platform
import secrets
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

FIREBASE_URL = "https://py-945d1-default-rtdb.europe-west1.firebasedatabase.app"
SECRET = "S." + "12" + "Zàp" + "13975"
ROOT = Path(__file__).resolve().parent


def local_data_directory():
    """Dossier privé de l'utilisateur, jamais inclus avec le projet partagé."""
    windows_data = os.environ.get("LOCALAPPDATA")
    base = Path(windows_data) if windows_data else Path.home() / ".local" / "share"
    return base / "SC4R"


ACCOUNT_FILE = local_data_directory() / "account.json"
_cache = {"at": 0.0, "record": None, "online": False}


def fingerprint():
    data = str(uuid.getnode()) + platform.system() + platform.processor() + platform.version()
    return hashlib.sha256(data.encode()).hexdigest()


def expected_key():
    return hashlib.sha256((fingerprint() + SECRET).encode()).hexdigest()


def user_id():
    return fingerprint()[:16]


def firebase_request(path, method="GET", data=None):
    body = None if data is None else json.dumps(data, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(f"{FIREBASE_URL}/{path}.json", data=body, method=method,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=6) as response:
        raw = response.read().decode("utf-8")
        return json.loads(raw) if raw else None


def get_record(force=False):
    if not force and time.time() - _cache["at"] < 12:
        return _cache["record"]
    try:
        record = firebase_request(f"users/{user_id()}")
        online = True
    except Exception:
        record = None
        online = False
    _cache.update(at=time.time(), record=record, online=online)
    return record


def hash_password(password, salt=None):
    salt_bytes = bytes.fromhex(salt) if salt else secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt_bytes, n=2**14, r=8, p=1)
    return salt_bytes.hex(), digest.hex()


def save_local_account(username, salt, password_hash, status="active", pending_sync=False):
    ACCOUNT_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = ACCOUNT_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps({"username": username, "user_id": user_id(), "password_salt": salt,
        "password_hash": password_hash, "status": status, "pending_sync": pending_sync,
        "activated_at": int(time.time())}, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(ACCOUNT_FILE)


def load_local_account():
    try:
        return json.loads(ACCOUNT_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None


def activate(license_key, username, password):
    if not secrets.compare_digest(license_key.strip(), expected_key()):
        return False, "Clé d'activation incorrecte."
    username = username.strip()
    if len(username) < 3 or len(password) < 8:
        return False, "Utilise un nom d'au moins 3 caractères et un mot de passe d'au moins 8 caractères."
    record = get_record(force=True)
    # Une clé valide prouve que le générateur a reçu cet identifiant machine.
    # Si sa synchronisation Firebase a échoué, l'activation crée la fiche ici.
    if not isinstance(record, dict):
        record = {
            "full_id": fingerprint(),
            "pseudo": username,
            "created_at": int(time.time()),
            "status": "active",
            "activated": False,
        }
    elif record.get("full_id") != fingerprint():
        return False, "La fiche Firebase appartient à une autre machine."
    if record.get("status") == "blocked":
        return False, "Ce compte est bloqué."
    salt, password_hash = hash_password(password)
    update = {**record, "username": username, "password_salt": salt, "password_hash": password_hash,
        "activated": True, "status": "active", "last_login": int(time.time())}
    synced = True
    try:
        firebase_request(f"users/{user_id()}", "PUT", update)
    except Exception:
        synced = False
    # La clé n'est demandée qu'ici. Les identifiants locaux permettent les
    # connexions suivantes pendant que la synchronisation Firebase réessaie.
    save_local_account(username, salt, password_hash, pending_sync=not synced)
    _cache.update(at=0.0, record=None)
    return True, "Compte activé." if synced else "Compte activé localement ; Firebase sera resynchronisé automatiquement."


def login(username, password):
    local = load_local_account()
    if not local or local.get("user_id") != user_id():
        return False, "Cette installation n'est pas encore activée."
    record = get_record(force=True)
    online = _cache.get("online", False)
    if online and isinstance(record, dict) and record.get("status") == "blocked":
        local["status"] = "blocked"
        ACCOUNT_FILE.write_text(json.dumps(local, ensure_ascii=False, indent=2), encoding="utf-8")
        return False, "Ce compte est bloqué par le propriétaire."
    source = record if online and isinstance(record, dict) and record.get("full_id") == fingerprint() else local
    if online and isinstance(record, dict) and record.get("status") == "active":
        local["status"] = "active"
        ACCOUNT_FILE.write_text(json.dumps(local, ensure_ascii=False, indent=2), encoding="utf-8")
    if username.strip() != source.get("username"):
        return False, "Identifiants incorrects."
    try:
        _, candidate = hash_password(password, source.get("password_salt"))
    except Exception:
        return False, "Compte incomplet : une nouvelle activation est nécessaire."
    if not secrets.compare_digest(candidate, source.get("password_hash", "")):
        return False, "Identifiants incorrects."
    if local.get("status") == "blocked":
        return False, "Ce compte est bloqué par le propriétaire."
    if not online or not isinstance(record, dict):
        update = {"full_id": fingerprint(), "pseudo": username.strip(), "username": username.strip(),
            "password_salt": local["password_salt"], "password_hash": local["password_hash"],
            "activated": True, "status": "active", "last_login": int(time.time())}
        try:
            firebase_request(f"users/{user_id()}", "PUT", update)
            local["pending_sync"] = False
            ACCOUNT_FILE.write_text(json.dumps(local, ensure_ascii=False, indent=2), encoding="utf-8")
            _cache.update(at=0.0, record=None, online=False)
        except Exception:
            pass
    try:
        firebase_request(f"users/{user_id()}/last_login", "PUT", int(time.time()))
    except Exception:
        pass
    return True, "Connexion réussie."


def access_allowed():
    record = get_record()
    if _cache.get("online", False):
        if isinstance(record, dict) and record.get("status") == "blocked":
            local = load_local_account() or {}
            local["status"] = "blocked"
            ACCOUNT_FILE.write_text(json.dumps(local, ensure_ascii=False, indent=2), encoding="utf-8")
            return False
        return isinstance(record, dict) and record.get("status") == "active" and record.get("full_id") == fingerprint()
    local = load_local_account()
    return isinstance(local, dict) and local.get("user_id") == user_id() and local.get("status") == "active"
