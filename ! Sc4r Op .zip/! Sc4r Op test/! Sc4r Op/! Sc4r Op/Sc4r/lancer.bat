@echo off
cd /d "%~dp0"
"C:\Users\Mecdu\AppData\Local\Programs\Python\Python312\python.exe" "22.py"
pause