import tkinter as tk
import subprocess
import sys
import os
import threading
import queue
import hashlib
import uuid
import platform
import random
import urllib.request
import json
import colorsys
import math

FIREBASE_URL = "https://py-945d1-default-rtdb.europe-west1.firebasedatabase.app"

def fetch_user_count():
    try:
        with urllib.request.urlopen(f"{FIREBASE_URL}/user_count.json", timeout=3) as r:
            data = json.loads(r.read().decode())
            return int(data) if data else 0
    except Exception:
        return 0

BG_MAIN     = "#0e0b14"
BG_PANEL    = "#120f1a"
BG_CARD     = "#161220"
BG_HOVER    = "#1e1830"
ACCENT      = "#a855f7"
ACCENT_DIM  = "#7c3aed"
ACCENT_DARK = "#2e1065"
RED         = "#f43f5e"
ORANGE      = "#c084fc"
TEXT_MAIN   = "#e2d9f3"
TEXT_DIM    = "#6b5e8a"
BORDER      = "#2d2244"
LOGO_COLOR  = ACCENT
OPTION_TEXT = TEXT_MAIN

THEMES = {
    "Violet": {"BG_MAIN":"#0e0b14", "BG_PANEL":"#120f1a", "BG_CARD":"#161220", "BG_HOVER":"#1e1830", "ACCENT":"#a855f7", "ACCENT_DIM":"#7c3aed", "ACCENT_DARK":"#2e1065", "ORANGE":"#c084fc", "TEXT_MAIN":"#e2d9f3", "TEXT_DIM":"#6b5e8a", "BORDER":"#2d2244"},
    "Bleu":   {"BG_MAIN":"#07111f", "BG_PANEL":"#0b1728", "BG_CARD":"#0e1d31", "BG_HOVER":"#132944", "ACCENT":"#38bdf8", "ACCENT_DIM":"#0284c7", "ACCENT_DARK":"#0c4a6e", "ORANGE":"#7dd3fc", "TEXT_MAIN":"#e0f2fe", "TEXT_DIM":"#62809b", "BORDER":"#183a59"},
    "Vert":   {"BG_MAIN":"#07140f", "BG_PANEL":"#0b1b14", "BG_CARD":"#0e231a", "BG_HOVER":"#153326", "ACCENT":"#4ade80", "ACCENT_DIM":"#16a34a", "ACCENT_DARK":"#14532d", "ORANGE":"#86efac", "TEXT_MAIN":"#dcfce7", "TEXT_DIM":"#628773", "BORDER":"#1d4932"},
    "Rouge":  {"BG_MAIN":"#16090c", "BG_PANEL":"#200d12", "BG_CARD":"#291117", "BG_HOVER":"#3a1820", "ACCENT":"#fb7185", "ACCENT_DIM":"#e11d48", "ACCENT_DARK":"#881337", "ORANGE":"#fda4af", "TEXT_MAIN":"#ffe4e6", "TEXT_DIM":"#95616a", "BORDER":"#55202d"},
    "Orange": {"BG_MAIN":"#171006", "BG_PANEL":"#211609", "BG_CARD":"#2a1c0c", "BG_HOVER":"#3b2811", "ACCENT":"#fb923c", "ACCENT_DIM":"#ea580c", "ACCENT_DARK":"#7c2d12", "ORANGE":"#fdba74", "TEXT_MAIN":"#ffedd5", "TEXT_DIM":"#967454", "BORDER":"#583516"},
    "Rose":   {"BG_MAIN":"#160914", "BG_PANEL":"#200d1d", "BG_CARD":"#291126", "BG_HOVER":"#3a1836", "ACCENT":"#f472d0", "ACCENT_DIM":"#db2777", "ACCENT_DARK":"#831843", "ORANGE":"#f9a8d4", "TEXT_MAIN":"#fce7f3", "TEXT_DIM":"#946484", "BORDER":"#54204a"},
}

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
PYTHON   = sys.executable
SETTINGS_FILE = os.path.join(TOOL_DIR, ".interface_settings.json")

def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def save_settings(data):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def custom_theme(hex_color, second_color=None, strength=100, background_color="#0b0d12"):
    second_color = second_color or hex_color
    amount = max(0, min(100, int(strength))) / 100
    def rgb(value):
        value = value.lstrip("#")
        return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))
    def mix(first, second, ratio):
        a, b = rgb(first), rgb(second)
        values = tuple(round(x + (y-x)*ratio) for x, y in zip(a, b))
        return "#%02x%02x%02x" % values
    def shade(value, brightness, saturation=.85):
        r, g, b = (part / 255 for part in rgb(value))
        h, s, _ = colorsys.rgb_to_hsv(r, g, b)
        rr, gg, bb = colorsys.hsv_to_rgb(h, min(s*saturation, 1), brightness)
        return f"#{int(rr*255):02x}{int(gg*255):02x}{int(bb*255):02x}"
    blend25 = mix(hex_color, second_color, .25 * amount)
    blend50 = mix(hex_color, second_color, .50 * amount)
    blend75 = mix(hex_color, second_color, .75 * amount)
    panel = mix(background_color, "#ffffff", .06)
    card = mix(background_color, "#ffffff", .11)
    hover = mix(background_color, "#ffffff", .17)
    br, bg, bb = rgb(background_color)
    luminance = (0.2126*br + 0.7152*bg + 0.0722*bb) / 255
    text_main = "#111318" if luminance > .48 else "#f2f3f5"
    text_dim = "#343841" if luminance > .48 else "#b5bac1"
    border = mix(background_color, "#ffffff" if luminance < .48 else "#000000", .22)
    return {
        "BG_MAIN": background_color, "BG_PANEL": panel,
        "BG_CARD": card, "BG_HOVER": hover,
        "ACCENT": hex_color, "ACCENT_DIM": blend25,
        "ACCENT_DARK": shade(blend50, .34, .92), "ORANGE": second_color,
        "TEXT_MAIN": text_main, "TEXT_DIM": text_dim,
        "BORDER": border,
    }

def set_global_theme(theme_name, custom_color=None, second_color=None, strength=100, background_color=None):
    global BG_MAIN, BG_PANEL, BG_CARD, BG_HOVER, ACCENT
    global ACCENT_DIM, ACCENT_DARK, ORANGE, TEXT_MAIN, TEXT_DIM, BORDER
    palette = custom_theme(custom_color, second_color, strength, background_color or "#0b0d12") if theme_name == "Personnalise" and custom_color else THEMES.get(theme_name, THEMES["Violet"])
    for key, value in palette.items():
        globals()[key] = value

LOGO = r""" _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
                           ! Sc4r   """


def _fingerprint():
    data = (
        str(uuid.getnode()) +
        platform.system() +
        platform.processor() +
        platform.version()
    )
    return hashlib.sha256(data.encode()).hexdigest()

def _build_secret():
    return "S." + "12" + "Z\u00e0p" + "13975"

def check_license(user_key):
    expected = hashlib.sha256((_fingerprint() + _build_secret()).encode()).hexdigest()
    return user_key == expected

LICENCE_FILE  = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".licence_cache")

def save_licence(key):
    try:
        with open(LICENCE_FILE, "w") as f:
            f.write(key)
    except Exception:
        pass

def load_licence():
    try:
        if os.path.exists(LICENCE_FILE):
            with open(LICENCE_FILE, "r") as f:
                return f.read().strip()
    except Exception:
        pass
    return None

def show_license_screen():
    cached = load_licence()
    if cached and check_license(cached):
        return

    win = tk.Tk()
    win.title("22BySc4r — Licence")
    win.configure(bg=BG_MAIN)
    win.geometry("600x380")
    win.resizable(False, False)
    win.update_idletasks()
    x = (win.winfo_screenwidth()  - 600) // 2
    y = (win.winfo_screenheight() - 380) // 2
    win.geometry(f"600x380+{x}+{y}")

    tk.Label(win, text=LOGO, font=("Courier New", 8),
             fg=ACCENT, bg=BG_MAIN, justify="left").pack(pady=(18, 4))

    fid = tk.Frame(win, bg=BG_PANEL,
                   highlightthickness=1, highlightbackground=BORDER)
    fid.pack(fill="x", padx=24, pady=(6, 2))
    tk.Label(fid, text="VOTRE ID MACHINE :", font=("Courier New", 7),
             fg=TEXT_DIM, bg=BG_PANEL).pack(anchor="w", padx=10, pady=(6, 0))
    tk.Label(fid, text=_fingerprint(), font=("Courier New", 8, "bold"),
             fg=ORANGE, bg=BG_PANEL, wraplength=540).pack(anchor="w", padx=10, pady=(0, 4))
    tk.Label(fid, text="Envoie cet ID a sc4r pour obtenir ta licence.",
             font=("Courier New", 7), fg=TEXT_DIM, bg=BG_PANEL).pack(anchor="w", padx=10, pady=(0, 6))

    msg_var = tk.StringVar()
    tk.Label(win, textvariable=msg_var, font=("Courier New", 8),
             fg=RED, bg=BG_MAIN).pack(pady=(4, 0))

    finput = tk.Frame(win, bg=BG_PANEL,
                      highlightthickness=1, highlightbackground=BORDER)
    finput.pack(fill="x", padx=24, pady=6)
    tk.Label(finput, text=" > C'est quoi le mot de passe ? : ",
             font=("Courier New", 9, "bold"),
             fg=ACCENT, bg=BG_PANEL).pack(side="left", padx=(6, 0), pady=8)
    pwd_var = tk.StringVar()
    entry = tk.Entry(finput, textvariable=pwd_var, show="*",
                     bg=BG_PANEL, fg=ACCENT,
                     font=("Courier New", 9),
                     relief="flat", bd=0,
                     insertbackground=ACCENT)
    entry.pack(side="left", fill="x", expand=True, padx=6, pady=8)
    entry.focus_set()

    result = {"ok": False}

    def try_license(e=None):
        key = pwd_var.get().strip()
        if check_license(key):
            save_licence(key)
            result["ok"] = True
            win.destroy()
        else:
            msg_var.set("[ Tu Veux Me Bz????? — Mauvais mot de passe ]")
            pwd_var.set("")
            entry.focus_set()

    entry.bind("<Return>", try_license)
    btn = tk.Label(win, text="[ VALIDER ]",
                   font=("Courier New", 9, "bold"),
                   fg=ACCENT_DIM, bg=BG_MAIN, cursor="hand2")
    btn.pack(pady=4)
    btn.bind("<Button-1>", try_license)
    win.protocol("WM_DELETE_WINDOW", lambda: sys.exit())
    win.mainloop()
    if not result["ok"]:
        sys.exit()



def make_runner(module_path):
    return f"""
import sys, os, types

# Patch pour eviter l'import circulaire de core.py
fake_prog = types.ModuleType('Programme')
for _name in ['spoofer','iptool','grabber','basecode','scannerport','obfuscator','trackername','EmailInfo','doxcreater']:
    setattr(fake_prog, _name, types.ModuleType(_name))
    sys.modules['Programme.' + _name] = types.ModuleType('Programme.' + _name)
sys.modules['Programme'] = fake_prog

sys.path.insert(0, r'{TOOL_DIR}')
sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)
sys.stderr.reconfigure(encoding='utf-8', line_buffering=True)
sys.stdin.reconfigure(encoding='utf-8')
os.chdir(r'{TOOL_DIR}')

import importlib.util
spec = importlib.util.spec_from_file_location("mod", r'{module_path}')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
if hasattr(mod, 'main'):
    mod.main()
"""

TOOL_MENU_LOGO = r"""
 _________    ___      ___   _____
|  _   _  | .'   `.  .'   `.|_   _|
|_/ | | \_|/  .-.  \/  .-.  \ | |
    | |    | |   | || |   | | | |   _
   _| |_   \  `-'  /\  `-'  /_| |__/ |
  |_____|   `.___.'  `.___.'|________|
  _   ____     ____   _  _     ____
 | | / ___|   / ___| | || |   |  _ \
 | | \___ \  | |     | || |_  | |_) |
 |_|  ___) | | |___  |__   _| |  _ <
 (_) |____/   \____|    |_|   |_| \_\
"""


def make_choice_runner(code, title, action_label):
    """Affiche le meme menu de choix avant chaque fonctionnalite."""
    return f"""
print({TOOL_MENU_LOGO!r})
print("=" * 54)
print("  " + {title!r})
print("-" * 54)
print("[1] " + {action_label!r})
print("[2] Revenir au menu principal")
print("=" * 54)

while True:
    choix = input().strip()
    if choix == "1":
        print()
        exec({code!r}, {{"__name__": "__main__"}})
        break
    if choix == "2":
        print("Retour au menu principal.")
        break
    print("Choix invalide. Tape 1 ou 2.")
"""

PHONE_LOOKUP_RUNNER = """
import phonenumbers
from phonenumbers import carrier, geocoder, timezone

phone_number = input("[+] Numero de telephone (ex: +33658182243) : ").strip()

try:
    parsed_number = phonenumbers.parse(phone_number, None)
    if not phonenumbers.is_valid_number(parsed_number):
        print("Numero invalide.")
    else:
        country_code = f"+{parsed_number.country_code}" if parsed_number.country_code else "None"
        operator = carrier.name_for_number(parsed_number, "fr") or "None"
        number_type = phonenumbers.number_type(parsed_number)
        if number_type == phonenumbers.PhoneNumberType.MOBILE:
            type_number = "Mobile"
        elif number_type in (
            phonenumbers.PhoneNumberType.FIXED_LINE,
            phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE,
        ):
            type_number = "Fixe"
        else:
            type_number = "Autre"
        timezones = timezone.time_zones_for_number(parsed_number)
        timezone_info = ", ".join(timezones) if timezones else "None"
        country = phonenumbers.region_code_for_number(parsed_number) or "None"
        region = geocoder.description_for_number(parsed_number, "fr") or "None"
        formatted_number = phonenumbers.format_number(
            parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL
        )

        print(f"\\n[+] Statut       : Valide")
        print(f"[+] Numero       : {formatted_number}")
        print(f"[+] Indicatif    : {country_code}")
        print(f"[+] Pays         : {country}")
        print(f"[+] Region       : {region}")
        print(f"[+] Fuseau       : {timezone_info}")
        print(f"[+] Operateur    : {operator}")
        print(f"[+] Type         : {type_number}")
except phonenumbers.NumberParseException as error:
    print(f"Format invalide : {error}")
"""

GENERATEUR_RUNNER = f"""
import sys, os, random
sys.path.insert(0, r'{TOOL_DIR}')
sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)
sys.stderr.reconfigure(encoding='utf-8', line_buffering=True)
sys.stdin.reconfigure(encoding='utf-8')
os.chdir(r'{TOOL_DIR}')

operators_data = {{
    "Orange": ["0600","0601","0602","0603","0620","0621","0622","0623","0700","0701","0702","0703"],
    "SFR": ["0610","0611","0612","0613","0630","0631","0632","0633","0710","0711","0712","0713"],
    "Bouygues Telecom": ["0650","0651","0652","0653","0654","0655","0656","0657","0658","0659","0750","0751","0752","0753"],
    "Free Mobile": ["0695","0696","0697","0698","0699","0755","0756","0757","0758","0780","0781","0782","0783"],
    "La Poste Mobile": ["0630","0631","0632"],
    "NRJ Mobile": ["0670","0671","0672"],
    "Prixtel": ["0688","0689"],
    "Coriolis": ["0760","0761","0762"],
}}
operators = sorted(operators_data.keys())

def generate_number(operator=None):
    chosen = operator if operator in operators_data else random.choice(list(operators_data.keys()))
    prefix = random.choice(operators_data[chosen])
    remaining = "".join(str(random.randint(0,9)) for _ in range(6))
    return prefix + remaining, chosen

while True:
    print("\\n=== GENERATEUR DE NUMEROS ===")
    print("1 - Generer des numeros")
    print("2 - Quitter")
    choix = input().strip()
    if choix == "1":
        while True:
            try:
                count = int(input("Combien de numeros ? ").strip())
                if count > 0: break
                print("Entrez un nombre positif.")
            except ValueError:
                print("Entrez un nombre valide.")
        print("\\nOperateurs disponibles :")
        for i, op in enumerate(operators, 1):
            print(f"{{i}}. {{op}}")
        print(f"{{len(operators)+1}}. MIXTE (tous operateurs)")
        while True:
            try:
                op_choice = int(input(f"Quel operateur ? (1-{{len(operators)+1}}): ").strip())
                if op_choice == len(operators)+1:
                    selected = "mixte"; break
                elif 1 <= op_choice <= len(operators):
                    selected = operators[op_choice-1]; break
                else:
                    print(f"Choisissez entre 1 et {{len(operators)+1}}.")
            except ValueError:
                print("Entrez un nombre valide.")
        results = []
        for _ in range(count):
            op = selected if selected != "mixte" else None
            num, used_op = generate_number(op)
            results.append((num, used_op))
        print("\\nNumeros generes :")
        for i, (num, op) in enumerate(results, 1):
            if selected == "mixte":
                print(f"{{i:3d}}. {{num}} -> {{op}}")
            else:
                print(f"{{i:3d}}. {{num}}")
        save_folder = os.path.join(r'{TOOL_DIR}', "numeros_generes")
        os.makedirs(save_folder, exist_ok=True)
        filename = input("\\nNom du fichier (sans extension) : ").strip() or "numeros_generes"
        full_path = os.path.join(save_folder, filename + ".txt")
        with open(full_path, "w", encoding="utf-8") as f:
            for num, op in results:
                f.write(num + "\\n")
        print(f"Fichier sauvegarde dans : {{full_path}}")
    elif choix == "2":
        break
    else:
        print("Choix invalide.")
"""

NOT_FOUND_RUNNER = """
print("Not found")
"""

MENU_ITEMS = [
    ("01", "GENERATEUR DE NUMEROS", "Génère des numéros mobiles FR",
     ("runner", GENERATEUR_RUNNER)),
    ("02", "LOOKUP NUM",            "Recherche infos sur un numéro",
     ("runner", PHONE_LOOKUP_RUNNER)),
    ("03", "DOX CREATER",           "Crée un dossier d'informations",
     ("file", os.path.join(TOOL_DIR, "Programme", "doxcreater.py"))),
    ("04", "SCAN IP",               "Scanne et analyse une adresse IP",
     ("file", os.path.join(TOOL_DIR, "Programme", "iptool.py"))),
    ("05", "NOT FOUND",             "Fonction indisponible",
     ("runner", NOT_FOUND_RUNNER)),
    ("06", "PORT SCANNER",          "Scanne les ports d'une machine",
     ("file", os.path.join(TOOL_DIR, "Programme", "scannerport.py"))),
    ("07", "OBFUSCATOR",            "Obfusque du code Python",
     ("file", os.path.join(TOOL_DIR, "Programme", "obfuscator.py"))),
    ("08", "TRACKER NAME",          "Recherche un pseudo sur les réseaux",
     ("file", os.path.join(TOOL_DIR, "Programme", "trackername.py"))),
    ("09", "EMAIL INFO",            "Analyse une adresse email",
     ("file", os.path.join(TOOL_DIR, "Programme", "EmailInfo.py"))),
]

ACTION_LABELS = {
    "GENERATEUR DE NUMEROS": "Generer des numeros",
    "LOOKUP NUM": "Rechercher un numero",
    "DOX CREATER": "Creer un dossier d'informations",
    "SCAN IP": "Scanner une adresse IP",
    "NOT FOUND": "Afficher Not found",
    "PORT SCANNER": "Scanner les ports d'une machine",
    "OBFUSCATOR": "Obfusquer un fichier Python",
    "TRACKER NAME": "Rechercher un pseudo",
    "EMAIL INFO": "Analyser une adresse email",
}



class InteractiveTerminal(tk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=BG_PANEL, **kwargs)
        self.proc       = None
        self._out_queue = queue.Queue()
        self._build()
        self._poll_output()

    def _build(self):
        header = tk.Frame(self, bg=BG_PANEL)
        header.pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(header, text="● TERMINAL",
                 font=("Courier New", 8, "bold"),
                 fg=ACCENT, bg=BG_PANEL).pack(side="left")
        self.status_lbl = tk.Label(header, text="IDLE",
                                   font=("Courier New", 8),
                                   fg=TEXT_DIM, bg=BG_PANEL)
        self.status_lbl.pack(side="right")

        self.output = tk.Text(
            self, bg="#0a0812", fg=TEXT_MAIN,
            font=("Courier New", 9),
            relief="flat", bd=0,
            insertbackground=ACCENT,
            selectbackground=ACCENT_DARK,
            wrap="word", state="disabled",
        )
        self.output.pack(fill="both", expand=True, padx=10, pady=(4, 2))
        self.output.tag_configure("green",  foreground=LOGO_COLOR)
        self.output.tag_configure("orange", foreground=ORANGE)
        self.output.tag_configure("red",    foreground=RED)
        self.output.tag_configure("dim",    foreground=TEXT_DIM)
        self.output.tag_configure("white",  foreground=TEXT_MAIN)

        bar = tk.Frame(self, bg="#100d1c",
                       highlightthickness=1, highlightbackground=BORDER)
        bar.pack(fill="x", padx=10, pady=(2, 8))
        tk.Label(bar, text=" > ", font=("Courier New", 11, "bold"),
                 fg=ACCENT, bg="#100d1c").pack(side="left")
        self.input_var = tk.StringVar()
        self.entry = tk.Entry(
            bar, textvariable=self.input_var,
            bg="#100d1c", fg=ACCENT,
            font=("Courier New", 9),
            relief="flat", bd=0,
            insertbackground=ACCENT,
            disabledbackground="#100d1c",
            disabledforeground=TEXT_DIM,
            state="disabled",
        )
        self.entry.pack(side="left", fill="x", expand=True, ipady=5)
        self.entry.bind("<Return>", self._send_input)

    def write(self, msg, tag="green"):
        self.output.configure(state="normal")
        self.output.insert("end", msg, tag)
        self.output.see("end")
        self.output.configure(state="disabled")

    def clear(self):
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.configure(state="disabled")
        # ✅ Garde l'entry active après clear
        if self.proc and self.proc.poll() is None:
            self.entry.configure(state="normal")
            self.entry.focus_set()

    def launch(self, target, title):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            self.proc.wait()
        self.proc = None

        self.clear()
        self.write(f"[ LANCEMENT : {title} ]\n", "orange")
        self.write("─" * 44 + "\n", "dim")

        kind, val = target

        if kind == "file" and not os.path.exists(val):
            self.write(f"[ ERREUR ] Fichier introuvable :\n{val}\n", "red")
            return

        env = os.environ.copy()
        env["PYTHONPATH"]       = TOOL_DIR + os.pathsep + env.get("PYTHONPATH", "")
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"

        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW

        tool_code = val if kind == "runner" else make_runner(val)
        code = make_choice_runner(
            tool_code,
            title,
            ACTION_LABELS.get(title, f"Lancer {title}"),
        )

        self.proc = subprocess.Popen(
            [PYTHON, "-u", "-c", code],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=0,
            cwd=TOOL_DIR,
            env=env,
            **kwargs,
        )

        self.status_lbl.configure(text="● RUNNING", fg=ORANGE)
        self.entry.configure(state="normal")
        self.entry.focus_set()

        threading.Thread(target=self._reader, daemon=True).start()
        threading.Thread(target=self._watcher, daemon=True).start()

    def _reader(self):
        try:
            while True:
                ch = self.proc.stdout.read(1)
                if not ch:
                    break
                self._out_queue.put(ch)
        except Exception:
            pass

    def _poll_output(self):
        buf = []
        try:
            while True:
                buf.append(self._out_queue.get_nowait())
        except queue.Empty:
            pass
        if buf:
            self.write("".join(buf), "white")
        self.after(30, self._poll_output)

    def _watcher(self):
        watched = self.proc
        watched.wait()
        self.after(0, lambda: self._on_end(watched))

    def _on_end(self, watched_proc):
        # N'agit que si c'est encore le même process actif
        if self.proc is watched_proc:
            self.entry.configure(state="disabled")
            self.status_lbl.configure(text="IDLE", fg=TEXT_DIM)

    def _send_input(self, e=None):
        if not self.proc or self.proc.poll() is not None:
            return
        val = self.input_var.get()
        self.input_var.set("")
        self.write(f"{val}\n", "green")
        try:
            self.proc.stdin.write(val + "\n")
            self.proc.stdin.flush()
        except Exception:
            pass

    def kill(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            self.write("\n[ Process stoppe ]\n", "red")



class ToolCard(tk.Canvas):
    def __init__(self, parent, num, title, desc, callback, gradient_getter=None, **kwargs):
        super().__init__(parent, bg=BG_MAIN, height=52, bd=0,
                         highlightthickness=0, cursor="hand2", **kwargs)
        self.num, self.title, self.desc = num, title, desc
        self.callback = callback
        self.gradient_getter = gradient_getter or (lambda: 0)
        self._pressed = False
        self._hovered = False
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_click)

    @staticmethod
    def _mix(first, second, amount):
        a = tuple(int(first[i:i+2], 16) for i in (1, 3, 5))
        b = tuple(int(second[i:i+2], 16) for i in (1, 3, 5))
        rgb = tuple(round(x + (y-x)*amount) for x, y in zip(a, b))
        return "#%02x%02x%02x" % rgb

    def _rounded(self, x1, y1, x2, y2, radius, **kwargs):
        points = [x1+radius,y1, x2-radius,y1, x2,y1, x2,y1+radius,
                  x2,y2-radius, x2,y2, x2-radius,y2, x1+radius,y2,
                  x1,y2, x1,y2-radius, x1,y1+radius, x1,y1]
        return self.create_polygon(points, smooth=True, splinesteps=24, **kwargs)

    def _draw(self):
        self.delete("all")
        width, height = max(self.winfo_width(), 280), 52
        base = ACCENT_DARK if self._pressed else (BG_HOVER if self._hovered else BG_CARD)
        self._rounded(2, 2, width-2, height-2, 20, fill=base,
                      outline=ACCENT if self._pressed else (ACCENT_DIM if self._hovered else BORDER),
                      width=2 if self._pressed else 1)
        strength = max(0, min(100, int(self.gradient_getter()))) / 100
        if strength:
            for x in range(18, width-18, 3):
                amount = (x / width) * strength * .72
                target = self._mix(ACCENT_DARK, ORANGE, x / width)
                self.create_line(x, 4, x, height-4,
                                 fill=self._mix(base, target, amount), width=3)
        self.create_text(28, 26, text=self.num, font=("Courier New", 9, "bold"), fill=ACCENT_DIM)
        self.create_text(62, 18, text=self.title, anchor="w", font=("Courier New", 9, "bold"), fill=OPTION_TEXT)
        self.create_text(62, 36, text=self.desc, anchor="w", font=("Courier New", 7), fill=TEXT_DIM)
        self.create_text(width-22, 26, text="●" if self._pressed else ("▶" if self._hovered else "›"),
                         font=("Courier New", 13, "bold"), fill=ACCENT if self._hovered else ACCENT_DIM)

    def refresh_theme(self):
        self.configure(bg=BG_MAIN)
        self._draw()

    def _on_enter(self, e=None):
        self._hovered = True
        self._draw()

    def _on_leave(self, e=None):
        if self._pressed:
            return
        self._hovered = False
        self._draw()

    def _on_press(self, e=None):
        self._pressed = True
        self._draw()

    def _on_click(self, e=None):
        self._pressed = False
        self._draw()
        self.callback()


class PillButton(tk.Canvas):
    def __init__(self, parent, text, command, width=150, **kwargs):
        super().__init__(parent, width=width, height=30, bg=parent.cget("bg"),
                         bd=0, highlightthickness=0, cursor="hand2", **kwargs)
        self.text, self.command = text, command
        self.hovered = False
        self.bind("<Enter>", lambda e: self._state(True))
        self.bind("<Leave>", lambda e: self._state(False))
        self.bind("<Button-1>", lambda e: self.command())
        self.bind("<Configure>", lambda e: self.refresh_theme())
        self.refresh_theme()

    def _state(self, hovered):
        self.hovered = hovered
        self.refresh_theme()

    def refresh_theme(self):
        self.configure(bg=self.master.cget("bg"))
        self.delete("all")
        width = max(self.winfo_width(), int(self.cget("width")))
        fill = ACCENT_DARK if self.hovered else BG_CARD
        outline = ACCENT if self.hovered else BORDER
        self.create_polygon(15,2, width-15,2, width-2,15, width-15,28,
                            15,28, 2,15, smooth=True, splinesteps=24,
                            fill=fill, outline=outline, width=1)
        self.create_text(width/2, 15, text=self.text,
                         font=("Courier New", 8, "bold"),
                         fill=TEXT_MAIN if self.hovered else ACCENT_DIM)


class ColorSlot(tk.Canvas):
    def __init__(self, parent, text, color, command):
        super().__init__(parent, width=105, height=36, bg=parent.cget("bg"),
                         bd=0, highlightthickness=0, cursor="hand2")
        self.text, self.color, self.selected = text, color, False
        self.bind("<Button-1>", lambda e: command())
        self.bind("<Configure>", lambda e: self.redraw())
        self.redraw()

    def set_color(self, color):
        self.color = color
        self.redraw()

    def set_selected(self, selected):
        self.selected = selected
        self.redraw()

    def redraw(self):
        self.delete("all")
        width = max(self.winfo_width(), 105)
        self.create_text(width/2, 18, text=self.text,
                         font=("Courier New", 8, "bold"),
                         fill=TEXT_MAIN if self.selected else TEXT_DIM)
        self.create_line(18, 32, width-18, 32, fill=self.color,
                         width=4 if self.selected else 2)



class App(tk.Tk):
    def __init__(self):
        self.settings = load_settings()
        self.theme_name = self.settings.get("theme", "Violet")
        set_global_theme(self.theme_name,
                         self.settings.get("custom_color", "#5865f2"),
                         self.settings.get("gradient_color", "#eb459e"),
                         self.settings.get("gradient", 100),
                         self.settings.get("background_color", "#0b0d12"))
        global LOGO_COLOR, OPTION_TEXT
        LOGO_COLOR = self.settings.get("logo_color", ACCENT)
        OPTION_TEXT = self.settings.get("option_text_color", TEXT_MAIN)
        super().__init__()
        self.attributes("-alpha", max(.35, min(1.0, float(self.settings.get("opacity", 100)) / 100)))
        self.current_target = None
        self.current_title = None
        self.digital_buttons = []
        self.title("22 By ! Sc4r — Tool")
        self.configure(bg=BG_MAIN)
        self.geometry("1180x760")
        self.minsize(980, 640)
        self._center()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _center(self):
        self.update_idletasks()
        w, h = 1180, 760
        x = (self.winfo_screenwidth()  - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _build_ui(self):
        top = tk.Frame(self, bg=BG_PANEL, height=58,
                       highlightthickness=0)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(top, text="22 By ! Sc4r", font=("Courier New", 13, "bold"),
                 fg=ACCENT, bg=BG_PANEL).pack(side="left", padx=20, pady=10)
        tk.Label(top, text="● READY", font=("Courier New", 8),
                 fg=ACCENT, bg=BG_PANEL).pack(side="right", padx=16)

        custom_btn = tk.Label(top, text="✦ PERSONNALISATION",
                              font=("Courier New", 8, "bold"),
                              fg=ACCENT_DIM, bg=BG_PANEL, cursor="hand2")
        custom_btn.pack(side="right", padx=12)
        custom_btn.bind("<Button-1>", self._open_personalization)

        self.username_var = tk.StringVar()
        self._refresh_username()
        self.username_label = tk.Label(top, textvariable=self.username_var,
                                       font=("Courier New", 8, "bold"),
                                       fg=ORANGE, bg=BG_PANEL)
        self.username_label.pack(side="right", padx=8)

        # Compteur Firebase
        self.count_var = tk.StringVar(value="👥 ...")
        tk.Label(top, textvariable=self.count_var, font=("Courier New", 8),
                 fg=TEXT_DIM, bg=BG_PANEL).pack(side="right", padx=8)
        threading.Thread(target=self._load_count, daemon=True).start()

        main = tk.Frame(self, bg=BG_MAIN)
        self.main_panel = main
        main.pack(fill="both", expand=True, padx=16, pady=12)

        left = tk.Frame(main, bg=BG_MAIN, width=365)
        self.left_panel = left
        left.pack(side="left", fill="y", padx=(0, 12))
        left.pack_propagate(False)

        lf = tk.Frame(left, bg=BG_MAIN, highlightthickness=0)
        lf.pack(fill="x", pady=(0, 8))
        self.logo_label = tk.Label(lf, text=LOGO, font=("Courier New", 7),
                                   fg=LOGO_COLOR, bg=BG_MAIN,
                                   justify="left", anchor="w")
        self.logo_label.pack(padx=10, pady=6, anchor="w")

        canvas = tk.Canvas(left, bg=BG_MAIN, bd=0, highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        cf = tk.Frame(canvas, bg=BG_MAIN)
        canvas_window = canvas.create_window((0, 0), window=cf, anchor="nw")
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfigure(canvas_window, width=e.width))
        cf.bind("<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        self.tool_cards = []
        for num, title, desc, target in MENU_ITEMS:
            card = ToolCard(cf, num, title, desc,
                            callback=lambda t=target, ti=title: self._launch(t, ti),
                            gradient_getter=lambda: self.settings.get("gradient", 100))
            card.pack(fill="x", pady=2)
            self.tool_cards.append(card)

        right = tk.Frame(main, bg=BG_MAIN)
        right.pack(side="right", fill="both", expand=True)
        self.right_panel = right

        info = tk.Frame(right, bg=BG_PANEL, highlightthickness=0)
        self.info_panel = info
        info.pack(fill="x", pady=(0, 8), ipady=3)
        self.active_label = tk.Label(
            info, text="Selectionne un outil →",
            font=("Courier New", 9), fg=TEXT_DIM, bg=BG_PANEL)
        self.active_label.pack(side="left", padx=10, pady=6)

        clear_btn = PillButton(info, "↻ RESET", self._reset_current_tool, width=100)
        clear_btn.pack(side="right", padx=8, pady=3)
        self.digital_buttons.append(clear_btn)

        self.terminal = InteractiveTerminal(right)
        self.terminal.pack(fill="both", expand=True)

        self.terminal.write(LOGO + "\n\n", "green")
        self.terminal.write("[ 22BySc4r Tool — Interface v2.0 ]\n", "dim")
        self.terminal.write("[ Clique sur un outil pour le lancer ]\n", "dim")
        self.terminal.write("[ Tape tes reponses dans la barre en bas ]\n\n", "dim")
        self._build_personalization_page(main)

    def _launch(self, target, title):
        self.current_target = target
        self.current_title = title
        self.active_label.configure(text=f"ACTIF → {title}", fg=ORANGE)
        self.terminal.launch(target, title)

    def _reset_current_tool(self):
        """Efface la sortie et remet l'outil actif sur son menu initial."""
        if self.current_target is not None and self.current_title is not None:
            self.terminal.launch(self.current_target, self.current_title)
        else:
            self.terminal.clear()

    def _refresh_username(self):
        pseudo = self.settings.get("pseudo", "").strip()
        self.username_var.set(f"@ {pseudo}" if pseudo else "@ utilisateur")

    def _open_personalization(self, e=None):
        self.left_panel.pack_forget()
        self.right_panel.pack_forget()
        self.personalization_page.pack(fill="both", expand=True)

    def _show_terminal_page(self, e=None):
        self.personalization_page.pack_forget()
        self.left_panel.pack(side="left", fill="y", padx=(0, 12))
        self.right_panel.pack(side="right", fill="both", expand=True)

    def _build_personalization_page(self, parent):
        self.selected_color_slot = "primary"
        page = tk.Frame(parent, bg=BG_MAIN)
        self.personalization_page = page
        header = tk.Frame(page, bg=BG_PANEL, highlightthickness=0)
        header.pack(fill="x", pady=(0, 10))
        tk.Label(header, text="PERSONNALISATION", font=("Courier New", 13, "bold"),
                 fg=ACCENT, bg=BG_PANEL).pack(side="left", padx=16, pady=12)
        back = tk.Label(header, text="← RETOUR AUX OUTILS",
                        font=("Courier New", 8, "bold"), fg=ACCENT_DIM,
                        bg=BG_PANEL, cursor="hand2")
        back.pack(side="right", padx=16, pady=14)
        back.bind("<Button-1>", self._show_terminal_page)

        body = tk.Frame(page, bg=BG_MAIN)
        body.pack(fill="both", expand=True, padx=18, pady=(4, 18))
        left = tk.Frame(body, bg=BG_PANEL)
        left.pack(side="left", fill="both", expand=True, padx=(0, 9))
        right = tk.Frame(body, bg=BG_PANEL, highlightthickness=0)
        right.pack(side="right", fill="both", expand=True, padx=(9, 0))

        tk.Label(left, text="PROFIL & APPARENCE", font=("Courier New", 11, "bold"),
                 fg=TEXT_MAIN, bg=BG_PANEL).pack(anchor="w", padx=18, pady=(16, 12))
        pseudo_box = tk.Frame(left, bg=BG_CARD, highlightthickness=0)
        pseudo_box.pack(fill="x", padx=16, pady=(0, 14))
        tk.Label(pseudo_box, text="PSEUDO", font=("Courier New", 8, "bold"),
                 fg=TEXT_DIM, bg=BG_CARD).pack(anchor="w", padx=12, pady=(10, 3))
        pseudo_var = tk.StringVar(value=self.settings.get("pseudo", ""))
        pseudo_entry = tk.Entry(pseudo_box, textvariable=pseudo_var,
                                bg=BG_MAIN, fg=TEXT_MAIN, insertbackground=ACCENT,
                                font=("Courier New", 11, "bold"), relief="flat", bd=0)
        pseudo_entry.pack(fill="x", padx=12, pady=(2, 10), ipady=6)
        pseudo_line = tk.Frame(pseudo_box, bg=ACCENT_DIM, height=2)
        pseudo_line.pack(fill="x", padx=12, pady=(0, 8))

        def update_pseudo(*_):
            self.settings["pseudo"] = pseudo_var.get()[:24]
            self._refresh_username()
            save_settings(self.settings)
        pseudo_var.trace_add("write", update_pseudo)

        def slider(title, value, command):
            box = tk.Frame(left, bg=BG_CARD, highlightthickness=0)
            box.pack(fill="x", padx=16, pady=(0, 10))
            label_var = tk.StringVar(value=f"{title}  {int(value)}%")
            tk.Label(box, textvariable=label_var, font=("Courier New", 8, "bold"),
                     fg=TEXT_MAIN, bg=BG_CARD).pack(anchor="w", padx=12, pady=(9, 1))
            scale = tk.Scale(box, from_=35 if title == "OPACITE FENETRE" else 0, to=100,
                             orient="horizontal", showvalue=False, resolution=1,
                             bg=BG_CARD, fg=ACCENT, troughcolor=BG_MAIN,
                             activebackground=ACCENT, highlightthickness=0,
                             bd=0, sliderrelief="flat", length=270)
            scale.set(value)
            scale.pack(fill="x", padx=10, pady=(0, 7))
            def changed(raw):
                number = int(float(raw))
                label_var.set(f"{title}  {number}%")
                command(number)
            scale.configure(command=changed)
            return scale, label_var

        def update_gradient(value):
            self.settings["gradient"] = value
            self._apply_theme("Personnalise",
                              self.settings.get("custom_color", "#5865f2"),
                              self.settings.get("gradient_color", "#eb459e"))

        def update_opacity(value):
            self.settings["opacity"] = value
            self.attributes("-alpha", value / 100)
            save_settings(self.settings)

        slider("DEGRADE GLOBAL", self.settings.get("gradient", 100), update_gradient)
        slider("OPACITE FENETRE", self.settings.get("opacity", 100), update_opacity)

        self.element_title_var = tk.StringVar(value="REGLAGES CIBLES : COULEUR A")
        tk.Label(left, textvariable=self.element_title_var,
                 font=("Courier New", 8, "bold"), fg=ACCENT_DIM,
                 bg=BG_PANEL).pack(anchor="w", padx=18, pady=(5, 8))

        def update_element_opacity(value):
            self.settings[f"{self.selected_color_slot}_opacity"] = value
            self._apply_theme("Personnalise",
                              self.settings.get("custom_color", "#5865f2"),
                              self.settings.get("gradient_color", "#eb459e"))

        def update_element_mix(value):
            self.settings[f"{self.selected_color_slot}_mix"] = value
            self._apply_theme("Personnalise",
                              self.settings.get("custom_color", "#5865f2"),
                              self.settings.get("gradient_color", "#eb459e"))

        self.element_opacity_scale, self.element_opacity_label = slider(
            "OPACITE ELEMENT", self.settings.get("primary_opacity", 100), update_element_opacity)
        self.element_mix_scale, self.element_mix_label = slider(
            "MELANGE DEGRADE", self.settings.get("primary_mix", 0), update_element_mix)
        tk.Label(left, text="La couleur et le pseudo sont sauvegardes\nautomatiquement.",
                 justify="left", font=("Courier New", 8),
                 fg=TEXT_DIM, bg=BG_PANEL).pack(anchor="w", padx=18, pady=6)

        tk.Label(right, text="SELECTEUR DE COULEUR", font=("Courier New", 11, "bold"),
                 fg=TEXT_MAIN, bg=BG_PANEL).pack(pady=(16, 3))
        tk.Label(right, text="Choisis un element, puis selectionne sa couleur",
                 font=("Courier New", 8), fg=TEXT_DIM, bg=BG_PANEL).pack(pady=(0, 8))
        selectors = tk.Frame(right, bg=BG_PANEL)
        selectors.pack(pady=(0, 5))
        def select_slot(slot):
            self.selected_color_slot = slot
            names = {"primary":"COULEUR A", "secondary":"COULEUR B",
                     "background":"FOND", "logo":"LOGO",
                     "option_text":"TEXTE OUTILS"}
            self.element_title_var.set(f"REGLAGES CIBLES : {names[slot]}")
            self.primary_swatch.set_selected(slot == "primary")
            self.secondary_swatch.set_selected(slot == "secondary")
            self.background_swatch.set_selected(slot == "background")
            self.logo_swatch.set_selected(slot == "logo")
            self.option_text_swatch.set_selected(slot == "option_text")
            opacity = self.settings.get(f"{slot}_opacity", 100)
            mix_value = self.settings.get(f"{slot}_mix", 0)
            self.element_opacity_scale.set(opacity)
            self.element_mix_scale.set(mix_value)
            if hasattr(self, "hex_var"):
                keys = {"primary":"custom_color", "secondary":"gradient_color",
                        "background":"background_color", "logo":"logo_color",
                        "option_text":"option_text_color"}
                self.hex_var.set(self.settings.get(keys[slot], "#ffffff").upper())
        self.primary_swatch = ColorSlot(selectors, "COULEUR A",
                                        self.settings.get("custom_color", "#5865f2"),
                                        lambda: select_slot("primary"))
        self.secondary_swatch = ColorSlot(selectors, "COULEUR B",
                                          self.settings.get("gradient_color", "#eb459e"),
                                          lambda: select_slot("secondary"))
        self.background_swatch = ColorSlot(selectors, "FOND",
                                           self.settings.get("background_color", "#0b0d12"),
                                           lambda: select_slot("background"))
        self.logo_swatch = ColorSlot(selectors, "LOGO",
                                     self.settings.get("logo_color", ACCENT),
                                     lambda: select_slot("logo"))
        self.option_text_swatch = ColorSlot(selectors, "TEXTE OUTILS",
                                            self.settings.get("option_text_color", TEXT_MAIN),
                                            lambda: select_slot("option_text"))
        for index, swatch in enumerate((self.primary_swatch, self.secondary_swatch,
                                        self.background_swatch, self.logo_swatch,
                                        self.option_text_swatch)):
            swatch.grid(row=index // 3, column=index % 3, padx=4, pady=2)
        self.primary_swatch.set_selected(True)
        picker_width, picker_height = 260, 170
        self.picker_hue = 0.95
        picker = tk.Canvas(right, width=picker_width, height=picker_height,
                           bg=BG_PANEL, bd=0, highlightthickness=0, cursor="crosshair")
        picker.pack(pady=(8, 4))
        self.color_picker_image = tk.PhotoImage(width=picker_width, height=picker_height)
        picker.create_image(0, 0, image=self.color_picker_image, anchor="nw")
        self.picker_marker = picker.create_oval(0, 0, 12, 12, outline="#ffffff", width=2)

        def render_picker():
            for y in range(picker_height):
                value = 1 - y / (picker_height - 1)
                row = []
                for x in range(picker_width):
                    saturation = x / (picker_width - 1)
                    rr, gg, bb = colorsys.hsv_to_rgb(self.picker_hue, saturation, value)
                    row.append(f"#{int(rr*255):02x}{int(gg*255):02x}{int(bb*255):02x}")
                self.color_picker_image.put("{" + " ".join(row) + "}", to=(0, y))
        render_picker()

        hue_bar = tk.Canvas(right, width=picker_width, height=16, bg=BG_PANEL,
                            bd=0, highlightthickness=0, cursor="hand2")
        hue_bar.pack(pady=(0, 8))
        hue_image = tk.PhotoImage(width=picker_width, height=16)
        self.hue_bar_image = hue_image
        for x in range(picker_width):
            rr, gg, bb = colorsys.hsv_to_rgb(x / (picker_width - 1), 1, 1)
            color = f"#{int(rr*255):02x}{int(gg*255):02x}{int(bb*255):02x}"
            hue_image.put(color, to=(x, 0, x+1, 16))
        hue_bar.create_image(0, 0, image=hue_image, anchor="nw")
        self.hue_marker = hue_bar.create_line(self.picker_hue*picker_width, 0,
                                              self.picker_hue*picker_width, 16,
                                              fill="#ffffff", width=3)

        hex_row = tk.Frame(right, bg=BG_PANEL)
        hex_row.pack(pady=(0, 7))
        self.hex_var = tk.StringVar(value=self.settings.get("custom_color", "#5865f2"))
        hex_entry = tk.Entry(hex_row, textvariable=self.hex_var, width=14,
                             font=("Courier New", 10, "bold"), bg=BG_CARD,
                             fg=TEXT_MAIN, insertbackground=ACCENT, relief="flat", bd=0)
        hex_entry.pack(side="left", ipady=6, padx=(0, 6))

        def apply_chosen(chosen):
            if self.selected_color_slot == "primary":
                self.settings["custom_color"] = chosen
                self.primary_swatch.set_color(chosen)
            elif self.selected_color_slot == "secondary":
                self.settings["gradient_color"] = chosen
                self.secondary_swatch.set_color(chosen)
            elif self.selected_color_slot == "background":
                self.settings["background_color"] = chosen
                self.background_swatch.set_color(chosen)
            elif self.selected_color_slot == "logo":
                self.settings["logo_color"] = chosen
                self.logo_swatch.set_color(chosen)
            else:
                self.settings["option_text_color"] = chosen
                self.option_text_swatch.set_color(chosen)
            self.hex_var.set(chosen.upper())
            self._apply_theme("Personnalise",
                              self.settings.get("custom_color", "#5865f2"),
                              self.settings.get("gradient_color", "#eb459e"))

        def choose_sv(event):
            x = max(0, min(picker_width-1, event.x))
            y = max(0, min(picker_height-1, event.y))
            saturation, value = x/(picker_width-1), 1-y/(picker_height-1)
            rr, gg, bb = colorsys.hsv_to_rgb(self.picker_hue, saturation, value)
            picker.coords(self.picker_marker, x-6, y-6, x+6, y+6)
            apply_chosen(f"#{int(rr*255):02x}{int(gg*255):02x}{int(bb*255):02x}")

        def choose_hue(event):
            x = max(0, min(picker_width-1, event.x))
            self.picker_hue = x/(picker_width-1)
            hue_bar.coords(self.hue_marker, x, 0, x, 16)
            render_picker()

        def apply_hex(event=None):
            value = self.hex_var.get().strip()
            if not value.startswith("#"):
                value = "#" + value
            if len(value) == 7:
                try:
                    int(value[1:], 16)
                    apply_chosen(value.lower())
                except ValueError:
                    pass

        picker.bind("<Button-1>", choose_sv)
        picker.bind("<B1-Motion>", choose_sv)
        hue_bar.bind("<Button-1>", choose_hue)
        hue_bar.bind("<B1-Motion>", choose_hue)
        hex_entry.bind("<Return>", apply_hex)
        apply_hex_btn = tk.Label(hex_row, text="APPLIQUER", font=("Courier New", 7, "bold"),
                                 fg=ACCENT_DIM, bg=BG_PANEL, cursor="hand2")
        apply_hex_btn.pack(side="left")
        apply_hex_btn.bind("<Button-1>", apply_hex)

        quick = tk.Frame(right, bg=BG_PANEL)
        quick.pack(pady=(0, 8))
        for color in ("#f2f3f5", "#80848e", "#5865f2", "#23a559", "#f0b232", "#f23f42"):
            swatch = tk.Canvas(quick, width=28, height=24, bg=BG_PANEL,
                               bd=0, highlightthickness=0, cursor="hand2")
            swatch.pack(side="left", padx=3)
            swatch.create_rectangle(2, 2, 26, 22, fill=color, outline=BORDER)
            swatch.bind("<Button-1>", lambda e, c=color: apply_chosen(c))

    def _apply_theme(self, theme_name, custom_color=None, second_color=None):
        global LOGO_COLOR, OPTION_TEXT
        old = {key: globals()[key] for key in THEMES["Violet"]}
        self.theme_name = theme_name
        self.settings["theme"] = theme_name
        if custom_color:
            self.settings["custom_color"] = custom_color
        if second_color:
            self.settings["gradient_color"] = second_color

        def blend(first, second, percent):
            a = tuple(int(first[i:i+2], 16) for i in (1, 3, 5))
            b = tuple(int(second[i:i+2], 16) for i in (1, 3, 5))
            ratio = max(0, min(100, percent)) / 100
            values = tuple(round(x + (y-x)*ratio) for x, y in zip(a, b))
            return "#%02x%02x%02x" % values

        raw_primary = self.settings.get("custom_color", "#5865f2")
        raw_secondary = self.settings.get("gradient_color", "#eb459e")
        raw_background = self.settings.get("background_color", "#0b0d12")
        def effective(slot, color, gradient_target, base):
            mixed = blend(color, gradient_target, self.settings.get(f"{slot}_mix", 0))
            return blend(base, mixed, self.settings.get(f"{slot}_opacity", 100))

        final_background = effective("background", raw_background, raw_secondary, "#07090d")
        final_primary = effective("primary", raw_primary, raw_secondary, final_background)
        final_secondary = effective("secondary", raw_secondary, raw_primary, final_background)
        final_logo = effective("logo", self.settings.get("logo_color", raw_primary),
                               raw_secondary, final_background)
        final_option_text = effective("option_text",
                                      self.settings.get("option_text_color", "#f2f3f5"),
                                      raw_secondary, final_background)
        set_global_theme(theme_name,
                         final_primary,
                         final_secondary,
                         self.settings.get("gradient", 100),
                         final_background)
        LOGO_COLOR = final_logo
        OPTION_TEXT = final_option_text
        new = {key: globals()[key] for key in THEMES["Violet"]}
        replacements = {old[key]: new[key] for key in old}

        def recolor(widget):
            for option in ("background", "foreground", "highlightbackground",
                           "insertbackground", "selectbackground",
                           "activebackground", "activeforeground"):
                try:
                    current = widget.cget(option)
                    if current in replacements:
                        widget.configure(**{option: replacements[current]})
                except Exception:
                    pass
            for child in widget.winfo_children():
                recolor(child)

        recolor(self)
        for card in self.tool_cards:
            card.refresh_theme()
        self.logo_label.configure(fg=LOGO_COLOR)
        for button in self.digital_buttons:
            button.refresh_theme()
        if hasattr(self, "primary_swatch"):
            for swatch in (self.primary_swatch, self.secondary_swatch,
                           self.background_swatch, self.logo_swatch,
                           self.option_text_swatch):
                swatch.redraw()
        try:
            self.terminal.output.tag_configure("green", foreground=LOGO_COLOR)
            self.terminal.output.tag_configure("orange", foreground=ORANGE)
            self.terminal.output.tag_configure("dim", foreground=TEXT_DIM)
            self.terminal.output.tag_configure("white", foreground=TEXT_MAIN)
        except Exception:
            pass
        save_settings(self.settings)

    def _load_count(self):
        count = fetch_user_count()
        label = f"👥 {count} utilisateur{'s' if count > 1 else ''}"
        self.after(0, lambda: self.count_var.set(label))

    def _on_close(self):
        self.terminal.kill()
        self.destroy()



if __name__ == "__main__":
    show_license_screen()
    app = App()
    app.mainloop()
