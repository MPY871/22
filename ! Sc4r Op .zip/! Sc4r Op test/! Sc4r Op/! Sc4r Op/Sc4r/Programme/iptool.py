import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()
import requests
from colorama import Fore, Style, init
init()

TOKEN = "691b5da3c2ffa2"

LOGO = r"""
 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
"""

def scanner_ip():
    ip_address = input(Fore.WHITE + "\n[?] Entrer l'adresse IP : ").strip()
    if not ip_address:
        print(Fore.WHITE + "[!] Adresse IP vide.")
        return

    url = f"https://ipinfo.io/{ip_address}?token={TOKEN}"
    try:
        response = requests.get(url, timeout=10)
    except Exception as e:
        print(Fore.WHITE + f"[!] Erreur de connexion : {e}")
        return

    if response.status_code == 200:
        ip_info = response.json()
        print(Fore.WHITE + f"""
┌─────────────────────────────────────────────────┐
│  Informations pour : {ip_address:<28}│
├─────────────────────────────────────────────────┤
│  IP           : {ip_info.get('ip', 'N/A'):<32}│
│  Ville        : {ip_info.get('city', 'N/A'):<32}│
│  Région       : {ip_info.get('region', 'N/A'):<32}│
│  Pays         : {ip_info.get('country', 'N/A'):<32}│
│  Code postal  : {ip_info.get('postal', 'N/A'):<32}│
│  Coordonnées  : {ip_info.get('loc', 'N/A'):<32}│
│  Organisation : {ip_info.get('org', 'N/A'):<32}│
│  Fuseau       : {ip_info.get('timezone', 'N/A'):<32}│
└─────────────────────────────────────────────────┘""" + Style.RESET_ALL)
    else:
        print(Fore.WHITE + f"[!] Adresse IP non valide ou informations non disponibles pour {ip_address}")

def main():
    while True:
        print(Fore.WHITE + LOGO)
        print(Fore.WHITE + "[1] Scanner une adresse IP")
        print(Fore.WHITE + "[2] Revenir au menu principal")

        choix = input(Fore.WHITE + "\n[?] : ").strip()

        if choix == "1":
            scanner_ip()
            input(Fore.WHITE + "\n[+] Appuie sur Entrée pour continuer...")
        elif choix == "2":
            return
        else:
            print(Fore.WHITE + "[!] Choix invalide.")

if __name__ == "__main__":
    main()
