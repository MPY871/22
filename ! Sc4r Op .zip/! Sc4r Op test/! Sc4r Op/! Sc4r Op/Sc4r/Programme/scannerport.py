
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()

"""
SCANNER DE PORTS AVANCÉ -DarkServer
Scanner complet avec toutes les fonctionnalités
"""

import socket
import sys
import threading
import queue
import time
from datetime import datetime
import ipaddress
import subprocess
import platform
import json
import os

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

class AdvancedPortScanner:
    def __init__(self):
        self.open_ports = []
        self.closed_ports = []
        self.filtered_ports = []
        self.scan_stats = {
            'start_time': None,
            'end_time': None,
            'total_ports': 0,
            'scanned': 0
        }
        self.services_db = self.load_services_database()
        self.lock = threading.Lock()
        
    def load_services_database(self):
        return {
            20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet",
            25: "SMTP", 53: "DNS", 67: "DHCP", 68: "DHCP",
            69: "TFTP", 80: "HTTP", 110: "POP3", 123: "NTP",
            135: "MS-RPC", 137: "NetBIOS", 138: "NetBIOS", 139: "NetBIOS",
            143: "IMAP", 161: "SNMP", 162: "SNMP-Trap", 389: "LDAP",
            443: "HTTPS", 445: "SMB", 465: "SMTPS", 514: "Syslog",
            587: "SMTP-Submission", 636: "LDAPS", 993: "IMAPS", 995: "POP3S",
            1433: "MS-SQL", 1434: "MS-SQL-Monitor", 1521: "Oracle",
            2049: "NFS", 2082: "cPanel", 2083: "cPanel-SSL", 2086: "WHM",
            2087: "WHM-SSL", 3306: "MySQL", 3389: "RDP", 5000: "UPnP",
            5432: "PostgreSQL", 5900: "VNC", 5901: "VNC", 6379: "Redis",
            8000: "HTTP-Alt", 8080: "HTTP-Proxy", 8443: "HTTPS-Alt",
            8888: "HTTP-Alt", 9000: "SonarQube", 9090: "Prometheus",
            9200: "Elasticsearch", 9300: "Elasticsearch", 10000: "Webmin",
            27017: "MongoDB", 27018: "MongoDB", 50000: "SAP", 50070: "Hadoop"
        }
    
    def banner(self):

        banner_text = f"""
{Colors.WHITE}{Colors.WHITE}
╔══════════════════════════════════════════════════════════════╗
║              SCANNER DE PUTES - DarkServer                   ║
║                     Version 1.1.0                            ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}
{Colors.WHITE}Fonctionnalités:{Colors.WHITE}
  • Scan multi-threadé ultra-rapide
  • Détection de services avancée
  • Scan de plages d'IP (CIDR)
  • Ping sweep et vérification d'hôte
  • Export des résultats (JSON/TXT)
  • Banner grabbing
  • Scan furtif
  • Statistiques détaillées
{Colors.WHITE}
AVERTISSEMENT: Utilisez uniquement pour trouver des grosses putes
{Colors.WHITE}
"""
        print(banner_text)
    
    def ping_host(self, host):
        param = '-n' if platform.system().lower() == 'windows' else '-c'
        command = ['ping', param, '1', '-W', '1', host]
        try:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=2)
            return result.returncode == 0
        except:
            return False
    
    def grab_banner(self, ip, port, timeout=2):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            sock.connect((ip, port))
            

            try:
                sock.send(b'HEAD / HTTP/1.0\r\n\r\n')
            except:
                pass
            
            banner = sock.recv(1024).decode('utf-8', errors='ignore').strip()
            sock.close()
            return banner[:100] if banner else None
        except:
            return None
    
    def scan_port_advanced(self, ip, port, timeout=1, grab_banner=False):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            
            if result == 0:
                service = self.services_db.get(port, "Putes non reconnue")
                banner = None
                
                if grab_banner:
                    banner = self.grab_banner(ip, port, timeout)
                
                sock.close()
                return {
                    'status': 'open',
                    'port': port,
                    'service': service,
                    'banner': banner
                }
            else:
                sock.close()
                return {'status': 'closed', 'port': port}
                
        except socket.timeout:
            return {'status': 'filtered', 'port': port}
        except:
            return {'status': 'filtered', 'port': port}
    
    def worker(self, ip, port_queue, timeout, grab_banner_flag):
        while True:
            try:
                port = port_queue.get(timeout=1)
                result = self.scan_port_advanced(ip, port, timeout, grab_banner_flag)
                
                with self.lock:
                    self.scan_stats['scanned'] += 1
                    
                    if result['status'] == 'open':
                        self.open_ports.append(result)
                        print(f"{Colors.GREEN}[+] Putes {port:5d} OUVERT  - {result['service']}{Colors.END}")
                        if result.get('banner'):
                            print(f"    {Colors.CYAN}└─ Banner: {result['banner'][:80]}{Colors.END}")
                    elif result['status'] == 'filtered':
                        self.filtered_ports.append(port)
                
                port_queue.task_done()
            except queue.Empty:
                break
    
    def scan_host(self, ip, start_port, end_port, threads, timeout, grab_banner_flag):
        print(f"\n{Colors.WHITE}{'='*70}{Colors.WHITE}")
        print(f"{Colors.WHITE}Cible: {Colors.WHITE}{ip}{Colors.WHITE}")
        print(f"{Colors.WHITE}Plage: {start_port}-{end_port} ({end_port - start_port + 1} ports){Colors.END}")
        print(f"{Colors.WHITE}Threads: {threads}{Colors.END}")
        print(f"{Colors.WHITE}Timeout: {timeout}s{Colors.END}")
        print(f"{Colors.WHITE}{'='*70}{Colors.END}\n")
        
   
        print(f"{Colors.WHITE}Vérification de la putes...{Colors.END}")
        try:
            resolved_ip = socket.gethostbyname(ip)
            print(f"{Colors.WHITE}✓ Putes trouvee: {resolved_ip}{Colors.END}")
        except:
            print(f"{Colors.WHITE}✗ Impossible de résoudre la putes{Colors.END}")
            return
        

        print(f"{Colors.WHITE}Test de putes(ping)...{Colors.END}")
        if self.ping_host(resolved_ip):
            print(f"{Colors.WHITE}✓ Putes accessible{Colors.END}\n")
        else:
            print(f"{Colors.WHITE}⚠ Putes ne répond pas au ping (peut être filtré){Colors.END}\n")
        

        self.open_ports = []
        self.closed_ports = []
        self.filtered_ports = []
        self.scan_stats['start_time'] = datetime.now()
        self.scan_stats['total_ports'] = end_port - start_port + 1
        self.scan_stats['scanned'] = 0
        

        port_queue = queue.Queue()
        for port in range(start_port, end_port + 1):
            port_queue.put(port)
        

        print(f"{Colors.BOLD}Démarrage du scan de putes...{Colors.END}\n")
        thread_list = []
        for _ in range(threads):
            t = threading.Thread(target=self.worker, args=(resolved_ip, port_queue, timeout, grab_banner_flag))
            t.daemon = True
            t.start()
            thread_list.append(t)

        while not port_queue.empty():
            progress = (self.scan_stats['scanned'] / self.scan_stats['total_ports']) * 100
            print(f"\r{Colors.CYAN}Progression: {progress:.1f}% ({self.scan_stats['scanned']}/{self.scan_stats['total_ports']}){Colors.END}", end='', flush=True)
            time.sleep(0.5)
        
        port_queue.join()
        for t in thread_list:
            t.join()
        
        self.scan_stats['end_time'] = datetime.now()
        print(f"\n\n{Colors.GREEN}✓ Scan de pute terminé!{Colors.END}\n")
        

        self.display_results()
    
    def display_results(self):
        duration = (self.scan_stats['end_time'] - self.scan_stats['start_time']).total_seconds()
        
        print(f"{Colors.WHITE}{'='*70}{Colors.END}")
        print(f"{Colors.WHITE}{Colors.BOLD}RÉSULTATS DU SCAN DE PUTE{Colors.END}")
        print(f"{Colors.WHITE}{'='*70}{Colors.END}\n")
        
        print(f"Durée du scan des putes: {Colors.WHITE}{duration:.2f}s{Colors.END}")
        print(f"Vitesse: {Colors.WHITE}{self.scan_stats['total_ports']/duration:.0f} ports/sec{Colors.END}")
        print(f"Ports ouverts: {Colors.WHITE}{Colors.BOLD}{len(self.open_ports)}{Colors.END}")
        print(f"Ports fermés: {Colors.WHITE}{self.scan_stats['total_ports'] - len(self.open_ports) - len(self.filtered_ports)}{Colors.END}")
        print(f"Ports filtrés: {Colors.WHITE}{len(self.filtered_ports)}{Colors.END}\n")
        
        if self.open_ports:
            print(f"{Colors.WHITE}{'─'*70}{Colors.END}")
            print(f"{Colors.WHITE}{Colors.BOLD}PUTES OUVERTS DÉTAILLÉS:{Colors.END}\n")
            

            self.open_ports.sort(key=lambda x: x['port'])
            
            for result in self.open_ports:
                print(f"{Colors.WHITE}┌─ Port {result['port']:5d} {Colors.END}")
                print(f"{Colors.WHITE}│  Service: {Colors.BOLD}{result['service']}{Colors.END}")
                if result.get('banner'):
                    print(f"{Colors.WHITE}│  Banner:  {result['banner'][:60]}{Colors.END}")
                print(f"{Colors.WHITE}└{'─'*68}{Colors.END}\n")
        else:
            print(f"{Colors.WHITE}Aucun putes ouverte détecté{Colors.END}\n")
        
        print(f"{Colors.WHITE}{'='*70}{Colors.END}")
    
    def export_results(self, filename, format_type='txt'):

        if format_type == 'json':
            data = {
                'scan_info': {
                    'start_time': self.scan_stats['start_time'].isoformat(),
                    'end_time': self.scan_stats['end_time'].isoformat(),
                    'duration': (self.scan_stats['end_time'] - self.scan_stats['start_time']).total_seconds(),
                    'total_ports_scanned': self.scan_stats['total_ports']
                },
                'open_ports': self.open_ports,
                'filtered_ports': self.filtered_ports
            }
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
        else: 
            with open(filename, 'w') as f:
                f.write("="*70 + "\n")
                f.write("RAPPORT DE SCAN DE PUTE\n")
                f.write("="*70 + "\n\n")
                f.write(f"Date: {self.scan_stats['start_time'].strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Durée: {(self.scan_stats['end_time'] - self.scan_stats['start_time']).total_seconds():.2f}s\n")
                f.write(f"Putes scannés: {self.scan_stats['total_ports']}\n")
                f.write(f"Putes ouverts: {len(self.open_ports)}\n\n")
                
                if self.open_ports:
                    f.write("-"*70 + "\n")
                    f.write("PUTES OUVERTES:\n")
                    f.write("-"*70 + "\n\n")
                    for result in sorted(self.open_ports, key=lambda x: x['port']):
                        f.write(f"Port {result['port']:5d} - {result['service']}\n")
                        if result.get('banner'):
                            f.write(f"  Banner: {result['banner']}\n")
                        f.write("\n")
        
        print(f"{Colors.WHITE}✓ Résultats exportés dans: {filename}{Colors.END}")
    
    def scan_network_range(self, network, port_range, threads, timeout):
        try:
            net = ipaddress.ip_network(network, strict=False)
            hosts = list(net.hosts())
            
            print(f"\n{Colors.WHITE}Scan du réseau des putes: {network}{Colors.END}")
            print(f"{Colors.WHITE}Nombre de pute: {len(hosts)}{Colors.END}\n")
            

            print(f"{Colors.WHITE}Phase 1: Découverte de chatte active...{Colors.END}\n")
            active_hosts = []
            
            for i, host in enumerate(hosts):
                print(f"\r{Colors.WHITE}Vérification de la qualite de la pute: {i+1}/{len(hosts)}{Colors.END}", end='', flush=True)
                if self.ping_host(str(host)):
                    active_hosts.append(str(host))
                    print(f"\n{Colors.WHITE}✓ Putes active trouvé: {host}{Colors.END}")
            
            print(f"\n\n{Colors.WHITE}✓ {len(active_hosts)} pute(s) active(s) trouvé(s){Colors.END}\n")
            

            if active_hosts:
                print(f"{Colors.WHITE}Phase 2: Scan des putes sur les chattes active...{Colors.END}\n")
                for host in active_hosts:
                    start_port, end_port = port_range
                    self.scan_host(host, start_port, end_port, threads, timeout, False)
                    print("\n")
            else:
                print(f"{Colors.WHITE}✗ Aucune pute active trouvé{Colors.END}")
                
        except Exception as e:
            print(f"{Colors.WHITE}✗ Erreur aucune pute: {e}{Colors.END}")

def main():
    scanner = AdvancedPortScanner()
    scanner.banner()
    
    while True:
        print(f"\n{Colors.WHITE}{Colors.WHITE}╔════════════════════════════════════════╗{Colors.END}")
        print(f"{Colors.WHITE}{Colors.WHITE}║          MENU PRINCIPAL                ║{Colors.END}")
        print(f"{Colors.WHITE}{Colors.WHITE}╚════════════════════════════════════════╝{Colors.END}\n")
        
        print(f"{Colors.WHITE}1.{Colors.END} Scan standard (une IP)")
        print(f"{Colors.WHITE}2.{Colors.END} Scan rapide (ports communs)")
        print(f"{Colors.WHITE}3.{Colors.END} Scan complet (tous les ports 1-65535)")
        print(f"{Colors.WHITE}4.{Colors.END} Scan personnalisé")
        print(f"{Colors.WHITE}5.{Colors.END} Scan de réseau (CIDR)")
        print(f"{Colors.WHITE}6.{Colors.END} Scan avec banner grabbing")
        print(f"{Colors.WHITE}7.{Colors.END} Scan furtif (lent mais discret)")
        print(f"{Colors.WHITE}8.{Colors.END} Quitter")
        
        choice = input(f"\n{Colors.WHITE}Votre choix salope de merde (1-8): {Colors.END}").strip()
        
        if choice == '8':
            print(f"\n{Colors.WHITE}Au revoir ma petite chiennes{Colors.END}\n")
            break
        
        if choice in ['1', '2', '3', '4', '6', '7']:
            ip = input(f"\n{Colors.WHITE}Adresse IP ou nom de la putes: {Colors.END}").strip()
            if not ip:
                print(f"{Colors.WHITE}✗ Adresse IP requise{Colors.END}")
                continue
            
            if choice == '1': 
                start_port, end_port = 1, 1024
                threads = 100
                timeout = 1
                grab_banner = False
            elif choice == '2': 
                start_port, end_port = 20, 1024
                threads = 200
                timeout = 0.5
                grab_banner = False
            elif choice == '3': 
                confirm = input(f"{Colors.WHITE}Scan complet des putes (ca peut prendre 10-20 min jrgl 1-2 min y a bcp de putes). Continuer? (o/n): {Colors.END}").lower()
                if confirm not in ['o', 'oui', 'y', 'yes']:
                    continue
                start_port, end_port = 1, 65535
                threads = 500
                timeout = 0.5
                grab_banner = False
            elif choice == '4':  
                try:
                    start_port = int(input(f"{Colors.WHITE}Port de début (1-65535): {Colors.END}"))
                    end_port = int(input(f"{Colors.WHITE}Port de fin (1-65535): {Colors.END}"))
                    threads = int(input(f"{Colors.WHITE}Nombre de threads (50-1000): {Colors.END}"))
                    timeout = float(input(f"{Colors.WHITE}Timeout en secondes (0.1-5): {Colors.END}"))
                    grab_banner = input(f"{Colors.WHITE}Activer banner grabbing? (o/n): {Colors.END}").lower() in ['o', 'oui', 'y', 'yes']
                except ValueError:
                    print(f"{Colors.WHITE}✗ Valeurs invalides{Colors.END}")
                    continue
            elif choice == '6':  
                start_port, end_port = 1, 1024
                threads = 50
                timeout = 2
                grab_banner = True
            elif choice == '7': 
                start_port, end_port = 1, 1024
                threads = 10
                timeout = 3
                grab_banner = False
            
            scanner.scan_host(ip, start_port, end_port, threads, timeout, grab_banner)
            
            if scanner.open_ports:
                export = input(f"\n{Colors.WHITE}Exporter les résultats? (o/n): {Colors.END}").lower()
                if export in ['o', 'oui', 'y', 'yes']:
                    format_choice = input(f"{Colors.WHITE}Format (txt/json): {Colors.END}").lower()
                    filename = input(f"{Colors.WHITE}Nom du fichier: {Colors.END}").strip()
                    if not filename:
                        filename = f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                    filename += f".{format_choice if format_choice in ['txt', 'json'] else 'txt'}"
                    scanner.export_results(filename, format_choice if format_choice in ['txt', 'json'] else 'txt')
        
        elif choice == '5': 
            network = input(f"\n{Colors.WHITE}Réseau CIDR (ex: 192.168.1.0/24): {Colors.END}").strip()
            if not network:
                print(f"{Colors.WHITE}✗ Réseau requis{Colors.END}")
                continue
            
            port_choice = input(f"{Colors.WHITE}Ports à scanner (1=communs, 2=personnalisé): {Colors.END}").strip()
            if port_choice == '2':
                try:
                    start_port = int(input(f"{Colors.WHITE}Port de début: {Colors.END}"))
                    end_port = int(input(f"{Colors.WHITE}Port de fin: {Colors.END}"))
                except ValueError:
                    print(f"{Colors.WHITE}✗ Valeurs invalides{Colors.END}")
                    continue
            else:
                start_port, end_port = 20, 1024
            
            threads = 100
            timeout = 1
            
            scanner.scan_network_range(network, (start_port, end_port), threads, timeout)
        
        else:
            print(f"{Colors.WHITE}✗ Choix invalide t'es vraiment trop con{Colors.END}")
        
        input(f"\n{Colors.WHITE}Appuie sur Entrée pour continuer grosse chienne...{Colors.END}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.WHITE}Scan interrompu par la grosse chienne que tu es{Colors.END}")
        print(f"{Colors.CYAN}Au revoir pite pute de merde a bientot{Colors.END}\n")
        sys.exit(0)
