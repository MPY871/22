import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()
import requests
from concurrent.futures import ThreadPoolExecutor
import webbrowser
from colorama import init, Fore, Style

init(autoreset=True)

sites = {
    "Twitter": "https://twitter.com/{}",
    "Facebook": "https://www.facebook.com/{}",
    "Instagram": "https://www.instagram.com/{}",
    "Github": "https://github.com/{}",
    "Reddit": "https://www.reddit.com/user/{}",
    "LinkedIn": "https://www.linkedin.com/in/{}",
    "Pinterest": "https://www.pinterest.com/{}",
    "YouTube": "https://www.youtube.com/{}",
    "Vimeo": "https://vimeo.com/{}",
    "TikTok": "https://www.tiktok.com/@{}",
    "Twitch": "https://www.twitch.tv/{}",
    "SoundCloud": "https://soundcloud.com/{}",
    "Patreon": "https://www.patreon.com/{}",
    "GitLab": "https://gitlab.com/{}",
    "Spotify": "https://open.spotify.com/user/{}"
}

def verifier_nom_utilisateur(site, url, nom_utilisateur):
    try:
        response = requests.get(url.format(nom_utilisateur), timeout=5)
        if response.status_code == 200:
            return (site, True, url.format(nom_utilisateur))
        else:
            return (site, False, None)
    except requests.RequestException:
        return (site, False, None)

def principal(nom_utilisateur):
    sites_trouves = []
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [
            executor.submit(verifier_nom_utilisateur, site, url, nom_utilisateur)
            for site, url in sites.items()
        ]
        results = [future.result() for future in futures]

    for site, existe, url in results:
        if existe:
            print(Fore.GREEN + f"[+] {nom_utilisateur} trouvé sur {site}")
            sites_trouves.append(url)
        else:
            print(Fore.RED + f"[-] {nom_utilisateur} non trouvé sur {site}")

    if sites_trouves:
        ouvrir_liens = input(Fore.WHITE + "\n[?] Voulez-vous ouvrir les liens ? (oui/non) : ").strip().lower()
        if ouvrir_liens == 'oui':
            for url in sites_trouves:
                webbrowser.open(url)
    else:
        print(Fore.YELLOW + "[!] Aucun lien à ouvrir.")

    print(Fore.WHITE + "\n[1] Encore 1")
    print(Fore.WHITE + "[2] Revien au Main Menu")
    print(Fore.WHITE + "[3] Quitter")

    choix = input(Fore.WHITE + "\n[?] : ").strip()

    if choix == "1":
        main()
    elif choix == "2":
        return  
    elif choix == "3":
        sys.exit()

def main():
    logo = r"""
 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
"""
    print(Fore.WHITE + logo)
    print(Fore.WHITE + "[1] Lancer une recherche")
    print(Fore.WHITE + "[2] Revien au Main Menu")

    choix = input(Fore.WHITE + "\n[?] : ").strip()

    if choix == "1":
        nom_utilisateur = input(Fore.WHITE + " Tu Recherche Qui ? : ")
        principal(nom_utilisateur)
    elif choix == "2":
        return  
    else:
        print(Fore.RED + "[!] Choix invalide.")
        main()

if __name__ == "__main__":
    main()
