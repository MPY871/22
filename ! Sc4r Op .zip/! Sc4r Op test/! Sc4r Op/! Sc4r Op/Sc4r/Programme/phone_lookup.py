import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()
import phonenumbers
from phonenumbers import carrier, geocoder, timezone


def main():
    print("LOOKUP NUM")
    print("[1] Rechercher un numéro")
    print("[2] Revenir au menu principal")
    choice = input().strip()
    if choice != "1":
        return
    raw = input("Numéro (ex: +33658182243) : ").strip()
    try:
        number = phonenumbers.parse(raw, None)
        if not phonenumbers.is_valid_number(number):
            print("Numéro invalide.")
            return
        kind = phonenumbers.number_type(number)
        print(f"\nStatut       : Valide")
        print(f"Numéro       : {phonenumbers.format_number(number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}")
        print(f"Pays         : {phonenumbers.region_code_for_number(number) or 'Inconnu'}")
        print(f"Région       : {geocoder.description_for_number(number, 'fr') or 'Inconnue'}")
        print(f"Opérateur    : {carrier.name_for_number(number, 'fr') or 'Inconnu'}")
        print(f"Fuseau       : {', '.join(timezone.time_zones_for_number(number)) or 'Inconnu'}")
        print(f"Type         : {'Mobile' if kind == phonenumbers.PhoneNumberType.MOBILE else 'Fixe/autre'}")
    except phonenumbers.NumberParseException as error:
        print(f"Format invalide : {error}")


if __name__ == "__main__":
    main()
