import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()
from colorama import init, Fore

init(autoreset=True)

def collecter_informations():
    repertoire_sauvegarde = os.path.join(os.getcwd(), "output", "dox-created")
    if not os.path.exists(repertoire_sauvegarde):
        os.makedirs(repertoire_sauvegarde)

    print(Fore.RED + "\n Ecris 'retour' pour revenir Sur la question précédente")
    print(Fore.RED + " Ecris 'menu' pour revenir au Menu principal\n")

    questions = [
        "[?] Nom du dox ? : ",
        "[?] Quel est le nom de la victime ? : ",
        "[?] Quel est le prénom de la victime ? : ",
        "[?] Quel est l'âge de la victime ? : ",
        "[?] Quelle est la date de naissance de la victime ? : ",
        "[?] Quel est le pays de la victime ? : ",
        "[?] Quelle est la ville de la victime ? : ",
        "[?] Quelle est l'adresse de la victime ? : ",
        "[?] Situation scolaire ou professionnelle de la victime ? : ",
        "[?] Autres informations sur la victime ? : ",
        "[?] Quel est le pseudo de la victime sur les sites en ligne ? : ",
        "[?] Quelle est l'adresse email de la victime ? : ",
        "[?] Quel est le numéro de téléphone de la victime ? : ",
        "[?] Quel est le compte YouTube de la victime ? : ",
        "[?] Quel est le compte Instagram de la victime ? : ",
        "[?] Quel est le compte Discord de la victime ? : ",
        "[?] Quel est le compte Twitter de la victime ? : ",
        "[?] Quel est le compte Facebook de la victime ? : ",
        "[?] Quel est le nom du père ? : ",
        "[?] Quel est le prénom du père ? : ",
        "[?] Quel est l'âge du père ? : ",
        "[?] Quelle est la résidence du père ? : ",
        "[?] Quelle est la profession du père ? : ",
        "[?] Informations supplémentaires sur le père ? : ",
        "[?] Quel est le nom de la mère ? : ",
        "[?] Quel est le prénom de la mère ? : ",
        "[?] Quel est l'âge de la mère ? : ",
        "[?] Quelle est la résidence de la mère ? : ",
        "[?] Quelle est la profession de la mère ? : ",
        "[?] Quels sont les intérêts de la mère ? : ",
        "[?] Informations supplémentaires sur la mère ? : ",
        "[?] Quel est le nom du PC ? : ",
        "[?] Quelle est la marque du PC ? : ",
        "[?] Quel est le modèle du PC ? : ",
        "[?] Quel est le système d'exploitation du PC ? : ",
        "[?] Quelle est l'adresse MAC du PC ? : ",
        "[?] Quelle est l'adresse IP du PC ? : ",
        "[?] Autres informations sur le PC ? : ",
    ]

    reponses = []
    i = 0
    while i < len(questions):
        rep = input(Fore.WHITE + questions[i]).strip()

        if rep.lower() == "menu":
            return "MENU", None

        if rep.lower() == "retour":
            if i > 0:
                i -= 1
                reponses.pop()
                print(Fore.YELLOW + f"[↩] Retour à : {questions[i]}\n")
            else:
                print(Fore.YELLOW + "[!] Tu es déjà à la première question.\n")
            continue

        reponses.append(rep)
        i += 1

    (DOX, Nom, Prenom, Age, Date, Pays, Ville, Adresse, Situation, Autre,
     Pseudo, Email, Telephone, YouTube, Instagram, Discord, Twitter, Facebook,
     Nom_Pere, Prenom_Pere, Age_Pere, Residence_Pere, Profession_Pere, Info_Pere,
     Nom_Mere, Prenom_Mere, Age_Mere, Residence_Mere, Profession_Mere,
     Interets_Mere, Info_Mere,
     Nom_PC, Marque_PC, Modele_PC, OS_PC, Adresse_MAC, Adresse_IP, Autre_PC) = reponses

    chemin_fichier = os.path.join(repertoire_sauvegarde, f"{DOX}.txt")

    contenu = f'''
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩    
╠╣    ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡠⢤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠟⠃⠀⠀⠙⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠋⠀⠀⠀⠀⠀⠀⠘⣆⠀⠀⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠾⢛⠒⠀⠀⠀⠀⠀⠀⠀⢸⡆⠀⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣶⣄⡈⠓⢄⠠⡀⠀⠀⠀⣄⣷⠀⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣷⠀⠈⠱⡄⠑⣌⠆⠀⠀⡜⢻⠀⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡿⠳⡆⠐⢿⣆⠈⢿⠀⠀⡇⠘⡆⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣷⡇⠀⠀⠈⢆⠈⠆⢸⠀⠀⢣⠀⠀⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣧⠀⠀⠈⢂⠀⡇⠀⠀⢨⠓⣄⠀⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣦⣤⠖⡏⡸⠀⣀⡴⠋⠀⠈⠢⡀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠁⣹⣿⣿⣿⣷⣾⠽⠖⠊⢹⣀⠄⠀⠀⠀⠈⢣⡀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡟⣇⣰⢫⢻⢉⠉⠀⣿⡆⠀⠀⡸⡏⠀⠀⠀⠀⠀⠀⢇
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢨⡇⡇⠈⢸⢸⢸⠀⠀⡇⡇⠀⠀⠁⠻⡄⡠⠂⠀⠀⠀⠘
╠╣⢤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠛⠓⡇⠀⠸⡆⢸⠀⢠⣿⠀⠀⠀⠀⣰⣿⣵⡆⠀⠀⠀⠀
╠╣⠈⢻⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡿⣦⣀⡇⠀⢧⡇⠀⠀⢺⡟⠀⠀⠀⢰⠉⣰⠟⠊⣠⠂⠀⡸
╠╣⠀⠀⢻⣿⣿⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⢧⡙⠺⠿⡇⠀⠘⠇⠀⠀⢸⣧⠀⠀⢠⠃⣾⣌⠉⠩⠭⠍⣉⡇
╠╣⠀⠀⠀⠻⣿⣿⣿⣿⣿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣞⣋⠀⠈⠀⡳⣧⠀⠀⠀⠀⠀⢸⡏⠀⠀⡞⢰⠉⠉⠉⠉⠉⠓⢻⠃
╠╣⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣷⡄⠀⠀⢀⣀⠠⠤⣤⣤⠤⠞⠓⢠⠈⡆⠀⢣⣸⣾⠆⠀⠀⠀⠀⠀⢀⣀⡼⠁⡿⠈⣉⣉⣒⡒⠢⡼⠀
╠╣⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣎⣽⣶⣤⡶⢋⣤⠃⣠⡦⢀⡼⢦⣾⡤⠚⣟⣁⣀⣀⣀⣀⠀⣀⣈⣀⣠⣾⣅⠀⠑⠂⠤⠌⣩⡇⠀
╠╣⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡁⣺⢁⣞⣉⡴⠟⡀⠀⠀⠀⠁⠸⡅⠀⠈⢷⠈⠏⠙⠀⢹⡛⠀⢉⠀⠀⠀⣀⣀⣼⡇⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⡟⢡⠖⣡⡴⠂⣀⣀⣀⣰⣁⣀⣀⣸⠀⠀⠀⠀⠈⠁⠀⠀⠈⠀⣠⠜⠋⣠⠁⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⣿⡟⢿⣿⣿⣷⡟⢋⣥⣖⣉⠀⠈⢁⡀⠤⠚⠿⣷⡦⢀⣠⣀⠢⣄⣀⡠⠔⠋⠁⠀⣼⠃⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⡄⠈⠻⣿⣿⢿⣛⣩⠤⠒⠉⠁⠀⠀⠀⠀⠀⠉⠒⢤⡀⠉⠁⠀⠀⠀⠀⠀⢀⡿⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣤⣤⠴⠟⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠤⠀⠀⠀⠀⠀⢩⠇⠀⠀⠀
╠╣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣                   DOSSIER D'INFORMATIONS PERSONNELLES                 
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣              INFORMATIONS PERSONNELLES          
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣  »Nom : {Nom}
╠╣  »Prénom : {Prenom}
╠╣  »Âge : {Age}
╠╣  »Date de naissance : {Date}
╠╣  »Pays : {Pays}
╠╣  »Ville : {Ville}
╠╣  »Adresse : {Adresse}
╠╣  »Adresse Email : {Email}
╠╣  »Numéro de téléphone : {Telephone}
╠╣  »Situation scolaire ou professionnelle : {Situation}
╠╣
╠╣   »Comptes en ligne :
╠╣      - YouTube : {YouTube}
╠╣      - Instagram : {Instagram}
╠╣      - Discord : {Discord}
╠╣      - Twitter : {Twitter}
╠╣      - Facebook : {Facebook}
╠╣
╠╣   »Autres informations : {Autre}
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣                      INFORMATIONS PÈRE
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣  »Nom du père : {Nom_Pere}
╠╣  »Prénom du père : {Prenom_Pere}
╠╣  »Âge du père : {Age_Pere}
╠╣  »Résidence du père : {Residence_Pere}
╠╣  »Profession du père : {Profession_Pere}
╠╣  »Autres informations sur le père : {Info_Pere}
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣                      INFORMATIONS MÈRE
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣  »Nom de la mère : {Nom_Mere}
╠╣  »Prénom de la mère : {Prenom_Mere}
╠╣  »Âge de la mère : {Age_Mere}
╠╣  »Résidence de la mère : {Residence_Mere}
╠╣  »Profession de la mère : {Profession_Mere}
╠╣  »Intérêts de la mère : {Interets_Mere}
╠╣  »Autres informations sur la mère : {Info_Mere}
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣                      INFORMATIONS PC
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣  »Nom du PC : {Nom_PC}
╠╣  »Marque du PC : {Marque_PC}
╠╣  »Modèle du PC : {Modele_PC}
╠╣  »Système d'exploitation : {OS_PC}
╠╣  »Adresse MAC : {Adresse_MAC}
╠╣  »Adresse IP : {Adresse_IP}
╠╣  »Autres informations : {Autre_PC}
╠╣╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦
╠╣╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩
╠╣╔═════════════════════════╗
╠╣║     By ! Sc4r           ║
╠╣╚═════════════════════════╝
'''

    with open(chemin_fichier, "w", encoding="utf-8") as fichier:
        fichier.write(contenu)

    return chemin_fichier, DOX


def menu_fin():
    print(Fore.WHITE + "\n[1] Créer un autre dox")
    print(Fore.WHITE + "[2] Retour au menu principal")
    print(Fore.WHITE + "[3] Quitter")

    choix = input(Fore.WHITE + "\n[?] : ").strip()

    if choix == "1":
        main()
    elif choix == "2":
        return
    elif choix == "3":
        sys.exit()
    else:
        print(Fore.RED + "[!] Choix invalide.")
        menu_fin()


def main():
    logo = r"""
 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
"""
    print(logo)
    print(Fore.WHITE + "\n[1] Créer un nouveau dox")
    print(Fore.WHITE + "[2] Retour au menu principal")

    choix = input(Fore.WHITE + "\n[?] : ").strip()

    if choix == "1":
        resultat, DOX = collecter_informations()
        if resultat == "MENU":
            print(Fore.YELLOW + "\n[!] Retour au menu principal.")
            return
        print(Fore.GREEN + f"\n[+] Le fichier {DOX}.txt a été sauvegardé ici : {resultat}")
        input(Fore.GREEN + "[+] Appuie sur Entrée pour continuer...")
        menu_fin()
    elif choix == "2":
        return
    else:
        print(Fore.RED + "[!] Choix invalide.")
        main()


if __name__ == "__main__":
    main()
