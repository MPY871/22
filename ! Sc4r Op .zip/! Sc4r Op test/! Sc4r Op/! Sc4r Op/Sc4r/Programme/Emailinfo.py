import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()
import dns.resolver
import requests
import re
from colorama import Fore, Style, init
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time

init(autoreset=True)

def print_title(title):
    print(f"{Fore.GREEN}{Style.BRIGHT}{title}{Style.RESET_ALL}")

def fetch_email_details(email_address):
    details = {}
    try: full_domain = email_address.split('@')[-1]
    except: full_domain = None

    try: username = email_address.split('@')[0]
    except: username = None

    try: domain_name = re.search(r"@([^@.]+)\.", email_address).group(1)
    except: domain_name = None

    try: top_level_domain = f".{email_address.split('.')[-1]}"
    except: top_level_domain = None

    try: details["mx_servers"] = [str(record.exchange) for record in dns.resolver.resolve(full_domain, 'MX')]
    except: details["mx_servers"] = None

    try: details["spf_records"] = [str(record) for record in dns.resolver.resolve(full_domain, 'SPF')]
    except: details["spf_records"] = None

    try: details["dmarc_records"] = [str(record) for record in dns.resolver.resolve(f'_dmarc.{full_domain}', 'TXT')]
    except: details["dmarc_records"] = None

    try: details["txt_records"] = [str(record) for record in dns.resolver.resolve(full_domain, 'TXT')]
    except: details["txt_records"] = None

    try: details["srv_records"] = [str(record) for record in dns.resolver.resolve(f"_sip._tcp.{full_domain}", 'SRV')]
    except: details["srv_records"] = None

    try:
        response = requests.get(f"https://email-reputation.api.useinsider.com/lookup/{email_address}")
        details["email_reputation"] = response.json()
    except Exception as err:
        details["email_reputation"] = {"error": str(err)}

    try: details["a_records"] = [str(record) for record in dns.resolver.resolve(full_domain, 'A')]
    except: details["a_records"] = None

    try: details["aaaa_records"] = [str(record) for record in dns.resolver.resolve(full_domain, 'AAAA')]
    except: details["aaaa_records"] = None

    return details, full_domain, domain_name, top_level_domain, username

def verifier_email(email):
    api_key = '432dfd7cbfec2b733603e519786b4156a789bac3'
    url = f'https://api.hunter.io/v2/email-verifier?email={email}&api_key={api_key}'
    try:
        response = requests.get(url, headers={'Accept': 'application/json'})
        data = response.json()
        if 'data' in data and 'status' in data['data']:
            if data['data']['status'] == 'valid':
                print(Fore.WHITE + f"[+] L'adresse email {email} est valide.")
            else:
                print(Fore.WHITE + f"[-] L'adresse email {email} est invalide.")
    except Exception as err:
        print(Fore.WHITE + f"Erreur : {err}")

def menu_fin():
    print(Fore.WHITE + "\n[1] Nouvelle recherche")
    print(Fore.WHITE + "[2] Retour au menu principal")
    print(Fore.WHITE + "[3] Quitter")

    choix = input(Fore.WHITE + "\n[?] : ").strip()

    if choix == "1":
        main()
    elif choix == "2":
        return
    elif choix == "3":
        sys.exit()
    else:
        print(Fore.RED + "[!] Choix invalide.")
        menu_fin()

def main():
    logo = r"""
 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
"""
    print(logo)
    print(Fore.WHITE + "\n[1] Lance la recherche sur l'email")
    print(Fore.WHITE + "[2] Revien au Main Menu")

    choix = input(Fore.WHITE + "\n[?] : ").strip()

    if choix == "2":
        return
    elif choix != "1":
        print(Fore.RED + "[!] Choix invalide.")
        main()
        return

    email_input = input(f"\n{Fore.WHITE} C'est Quoi L'email -> {Style.RESET_ALL}")

    if not email_input:
        print(f"{Fore.WHITE}Il y a Rien Sur Cette Email.{Style.RESET_ALL}")
        menu_fin()
        return

    print(f"{Fore.WHITE}[=] Récupération des informations...{Style.RESET_ALL}")
    details, full_domain, domain_name, top_level_domain, username = fetch_email_details(email_input)

    print(f"""
{Fore.WHITE}[+] Email                 : {email_input}
{Fore.WHITE}[+] Nom d'utilisateur     : {username}
{Fore.WHITE}[+] Nom de domaine        : {domain_name}
{Fore.WHITE}[+] TLD                   : {top_level_domain}
{Fore.WHITE}[+] Domaine complet       : {full_domain}
{Fore.WHITE}[+] Enregistrements SPF   : {', '.join(details.get("spf_records", [])) if isinstance(details.get("spf_records"), list) else details.get("spf_records", "N/A")}
{Fore.WHITE}[+] Enregistrements DMARC : {', '.join(details.get("dmarc_records", [])) if isinstance(details.get("dmarc_records"), list) else details.get("dmarc_records", "N/A")}
{Fore.WHITE}[+] Enregistrements TXT   : {', '.join(details.get("txt_records", [])) if isinstance(details.get("txt_records"), list) else details.get("txt_records", "N/A")}
{Fore.WHITE}[+] Enregistrements SRV   : {', '.join(details.get("srv_records", [])) if isinstance(details.get("srv_records"), list) else details.get("srv_records", "N/A")}
{Fore.WHITE}[+] Réputation de l'email : {details.get("email_reputation", {}).get("reputation", "N/A")}
{Fore.WHITE}[+] Enregistrements A     : {', '.join(details.get("a_records", [])) if isinstance(details.get("a_records"), list) else details.get("a_records", "N/A")}
{Fore.WHITE}[+] Enregistrements AAAA  : {', '.join(details.get("aaaa_records", [])) if isinstance(details.get("aaaa_records"), list) else details.get("aaaa_records", "N/A")}
{Style.RESET_ALL}""")

    chrome_options = Options()
    chrome_options.add_experimental_option("detach", True)
    chrome_options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=chrome_options)
    driver.get("https://epieos.com")

    try:
        # Cherche le champ de recherche
        search_input = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, 'search-input'))
        )
        search_input.clear()
        search_input.send_keys(email_input)

        # Coche les CGU si présentes
        try:
            tos_checkbox = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "tos-checkbox"))
            )
            tos_checkbox.click()
        except Exception:
            pass

        # Essaie plusieurs selecteurs pour le bouton de recherche
        search_button = None
        selectors = [
            (By.XPATH, '//*[@id="search"]/main/div[6]/div[2]/div[5]/div[2]/button/span'),
            (By.XPATH, '//button[contains(@class,"search")]'),
            (By.XPATH, '//button[@type="submit"]'),
            (By.CSS_SELECTOR, 'button[type="submit"]'),
            (By.CSS_SELECTOR, '.search-btn'),
        ]
        for by, selector in selectors:
            try:
                search_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((by, selector))
                )
                search_button.click()
                break
            except Exception:
                continue

        if search_button is None:
            print(Fore.YELLOW + "[!] Bouton introuvable — clique manuellement sur Rechercher.")

        time.sleep(5)
        print(Fore.YELLOW + "T'es Un Robot ???")

        while True:
            try:
                if len(driver.window_handles) == 0:
                    break
            except Exception:
                break
            input(Fore.RED + "[!] Fermer la page chrome pour retourner au menu.")
    except Exception as e:
        print(Fore.RED + f"[!] Erreur Selenium : {e}")
    finally:
        try:
            driver.quit()
        except Exception:
            pass

    menu_fin()

if __name__ == "__main__":
    main()
