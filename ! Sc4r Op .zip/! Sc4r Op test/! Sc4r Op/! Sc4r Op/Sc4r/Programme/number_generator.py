import os
import random
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()


OPERATORS = {
    "Orange": ["0600", "0601", "0602", "0620", "0700", "0701"],
    "SFR": ["0610", "0611", "0630", "0710", "0711"],
    "Bouygues Telecom": ["0650", "0651", "0652", "0750", "0751"],
    "Free Mobile": ["0695", "0696", "0697", "0755", "0780"],
}


def main():
    print("- [1] Générer des numéros")
    print("- [2] Revenir au menu principal")
    if input().strip() != "1":
        return
    try:
        count = max(1, min(1000, int(input("Combien de numéros ? ").strip())))
    except ValueError:
        print("Nombre invalide.")
        return
    names = list(OPERATORS)
    for index, name in enumerate(names, 1):
        print(f"- [{index}] {name}")
    print(f"- [{len(names)+1}] Mixte")
    try:
        selected = int(input("Opérateur : ").strip())
    except ValueError:
        selected = len(names) + 1
    results = []
    for _ in range(count):
        operator = names[selected-1] if 1 <= selected <= len(names) else random.choice(names)
        number = random.choice(OPERATORS[operator]) + "".join(str(random.randint(0, 9)) for _ in range(6))
        results.append((number, operator))
        print(f"{number}  —  {operator}")
    folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "numeros_generes")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "numeros_generes.txt")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(number for number, _ in results))
    print(f"\nSauvegardé dans : {path}")


if __name__ == "__main__":
    main()
