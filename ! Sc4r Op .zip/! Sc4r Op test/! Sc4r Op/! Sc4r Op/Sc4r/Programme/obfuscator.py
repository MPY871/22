import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from runtime_guard import require_active
require_active()
import secrets
import string
import base64
import zlib
import marshal
import json
from pathlib import Path
from math import ceil
import sys
import time
import platform
import os
import hashlib
from time import sleep
from datetime import datetime, UTC
try:
    from Crypto.Cipher import AES
    from Crypto.Hash import HMAC, SHA256
except ImportError:
    print('Erreur: pycryptodome requis. Installe avec: pip install pycryptodome')
    sys.exit(1)
try:
    from argon2.low_level import hash_secret_raw, Type
except ImportError:
    print('Erreur: argon2-cffi requis. Installe avec: pip install argon2-cffi')
    sys.exit(1)
try:
    from colorama import init, Fore, Style
    init()
except ImportError:
    print('Erreur: colorama requis. Installe avec: pip install colorama')
    sys.exit(1)

SALT_LEN = 16
NONCE_LEN = 12
TAG_LEN = 16
ARGON_TIME = 2
ARGON_MEMORY = 65536
ARGON_PARALLELISM = 1
KEY_LEN = 32
HMAC_BLOCK = 32
ARGON_TYPE = Type.ID
UI_COLOR = Fore.WHITE
ERROR_COLOR = Fore.WHITE
RESET = Style.RESET_ALL

def rand_ident(n=10):
    alphabet = string.ascii_letters + '_'
    return secrets.choice(alphabet) + ''.join((secrets.choice(alphabet + string.digits) for _ in range(n - 1)))

def deriver_cle_argon2(mot_de_passe: str, sel: bytes) -> bytes:
    pwd_b = (mot_de_passe if mot_de_passe is not None else '').encode('utf-8')
    return hash_secret_raw(secret=pwd_b, salt=sel, time_cost=ARGON_TIME, memory_cost=ARGON_MEMORY, parallelism=ARGON_PARALLELISM, hash_len=KEY_LEN, type=ARGON_TYPE)

def flux_cle_hmac(cle: bytes, longueur: int) -> bytes:
    blocs = ceil(longueur / HMAC_BLOCK)
    sortie = bytearray()
    for i in range(blocs):
        ctr = i.to_bytes(8, 'big')
        h = HMAC.new(cle, digestmod=SHA256)
        h.update(ctr)
        sortie.extend(h.digest())
    return bytes(sortie[:longueur])

def xor_octets(a: bytes, b: bytes) -> bytes:
    return bytes((x ^ y for x, y in zip(a, b)))

def b64enc(b: bytes) -> str:
    return base64.b64encode(b).decode('ascii')

def construire_blob(code_source: str, mot_de_passe: str, requiert_mdp: bool) -> str:
    decoration = f'def _{rand_ident(8)}():\n    return {secrets.randbelow(10000)} * {secrets.randbelow(1000)}\n'
    code_source = decoration + code_source
    obj_code = compile(code_source, '<obf>', 'exec')
    marsh = marshal.dumps(obj_code)
    comp = zlib.compress(marsh, level=9)
    sel = secrets.token_bytes(SALT_LEN)
    cle = deriver_cle_argon2(mot_de_passe if mot_de_passe is not None else '', sel)
    ks = flux_cle_hmac(cle, len(comp))
    xore = xor_octets(comp, ks)
    nonce1 = secrets.token_bytes(NONCE_LEN)
    chiffre1 = AES.new(cle, AES.MODE_GCM, nonce=nonce1)
    ct1 = chiffre1.encrypt(xore)
    tag1 = chiffre1.digest()
    meta = {'names': {'crypto': base64.b64encode(b'Crypto').decode('ascii'), 'cipher': base64.b64encode(b'Cipher').decode('ascii'), 'aes': base64.b64encode(b'AES').decode('ascii')}, 'messages': {'require_password': bool(requiert_mdp), 'argon_time': ARGON_TIME, 'argon_memory': ARGON_MEMORY, 'argon_parallelism': ARGON_PARALLELISM, 'key_len': KEY_LEN}}
    meta_json = json.dumps(meta, separators=(',', ':')).encode('utf-8')
    meta_comp = zlib.compress(meta_json, level=9)
    nonce2 = secrets.token_bytes(NONCE_LEN)
    chiffre2 = AES.new(cle, AES.MODE_GCM, nonce=nonce2)
    ct2 = chiffre2.encrypt(meta_comp)
    tag2 = chiffre2.digest()
    payload = nonce1 + tag1 + ct1
    taille_payload = len(payload).to_bytes(8, 'big')
    assemble = sel + taille_payload + payload + (nonce2 + tag2 + ct2)
    return b64enc(assemble)

def creer_loader(big_b64):
    var_blob = rand_ident(8)
    loader = f'# ultra-minimal loader (packed payload)\nimport base64 as _b64, zlib as _zl, marshal as _m, sys as _sys\n'
    loader += f'{var_blob} = {repr(big_b64)}\n'
    loader += "\ndef _r():\n    try:\n        assembled = _b64.b64decode(" + var_blob + ")\n    except Exception:\n        _sys.exit('Payload corrompu')\n\n    s, n, t = "
    loader += f"{SALT_LEN}, {NONCE_LEN}, {TAG_LEN}\n"
    loader += """    salt = assembled[:s]
    payload_len = int.from_bytes(assembled[s:s+8], 'big')
    pstart, pend = s + 8, s + 8 + payload_len
    payload = assembled[pstart:pend]
    meta_blob = assembled[pend:]

    nonce1, tag1, ct1 = payload[:n], payload[n:n+t], payload[n+t:]
    nonce2, tag2, ct2 = meta_blob[:n], meta_blob[n:n+t], meta_blob[n+t:]

    try:
        from argon2.low_level import hash_secret_raw, Type as _Type
    except Exception:
        _sys.exit('argon2-cffi requis')

    pwd = ''
    def derive(p):
        return hash_secret_raw(secret=(p.encode('utf-8')), salt=salt, time_cost="""
    loader += f"{ARGON_TIME}, memory_cost={ARGON_MEMORY}, parallelism={ARGON_PARALLELISM}, hash_len={KEY_LEN}"
    loader += """, type=_Type.ID)

    key = derive(pwd)

    from Crypto.Cipher import AES as _AES
    try:
        c2 = _AES.new(key, _AES.MODE_GCM, nonce=nonce2)
        meta_comp = c2.decrypt_and_verify(ct2, tag2)
    except Exception:
        pwd = input('Entrez la cle de chiffrement: ').strip()
        key = derive(pwd)
        try:
            c2 = _AES.new(key, _AES.MODE_GCM, nonce=nonce2)
            meta_comp = c2.decrypt_and_verify(ct2, tag2)
        except Exception:
            _sys.exit('Cle invalide ou payload corrompu')

    try:
        meta_json = _zl.decompress(meta_comp)
        meta = __import__('json').loads(meta_json.decode('utf-8'))
    except Exception:
        _sys.exit('Erreur de decodage meta')

    if meta.get('flags', {}).get('require_password', False) and not pwd:
        pwd = input(_b64.b64decode(meta['messages']['prompt']).decode('utf-8')).strip()
        key = derive(pwd)

    _cipher1 = _AES.new(key, _AES.MODE_GCM, nonce=nonce1)
    try:
        xored = _cipher1.decrypt_and_verify(ct1, tag1)
    except Exception:
        _sys.exit(_b64.b64decode(meta['messages']['err_key']).decode('utf-8'))

    ln = len(xored)
    blocks = (ln + """
    loader += f"{HMAC_BLOCK} - 1) // {HMAC_BLOCK}\n"
    loader += """    out = bytearray()
    for i in range(blocks):
        ctr = i.to_bytes(8, 'big')
        from Crypto.Hash import HMAC, SHA256
        h = HMAC.new(key, digestmod=SHA256)
        h.update(ctr)
        out.extend(h.digest())
    ks = bytes(out[:ln])
    code_bytes = bytes(a ^ b for a, b in zip(xored, ks))

    try:
        marsh = _zl.decompress(code_bytes)
        code_obj = _m.loads(marsh)
        exec(code_obj, globals(), globals())
    except Exception as e:
        _sys.exit(str(e))

_r()

if __name__ == '__main__':
    pass
"""
    return loader

def main():
    RESET = "\033[0m"
    banner = r"""
 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
                           ! Sc4r
"""
    print(banner)
    print(f"""
┌──────────────────────────────────────────────────────────────────┐
│  [+] Indétectable par les antivirus                              │
│  [+] Chiffrement multicouche ultra-furtif (XOR + AES-GCM + HMAC) │
│  [+] Dérivation de clé Argon2id pour une sécurité maximale       │
│  [+] Payload compressé avec un loader minimal                    │
│  [+] Protection par mot de passe optionnelle au lancement        │
│  [+] Keystream HMAC-SHA256 pour une obfuscation avancée          │
│  [+] Conçu pour la furtivité et l'anti-rétro-ingénierie          │
└──────────────────────────────────────────────────────────────────┘
""" + RESET)

    chemin = input(UI_COLOR + 'Chemin vers le fichier Python : ' + RESET).strip()
    fichier = Path(chemin)

    if not fichier.exists() or not fichier.is_file():
        print(ERROR_COLOR + 'Erreur : Fichier introuvable' + RESET)
        return

    mdp = input(UI_COLOR + 'Clé d\'obfuscation (laisse vide => pas de mot de passe) : ' + RESET).strip()
    requiert_mdp = bool(mdp)

    try:
        src = fichier.read_text(encoding='utf-8')
        print(UI_COLOR + 'Obfuscation en cours... (cela peut prendre un moment)' + RESET)
        big_b64 = construire_blob(src, mdp if mdp else '', requiert_mdp)
        loader_code = creer_loader(big_b64)
        dossier_sortie = fichier.parent / 'output'
        dossier_sortie.mkdir(parents=True, exist_ok=True)
        sortie = dossier_sortie / f'{fichier.stem}_obf{fichier.suffix}'
        sortie.write_text(loader_code, encoding='utf-8')
        print(UI_COLOR + f'Fichier obfusqué créé : {sortie}' + RESET)
        input(UI_COLOR + 'Appuie sur Entrée pour continuer...' + RESET)
    except Exception as e:
        print(ERROR_COLOR + f'Erreur lors de la lecture du fichier : {e}' + RESET)

if __name__ == '__main__':
    if os.name == 'posix':
        os.system('clear')
    else:
        os.system('cls')
    main()
