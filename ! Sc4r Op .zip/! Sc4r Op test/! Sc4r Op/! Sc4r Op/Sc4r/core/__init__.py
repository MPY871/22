
# core/__init__.py
from .core import os, time, Fore, Style, webbrowser



