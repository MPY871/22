"""Interface web locale de Sc4r, limitée aux scripts explicitement autorisés."""
from __future__ import annotations

import json
import html as html_lib
import os
import queue
import re
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, session, url_for
from werkzeug.serving import make_server
import auth_system

ROOT = Path(__file__).resolve().parent
WINDOWS_DATA = os.environ.get("LOCALAPPDATA")
DATA_DIR = (Path(WINDOWS_DATA) if WINDOWS_DATA else Path.home() / ".local" / "share") / "SC4R"
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = DATA_DIR / "settings.json"
HISTORY_FILE = DATA_DIR / "history.json"
SESSION_TOKEN = secrets.token_urlsafe(32)
TOOLS = {
    "number-generator": ("01", "Générateur de numéros", "Génération locale de données de test", "number_generator.py"),
    "phone-lookup": ("02", "Informations numéro", "Analyse le format d'un numéro", "phone_lookup.py"),
    "dox-creator": ("03", "Créateur de dossier", "Organise les informations fournies", "doxcreater.py"),
    "ip-tool": ("04", "Informations IP", "Affiche des informations réseau", "iptool.py"),
    "port-scanner": ("05", "Scanner de ports", "Diagnostic d'une machine autorisée", "scannerport.py"),
    "obfuscator": ("06", "Obfuscateur Python", "Transforme un fichier Python local", "obfuscator.py"),
    "username-search": ("07", "Recherche de pseudo", "Recherche un nom public", "trackername.py"),
    "email-info": ("08", "Informations e-mail", "Analyse technique d'une adresse", "Emailinfo.py"),
}
DEFAULT_SETTINGS = {
    "display_name": "Utilisateur", "theme": "dark",
    "primary_color": "#7b61ff", "secondary_color": "#35cce1",
    "gradient_angle": 135, "card_opacity": 96, "sidebar_opacity": 95,
    "sidebar_width": 240, "sidebar_side": "left", "nav_spacing": 6,
    "radius": 17, "font_scale": 100, "density": "comfortable",
    "animations": True, "background_glow": True,
    "background_a": "#070b16", "background_b": "#0c1828",
    "card_a": "#121c31", "card_b": "#0d1424",
    "tool_a": "#0a101f", "tool_b": "#131d36",
    "sidebar_a": "#080d1b", "sidebar_b": "#10182b",
    "terminal_a": "#070c18", "terminal_b": "#0b1425",
    "text_color": "#eff3ff", "muted_color": "#8490ad",
    "terminal_text": "#dce4ff", "surface_angle": 145,
    "nav_order": ["dashboard", "tools", "terminal", "history", "settings"],
    "topbar_a": "#0a101f", "topbar_b": "#11182b",
    "topbar_text": "#eff3ff", "topbar_border": "#202d4b",
    "topbar_accent": "#40d7a2", "topbar_opacity": 96,
    "topbar_radius": 17, "topbar_shadow": 55, "topbar_height": 54,
    "topbar_show_brand": True, "topbar_show_local": True, "topbar_show_account": True,
}


# Version web de la recherche de pseudo. Elle produit un marqueur distinct pour
# que l'interface puisse afficher un vrai lien cliquable sous chaque résultat.
# Le fichier est généré automatiquement : l'utilisateur ne remplace toujours
# que web_app.py.
USERNAME_SEARCH_SCRIPT = r'''from concurrent.futures import ThreadPoolExecutor
import re
import sys
import webbrowser

import requests

SITES = {
    "Twitter": "https://twitter.com/{}",
    "Facebook": "https://www.facebook.com/{}",
    "Instagram": "https://www.instagram.com/{}",
    "Github": "https://github.com/{}",
    "Reddit": "https://www.reddit.com/user/{}",
    "LinkedIn": "https://www.linkedin.com/in/{}",
    "Pinterest": "https://www.pinterest.com/{}",
    "YouTube": "https://www.youtube.com/{}",
    "Vimeo": "https://vimeo.com/{}",
    "TikTok": "https://www.tiktok.com/@{}",
    "Twitch": "https://www.twitch.tv/{}",
    "SoundCloud": "https://soundcloud.com/{}",
    "Patreon": "https://www.patreon.com/{}",
    "GitLab": "https://gitlab.com/{}",
    "Spotify": "https://open.spotify.com/user/{}",
}

# Textes généralement renvoyés par les plateformes lorsqu'un profil n'existe
# plus. Le contrôle est volontairement strict afin d'éviter les faux positifs.
ABSENCE_MARKERS = (
    "page not found", "profile not found", "user not found",
    "account not found", "this account doesn’t exist",
    "this account doesn't exist", "sorry, this page isn't available",
    "sorry, this page isn’t available", "the page you requested cannot be found",
    "couldn't find this account", "couldn’t find this account",
    "ce compte n’existe pas", "ce compte n'existe pas",
    "profil introuvable", "page introuvable", "utilisateur introuvable",
)
BLOCK_MARKERS = (
    "captcha", "verify you are human", "access denied", "temporarily blocked",
    "too many requests", "rate limit", "enable javascript and cookies",
)
STRICT_SITES = {"Twitter", "Facebook", "Instagram", "LinkedIn", "TikTok", "Spotify"}


def page_confirme_profil(site, pseudo, url, reponse):
    if reponse.status_code in {404, 410}:
        return "absent"
    if reponse.status_code != 200:
        return "inconnu"

    texte = reponse.text[:1_500_000].lower()
    if any(marqueur in texte for marqueur in ABSENCE_MARKERS):
        return "absent"
    if any(marqueur in texte for marqueur in BLOCK_MARKERS):
        return "inconnu"

    # Un renvoi vers l'accueil ou la connexion n'est pas une preuve de profil.
    chemin_final = reponse.url.split("?", 1)[0].rstrip("/").lower()
    chemin_demande = url.split("?", 1)[0].rstrip("/").lower()
    if chemin_final != chemin_demande:
        if any(partie in chemin_final for partie in ("/login", "/signin", "/auth", "/404")):
            return "inconnu"
        if chemin_final.count("/") <= 2:
            return "inconnu"

    # Les sites très dynamiques renvoient parfois la même coquille HTML pour
    # tous les pseudos. On exige alors que le pseudo figure réellement dans les
    # métadonnées ou le titre de la page.
    if site in STRICT_SITES:
        pseudo_re = re.escape(pseudo.lower())
        preuves = (
            rf'<title[^>]*>[^<]*{pseudo_re}',
            rf'<meta[^>]+(?:property|name)=["\'](?:og:title|og:url|twitter:title)["\'][^>]+{pseudo_re}',
            rf'<link[^>]+rel=["\']canonical["\'][^>]+{pseudo_re}',
        )
        if not any(re.search(preuve, texte, re.I) for preuve in preuves):
            return "inconnu"

    return "trouve"


def verifier(site, modele, pseudo):
    url = modele.format(pseudo)
    try:
        reponse = requests.get(url, timeout=5, allow_redirects=True,
                               headers={"User-Agent": "Mozilla/5.0 SC4R/1.0"})
        return site, page_confirme_profil(site, pseudo, url, reponse), url
    except requests.RequestException:
        return site, "inconnu", url


def rechercher(pseudo):
    with ThreadPoolExecutor(max_workers=10) as executor:
        resultats = list(executor.map(
            lambda item: verifier(item[0], item[1], pseudo), SITES.items()
        ))
    trouves = []
    print("\nRésultats :", flush=True)
    for site, etat, url in resultats:
        if etat == "trouve":
            print(f"[+] {pseudo} trouvé sur {site}", flush=True)
            print(f"[SC4R-LINK]{site}|{url}", flush=True)
            trouves.append(url)
        elif etat == "absent":
            print(f"[-] {pseudo} non trouvé sur {site}", flush=True)
        else:
            print(f"[?] {site} : profil impossible à confirmer", flush=True)

    if trouves:
        ouvrir = input("\n[?] Ouvrir uniquement les liens trouvés ? (oui/non) : ").strip().lower()
        if ouvrir in {"oui", "o", "yes", "y"}:
            for url in trouves:
                webbrowser.open_new_tab(url)
            print(f"[+] {len(trouves)} lien(s) trouvé(s) ouvert(s).")
    else:
        print("\n[!] Aucun lien trouvé à ouvrir.")


def main():
    while True:
        print("\n- [1] Lancer une recherche")
        print("- [2] Revenir au menu principal")
        choix = input("\n[?] : ").strip()
        if choix == "2":
            return
        if choix != "1":
            print("[!] Choix invalide.")
            continue
        pseudo = input("Tu recherches qui ? : ").strip()
        if pseudo:
            rechercher(pseudo)
        else:
            print("[!] Saisis un pseudo.")


if __name__ == "__main__":
    main()
'''


class ProcessManager:
    MAX_RUNS = 2

    def __init__(self):
        self.runs = {}
        self.lock = threading.Lock()

    def start(self, tool_id):
        tool = TOOLS.get(tool_id)
        if not tool:
            return False, "Outil inconnu.", None
        if sum(r["process"].poll() is None for r in self.runs.values()) >= self.MAX_RUNS:
            return False, "Deux outils sont déjà en cours. Arrête-en un avant d'en lancer un autre.", None
        script = ROOT / "Programme" / tool[3]
        if tool_id == "username-search":
            script = DATA_DIR / "username_search_web.py"
            temporary = script.with_suffix(".tmp")
            temporary.write_text(USERNAME_SEARCH_SCRIPT, encoding="utf-8")
            temporary.replace(script)
        if not script.is_file() or script.parent != ROOT / "Programme":
            if tool_id != "username-search" or script.parent != DATA_DIR:
                return False, "Script introuvable.", None
        child_env = os.environ.copy()
        child_env.update(PYTHONIOENCODING="utf-8", PYTHONUTF8="1", SC4R_WEB_AUTH="1")
        try:
            process = subprocess.Popen([sys.executable, "-u", str(script)], cwd=str(ROOT), stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                bufsize=1, env=child_env)
        except OSError as exc:
            return False, f"Démarrage impossible : {exc}", None
        run_id = secrets.token_hex(6)
        run = {"id": run_id, "tool_id": tool_id, "tool_name": tool[1], "process": process,
               "output": queue.Queue(), "full_output": [], "started_at": datetime.now().isoformat(timespec="seconds")}
        self.runs[run_id] = run
        threading.Thread(target=self._reader, args=(run,), daemon=True).start()
        return True, f"{tool[1]} démarré.", run_id

    def _reader(self, run):
        if run["process"].stdout:
            # input() affiche son invite sans retour à la ligne. Une lecture
            # par ligne la retenait jusqu'au prochain print et collait les textes.
            while True:
                chunk = run["process"].stdout.read(1)
                if not chunk:
                    break
                run["output"].put(chunk)
                run["full_output"].append(chunk)
        self._save_history(run)

    def _save_history(self, run):
        with self.lock:
            history = load_history()
            history.insert(0, {"run_id": run["id"], "tool_id": run["tool_id"], "tool_name": run["tool_name"],
                "started_at": run["started_at"], "finished_at": datetime.now().isoformat(timespec="seconds"),
                "return_code": run["process"].poll(), "output": "".join(run["full_output"])[-50000:]})
            HISTORY_FILE.write_text(json.dumps(history[:100], ensure_ascii=False, indent=2), encoding="utf-8")

    def send(self, run_id, value):
        run = self.runs.get(run_id)
        if not run or run["process"].poll() is not None or not run["process"].stdin:
            return False, "Cet outil n'est plus en cours.", ""
        pending = []
        while True:
            try:
                pending.append(run["output"].get_nowait())
            except queue.Empty:
                break
        try:
            run["process"].stdin.write(value + "\n"); run["process"].stdin.flush()
            return True, "Entrée envoyée.", "".join(pending)
        except (BrokenPipeError, OSError):
            return False, "L'outil n'accepte plus de saisie.", "".join(pending)

    def stop(self, run_id=None):
        targets = [self.runs.get(run_id)] if run_id else list(self.runs.values())
        for run in filter(None, targets):
            if run["process"].poll() is None:
                run["process"].terminate()

    def status(self):
        result = []
        for run in self.runs.values():
            chunks = []
            while True:
                try: chunks.append(run["output"].get_nowait())
                except queue.Empty: break
            result.append({"run_id": run["id"], "tool_id": run["tool_id"], "tool_name": run["tool_name"],
                "running": run["process"].poll() is None, "output": "".join(chunks), "return_code": run["process"].poll()})
        return {"runs": result, "running_count": sum(r["running"] for r in result)}


def load_settings():
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return {**DEFAULT_SETTINGS, **{k: data[k] for k in DEFAULT_SETTINGS if k in data}}
    except (OSError, ValueError, TypeError):
        return dict(DEFAULT_SETTINGS)


def load_history():
    try:
        data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, ValueError, TypeError):
        return []


def clamp(value, minimum, maximum, fallback):
    try:
        return max(minimum, min(maximum, int(value)))
    except (TypeError, ValueError):
        return fallback


def valid_color(value, fallback):
    value = str(value)
    return value.lower() if re.fullmatch(r"#[0-9a-fA-F]{6}", value) else fallback


app = Flask(__name__, template_folder="web/templates", static_folder="web/static")
app.secret_key = secrets.token_bytes(32)
manager = ProcessManager()
PRESENCE = {"last_touch": 0.0, "last_count": 0.0, "total": 0, "online": 0}


def touch_presence(force=False):
    now = int(time.time())
    if not force and now - PRESENCE["last_touch"] < 20:
        return
    local = auth_system.load_local_account()
    if not isinstance(local, dict) or local.get("status") != "active":
        return
    try:
        auth_system.firebase_request(f"users/{auth_system.user_id()}/presence", "PUT", {
            "last_seen": now, "username": local.get("username", "Utilisateur")
        })
        PRESENCE["last_touch"] = now
    except Exception:
        pass


def user_counters(force=False):
    touch_presence(force=force)
    now = int(time.time())
    if not force and now - PRESENCE["last_count"] < 10:
        return PRESENCE["total"], PRESENCE["online"]
    try:
        users = auth_system.firebase_request("users") or {}
        if isinstance(users, dict):
            valid = [record for record in users.values() if isinstance(record, dict)]
            online = 0
            for record in valid:
                presence = record.get("presence")
                try:
                    recent = int(presence.get("last_seen", 0)) >= now - 75 if isinstance(presence, dict) else False
                except (TypeError, ValueError):
                    recent = False
                if recent and record.get("status") == "active":
                    online += 1
            PRESENCE.update(total=len(valid), online=online, last_count=now)
    except Exception:
        pass
    return PRESENCE["total"], PRESENCE["online"]


COUNTER_SCRIPT = r'''
;(()=>{const $id=id=>document.getElementById(id);function alpha(hex,opacity){const h=String(hex||'#000000').replace('#','');return '#'+h+(Math.round(Number(opacity)*2.55).toString(16).padStart(2,'0'))}function applyTopbar(s){const root=document.documentElement.style;root.setProperty('--topbar-a',alpha(s.topbar_a,s.topbar_opacity));root.setProperty('--topbar-b',alpha(s.topbar_b,s.topbar_opacity));root.setProperty('--topbar-text',s.topbar_text);root.setProperty('--topbar-border',s.topbar_border);root.setProperty('--topbar-accent',s.topbar_accent);root.setProperty('--topbar-radius',s.topbar_radius+'px');root.setProperty('--topbar-shadow','0 16px '+s.topbar_shadow+'px #0008');root.setProperty('--topbar-height',s.topbar_height+'px');document.querySelector('.sc4r-hub')?.classList.toggle('topbar-hidden',!s.topbar_show_brand);document.querySelector('.sc4r-local')?.classList.toggle('topbar-hidden',!s.topbar_show_local);document.querySelector('.sc4r-user')?.classList.toggle('topbar-hidden',!s.topbar_show_account)}async function loadTopbar(){try{const s=await fetch('/api/topbar-settings').then(r=>r.json());applyTopbar(s);const grid=document.querySelector('#settingsForm .settings-grid');if(!grid||$id('topbarSettingsCard'))return;const card=document.createElement('article');card.className='card settings-group topbar-settings-card';card.id='topbarSettingsCard';card.innerHTML='<h3>Barre supérieure</h3><div class="color-row"><label>Dégradé début<input type="color" id="tbA"></label><label>Dégradé fin<input type="color" id="tbB"></label></div><div class="color-row"><label>Texte<input type="color" id="tbText"></label><label>Bordure<input type="color" id="tbBorder"></label></div><label>Accent<input type="color" id="tbAccent"></label><label>Opacité <output id="tbOpacityOut"></output><input type="range" id="tbOpacity" min="35" max="100"></label><label>Hauteur <output id="tbHeightOut"></output><input type="range" id="tbHeight" min="44" max="90"></label><label>Arrondi <output id="tbRadiusOut"></output><input type="range" id="tbRadius" min="0" max="32"></label><label>Ombre <output id="tbShadowOut"></output><input type="range" id="tbShadow" min="0" max="90"></label><label class="switch-row"><span>Afficher le logo</span><input type="checkbox" id="tbBrand"></label><label class="switch-row"><span>Afficher Local</span><input type="checkbox" id="tbLocal"></label><label class="switch-row"><span>Afficher le compte</span><input type="checkbox" id="tbAccount"></label><button class="primary" type="button" id="tbSave">Enregistrer la barre</button>';grid.append(card);const map={tbA:'topbar_a',tbB:'topbar_b',tbText:'topbar_text',tbBorder:'topbar_border',tbAccent:'topbar_accent',tbOpacity:'topbar_opacity',tbHeight:'topbar_height',tbRadius:'topbar_radius',tbShadow:'topbar_shadow',tbBrand:'topbar_show_brand',tbLocal:'topbar_show_local',tbAccount:'topbar_show_account'};Object.entries(map).forEach(([id,key])=>{$id(id)[$id(id).type==='checkbox'?'checked':'value']=s[key]});function read(){const v={};Object.entries(map).forEach(([id,key])=>v[key]=$id(id).type==='checkbox'?$id(id).checked:($id(id).type==='range'?Number($id(id).value):$id(id).value));return v}function preview(){const v=read();$id('tbOpacityOut').textContent=v.topbar_opacity+'%';$id('tbHeightOut').textContent=v.topbar_height+' px';$id('tbRadiusOut').textContent=v.topbar_radius+' px';$id('tbShadowOut').textContent=v.topbar_shadow+'%';applyTopbar(v)}card.addEventListener('input',preview);$id('tbSave').onclick=async()=>{const r=await fetch('/api/topbar-settings',{method:'POST',headers:{'Content-Type':'application/json','X-Sc4r-Token':token},body:JSON.stringify(read())});if(r.ok)toast('Barre supérieure enregistrée.')};preview()}catch(e){}}async function refreshSc4rCounters(){try{const r=await fetch('/api/user-counters'),d=await r.json();['totalUsers','topTotal'].forEach(id=>{const n=$id(id);if(n)n.textContent=d.total??0});['onlineUsers','topOnline'].forEach(id=>{const n=$id(id);if(n)n.textContent=d.online??0})}catch(e){}}loadTopbar();refreshSc4rCounters();setInterval(refreshSc4rCounters,10000)})();
'''

LINK_SCRIPT = r'''
;(()=>{const originalShowRun=showRun;showRun=function(){originalShowRun();const output=document.getElementById('output');if(!output)return;const source=buffers.get(document.getElementById('runSelector').value)||'';if(!source.includes('[SC4R-LINK]'))return;output.textContent='';for(const line of source.split('\n')){if(line.startsWith('[SC4R-LINK]')){const value=line.slice(11),separator=value.indexOf('|'),site=separator>=0?value.slice(0,separator):'Lien',href=separator>=0?value.slice(separator+1):'';try{const parsed=new URL(href);if(!['http:','https:'].includes(parsed.protocol))throw new Error();const link=document.createElement('a');link.className='console-result-link';link.href=parsed.href;link.target='_blank';link.rel='noopener noreferrer';link.textContent='↗ Ouvrir le résultat '+site;output.append(link,document.createTextNode('\n'))}catch(e){}continue}output.append(document.createTextNode(line+'\n'))}}})();
'''

TOPBAR_STYLE = r'''
:root{--topbar-a:#0a101ff5;--topbar-b:#11182bf5;--topbar-text:#eff3ff;--topbar-border:#202d4b;--topbar-accent:#40d7a2;--topbar-radius:17px;--topbar-shadow:0 16px 55px #0008;--topbar-height:54px}.sc4r-topbar{min-height:var(--topbar-height);margin:16px 0 20px;padding:7px 10px;display:flex;align-items:center;gap:7px;overflow-x:auto;color:var(--topbar-text);border:1px solid var(--topbar-border);border-radius:var(--topbar-radius);background:linear-gradient(135deg,var(--topbar-a),var(--topbar-b));box-shadow:var(--topbar-shadow),inset 0 1px 0 #ffffff08}.sc4r-hub{display:flex;align-items:center;gap:9px;padding:0 12px 0 5px;font-weight:900;white-space:nowrap}.sc4r-hub i{width:30px;height:30px;display:grid;place-items:center;border-radius:9px;background:linear-gradient(135deg,var(--accent),var(--cyan));font-style:normal;box-shadow:0 7px 18px rgba(var(--rgb),.32)}.sc4r-topstats{margin-left:auto;display:flex;align-items:center;gap:6px}.sc4r-pill{display:flex;align-items:center;gap:7px;min-height:34px;padding:7px 11px;color:var(--topbar-text);border:1px solid var(--topbar-border);border-radius:13px;background:#11192ddd;font-size:9px;white-space:nowrap;box-shadow:0 7px 20px #0002}.sc4r-pill b{font-size:11px}.sc4r-pill.online b{color:var(--topbar-accent)}.sc4r-pill.online:before{content:'';width:7px;height:7px;border-radius:50%;background:var(--topbar-accent);box-shadow:0 0 0 4px #40d7a219}.sc4r-user{max-width:150px}.sc4r-user b{overflow:hidden;text-overflow:ellipsis}.topbar-hidden{display:none!important}.topbar-settings-card{grid-column:1/-1}.topbar-settings-card .primary{justify-self:start}@media(max-width:900px){.sc4r-topstats{margin-left:0}.sc4r-topbar{justify-content:flex-start}}@media(max-width:560px){.sc4r-pill span{display:none}.sc4r-user{display:none}}
.console-result-link{display:inline-block;margin:3px 0 7px;padding:6px 10px;border:1px solid rgba(var(--rgb),.45);border-radius:8px;background:rgba(var(--rgb),.12);color:var(--secondary);font-family:inherit;font-weight:800;text-decoration:none}.console-result-link:hover{background:rgba(var(--rgb),.22);color:var(--text);transform:translateX(2px)}
'''


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; script-src 'self'"
    if request.path == "/static/app.js" and response.status_code == 200:
        response.direct_passthrough = False
        response.set_data(response.get_data(as_text=True) + COUNTER_SCRIPT + LINK_SCRIPT)
    if request.path == "/static/style.css" and response.status_code == 200:
        response.direct_passthrough = False
        response.set_data(response.get_data(as_text=True) + TOPBAR_STYLE)
    return response


def authorized():
    return secrets.compare_digest(request.headers.get("X-Sc4r-Token", ""), SESSION_TOKEN)


@app.before_request
def enforce_account_access():
    public = {"login_page", "activate_page", "login_api", "activate_api", "static"}
    if request.endpoint in public:
        return None
    if not session.get("authenticated"):
        if request.path.startswith("/api/"):
            return jsonify(error="Connexion requise."), 401
        return redirect(url_for("login_page" if auth_system.load_local_account() else "activate_page"))
    if not auth_system.access_allowed():
        session.clear()
        if request.path.startswith("/api/"):
            return jsonify(error="Compte bloqué ou inaccessible."), 403
        return redirect(url_for("login_page", blocked="1"))


@app.get("/activate")
def activate_page():
    if auth_system.load_local_account():
        return redirect(url_for("login_page"))
    return render_template("auth.html", mode="activate", device_id=auth_system.fingerprint())


@app.post("/api/auth/activate")
def activate_api():
    data = request.get_json(silent=True) or {}
    ok, message = auth_system.activate(str(data.get("license_key", "")), str(data.get("username", "")), str(data.get("password", "")))
    if ok:
        session["authenticated"] = True
    return jsonify(ok=ok, message=message), 200 if ok else 400


@app.get("/login")
def login_page():
    if not auth_system.load_local_account():
        return redirect(url_for("activate_page"))
    return render_template("auth.html", mode="login", blocked=request.args.get("blocked") == "1")


@app.post("/api/auth/login")
def login_api():
    data = request.get_json(silent=True) or {}
    ok, message = auth_system.login(str(data.get("username", "")), str(data.get("password", "")))
    if ok:
        session["authenticated"] = True
    return jsonify(ok=ok, message=message), 200 if ok else 400


@app.post("/api/auth/logout")
def logout_api():
    try:
        auth_system.firebase_request(f"users/{auth_system.user_id()}/presence/last_seen", "PUT", 0)
    except Exception:
        pass
    session.clear()
    return jsonify(ok=True)


@app.get("/")
def index():
    total, online = user_counters(force=True)
    html = render_template("index.html")
    account = auth_system.load_local_account() or {}
    username = html_lib.escape(str(account.get("username", "Utilisateur")))
    topbar = f'''<div class="sc4r-topbar"><div class="sc4r-hub"><i>S</i><span>SC4R Hub</span></div><div class="sc4r-topstats"><div class="sc4r-pill online"><span>En ligne</span><b id="topOnline">{online}</b></div><div class="sc4r-pill"><span>Utilisateurs</span><b id="topTotal">{total}</b></div><div class="sc4r-pill sc4r-local"><span>Local</span><b>●</b></div><div class="sc4r-pill sc4r-user"><span>Compte</span><b>{username}</b></div></div></div>'''
    html = html.replace("<main>", "<main>" + topbar, 1)
    html = re.sub(r'<article class="card"><small>RÉSEAU</small>.*?</article>',
        f'<article class="card"><small>UTILISATEURS</small><strong id="totalUsers">{total}</strong><span class="cyan">Ont activé le projet</span></article>', html)
    html = re.sub(r'<article class="card"><small>LICENCE</small>.*?</article>',
        f'<article class="card"><small>EN LIGNE</small><strong id="onlineUsers">{online}</strong><span class="green">Utilisent actuellement l’outil</span></article>', html)
    return html


@app.get("/api/bootstrap")
def bootstrap():
    touch_presence(force=True)
    tools = [{"id": key, "icon": val[0], "name": val[1], "description": val[2]} for key, val in TOOLS.items()]
    return jsonify(token=SESSION_TOKEN, tools=tools, settings=load_settings())


@app.get("/api/user-counters")
def user_counter_api():
    total, online = user_counters()
    return jsonify(total=total, online=online)


TOPBAR_KEYS = (
    "topbar_a", "topbar_b", "topbar_text", "topbar_border", "topbar_accent",
    "topbar_opacity", "topbar_radius", "topbar_shadow", "topbar_height",
    "topbar_show_brand", "topbar_show_local", "topbar_show_account",
)


@app.route("/api/topbar-settings", methods=["GET", "POST"])
def topbar_settings_api():
    current = load_settings()
    if request.method == "GET":
        return jsonify({key: current[key] for key in TOPBAR_KEYS})
    if not authorized():
        return jsonify(error="Session refusée."), 403
    data = request.get_json(silent=True) or {}
    current.update({
        "topbar_a": valid_color(data.get("topbar_a"), current["topbar_a"]),
        "topbar_b": valid_color(data.get("topbar_b"), current["topbar_b"]),
        "topbar_text": valid_color(data.get("topbar_text"), current["topbar_text"]),
        "topbar_border": valid_color(data.get("topbar_border"), current["topbar_border"]),
        "topbar_accent": valid_color(data.get("topbar_accent"), current["topbar_accent"]),
        "topbar_opacity": clamp(data.get("topbar_opacity"), 35, 100, current["topbar_opacity"]),
        "topbar_radius": clamp(data.get("topbar_radius"), 0, 32, current["topbar_radius"]),
        "topbar_shadow": clamp(data.get("topbar_shadow"), 0, 90, current["topbar_shadow"]),
        "topbar_height": clamp(data.get("topbar_height"), 44, 90, current["topbar_height"]),
        "topbar_show_brand": bool(data.get("topbar_show_brand", current["topbar_show_brand"])),
        "topbar_show_local": bool(data.get("topbar_show_local", current["topbar_show_local"])),
        "topbar_show_account": bool(data.get("topbar_show_account", current["topbar_show_account"])),
    })
    temporary = SETTINGS_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(SETTINGS_FILE)
    return jsonify({key: current[key] for key in TOPBAR_KEYS})


@app.post("/api/run/<tool_id>")
def run_tool(tool_id):
    if not authorized():
        return jsonify(error="Session refusée."), 403
    ok, message, run_id = manager.start(tool_id)
    return jsonify(ok=ok, message=message, run_id=run_id), 200 if ok else 400


@app.post("/api/input")
def send_input():
    if not authorized():
        return jsonify(error="Session refusée."), 403
    data = request.get_json(silent=True) or {}
    value = str(data.get("value", ""))[:2000]
    ok, message, pending_output = manager.send(str(data.get("run_id", "")), value)
    return jsonify(ok=ok, message=message, output=pending_output), 200 if ok else 400


@app.post("/api/stop")
def stop_tool():
    if not authorized():
        return jsonify(error="Session refusée."), 403
    manager.stop(str((request.get_json(silent=True) or {}).get("run_id", "")) or None)
    return jsonify(ok=True)


@app.get("/api/status")
def process_status():
    touch_presence()
    return jsonify(manager.status())


@app.get("/api/history")
def history():
    return jsonify(history=load_history())


@app.delete("/api/history")
def clear_history():
    if not authorized():
        return jsonify(error="Session refusée."), 403
    HISTORY_FILE.write_text("[]", encoding="utf-8")
    return jsonify(ok=True)


@app.post("/api/settings")
def update_settings():
    if not authorized():
        return jsonify(error="Session refusée."), 403
    data = request.get_json(silent=True) or {}
    current_settings = load_settings()
    expected_nav = ["dashboard", "tools", "terminal", "history", "settings"]
    nav_order = data.get("nav_order")
    if not isinstance(nav_order, list) or sorted(nav_order) != sorted(expected_nav):
        nav_order = expected_nav
    settings = {
        "display_name": str(data.get("display_name", "Utilisateur"))[:32],
        "theme": data.get("theme") if data.get("theme") in {"dark", "light"} else "dark",
        "primary_color": valid_color(data.get("primary_color"), DEFAULT_SETTINGS["primary_color"]),
        "secondary_color": valid_color(data.get("secondary_color"), DEFAULT_SETTINGS["secondary_color"]),
        "gradient_angle": clamp(data.get("gradient_angle"), 0, 360, 135),
        "card_opacity": clamp(data.get("card_opacity"), 45, 100, 96),
        "sidebar_opacity": clamp(data.get("sidebar_opacity"), 45, 100, 95),
        "sidebar_width": clamp(data.get("sidebar_width"), 190, 340, 240),
        "sidebar_side": data.get("sidebar_side") if data.get("sidebar_side") in {"left", "right"} else "left",
        "nav_spacing": clamp(data.get("nav_spacing"), 0, 24, 6),
        "radius": clamp(data.get("radius"), 0, 32, 17),
        "font_scale": clamp(data.get("font_scale"), 85, 120, 100),
        "density": data.get("density") if data.get("density") in {"compact", "comfortable", "spacious"} else "comfortable",
        "animations": bool(data.get("animations", True)),
        "background_glow": bool(data.get("background_glow", True)),
        "background_a": valid_color(data.get("background_a"), DEFAULT_SETTINGS["background_a"]),
        "background_b": valid_color(data.get("background_b"), DEFAULT_SETTINGS["background_b"]),
        "card_a": valid_color(data.get("card_a"), DEFAULT_SETTINGS["card_a"]),
        "card_b": valid_color(data.get("card_b"), DEFAULT_SETTINGS["card_b"]),
        "tool_a": valid_color(data.get("tool_a"), DEFAULT_SETTINGS["tool_a"]),
        "tool_b": valid_color(data.get("tool_b"), DEFAULT_SETTINGS["tool_b"]),
        "sidebar_a": valid_color(data.get("sidebar_a"), DEFAULT_SETTINGS["sidebar_a"]),
        "sidebar_b": valid_color(data.get("sidebar_b"), DEFAULT_SETTINGS["sidebar_b"]),
        "terminal_a": valid_color(data.get("terminal_a"), DEFAULT_SETTINGS["terminal_a"]),
        "terminal_b": valid_color(data.get("terminal_b"), DEFAULT_SETTINGS["terminal_b"]),
        "text_color": valid_color(data.get("text_color"), DEFAULT_SETTINGS["text_color"]),
        "muted_color": valid_color(data.get("muted_color"), DEFAULT_SETTINGS["muted_color"]),
        "terminal_text": valid_color(data.get("terminal_text"), DEFAULT_SETTINGS["terminal_text"]),
        "surface_angle": clamp(data.get("surface_angle"), 0, 360, 145),
        "nav_order": nav_order,
    }
    settings.update({key: current_settings[key] for key in TOPBAR_KEYS})
    temporary = SETTINGS_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(SETTINGS_FILE)
    return jsonify(ok=True, settings=settings)


if __name__ == "__main__":
    # Le port 0 demande à Windows de choisir automatiquement un port local
    # disponible. Cela évite les ports réservés ou bloqués comme 5000.
    server = make_server("127.0.0.1", 0, app, threaded=True)
    url = f"http://127.0.0.1:{server.server_port}"
    print(f"Sc4r Web : {url}")
    print("Ouverture du navigateur...")
    threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt de Sc4r Web.")
    finally:
        manager.stop()
        server.shutdown()
