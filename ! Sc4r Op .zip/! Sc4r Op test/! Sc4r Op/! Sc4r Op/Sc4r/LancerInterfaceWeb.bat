@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_CMD="
py -3.12 --version >nul 2>&1 && set "PYTHON_CMD=py -3.12"
if not defined PYTHON_CMD python --version >nul 2>&1 && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    echo ERREUR : Python est introuvable.
    echo Installe Python 3.12 puis relance ce fichier.
    pause
    exit /b 1
)

%PYTHON_CMD% -c "import flask" >nul 2>&1
if errorlevel 1 (
    echo Installation de Flask...
    %PYTHON_CMD% -m pip install "Flask>=3.1,<4"
    if errorlevel 1 (
        echo ERREUR : Flask n'a pas pu etre installe.
        pause
        exit /b 1
    )
)

echo Demarrage de Sc4r Web...
echo Ne ferme pas cette fenetre pendant l'utilisation.
%PYTHON_CMD% "%~dp0web_app.py"
echo.
echo Le serveur s'est arrete. Le message ci-dessus indique la cause.
pause
