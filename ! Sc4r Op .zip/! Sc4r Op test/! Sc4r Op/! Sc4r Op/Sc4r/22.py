import Programme.iptool as iptool
import Programme.doxcreater as doxcreater
import Programme.Emailinfo as EmailInfo
import Programme.trackername as trackername
import Programme.grabber as grabber
import Programme.scannerport as scannerport
import Programme.obfuscator as obfuscator
import phonenumbers
import os
import time
import requests
import random
import csv
import sys 
import re
import shutil
import pystyle
import uuid
import hashlib
import platform
import subprocess
from io import StringIO
from phonenumbers import carrier, geocoder, timezone
from core.core import Fore, Style, webbrowser
from rich.console import Console
from colorama import init
from pathlib import Path 
import licence
import subprocess

def _fingerprint():
    data = (
        str(uuid.getnode()) +
        platform.system() +
        platform.processor() +
        platform.version()
    )
    return hashlib.sha256(data.encode()).hexdigest()

print("=" * 40)
print(f"Votre ID Machine : {_fingerprint()}")
print("Envoyez cet ID à sc4r pour obtenir votre licence.")
print("=" * 40)

licence.ask_license()


webbrowser.open("https://guns.lol/sc4r./")
webbrowser.open("https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047052655")

console = Console()

def clear_screen():
    if os.name == "posix":
        os.system("clear")
    else:
        os.system("cls")


def get_phone_info(phone_number):
    try:
        parsed_number = phonenumbers.parse(phone_number, None)

        if not phonenumbers.is_valid_number(parsed_number):
            print('Invalid')
            input()
            return

        status = 'Valid'
        country_code = f'+{parsed_number.country_code}' if parsed_number.country_code else 'None'
        operator = carrier.name_for_number(parsed_number, 'fr') or 'None'
        number_type = phonenumbers.number_type(parsed_number)
        type_number = 'Mobile' if number_type == phonenumbers.PhoneNumberType.MOBILE else 'Fixe'
        timezones = timezone.time_zones_for_number(parsed_number)
        timezone_info = timezones[0] if timezones else 'None'
        country = phonenumbers.region_code_for_number(parsed_number) or 'None'
        region = geocoder.description_for_number(parsed_number, 'fr') or 'None'
        formatted_number = phonenumbers.format_number(
            parsed_number,
            phonenumbers.PhoneNumberFormat.NATIONAL
        ) or 'None'

        print(f'''
[+] Status       : {status}
[+] Formatted    : {formatted_number}
[+] Country Code : {country_code}
[+] Country      : {country}
[+] Region       : {region}
[+] Timezone     : {timezone_info}
[+] Operator     : {operator}
[+] Type Number  : {type_number}
''')

        input()

    except Exception:
        print('[+] Invalid format !')
        input()


class PhoneNumberGenerator:
    def __init__(self):
        self.operators_data = {}
        self.load_default_data()
        self.load_arcep_data()

    def get_operators(self) -> list[str]:
        return sorted(self.operators_data.keys())

    def load_arcep_data(self):
        api_url = "https://www.data.gouv.fr/api/1/datasets/ressources-en-numerotation-telephonique/"
        try:
            response = requests.get(api_url, timeout=10)
            response.raise_for_status()
            dataset = response.json()

            csv_url = None
            for resource in dataset.get("resources", []):
                if "mobile" in resource.get("title", "").lower() or "E164" in resource.get("title", ""):
                    csv_url = resource.get("url")
                    break

            if csv_url:
                self.parse_csv_data(csv_url)
        except Exception:
            pass

    def parse_csv_data(self, csv_url: str):
        try:
            response = requests.get(csv_url, timeout=10)
            response.encoding = "latin-1"
            csv_content = StringIO(response.text)
            reader = csv.DictReader(csv_content, delimiter=";")
            for row in reader:
                numero = row.get("Numero", "") or row.get("numero", "")
                operateur = row.get("Operateur", "") or row.get("operateur", "")
                if numero and operateur and (numero.startswith("06") or numero.startswith("07") or numero.startswith("09")):
                    prefix = numero[:4]
                    self.operators_data.setdefault(operateur, [])
                    if prefix not in self.operators_data[operateur]:
                        self.operators_data[operateur].append(prefix)
        except Exception:
            pass

    def load_default_data(self):
        self.operators_data = {
            "Orange": ["0600", "0601", "0602", "0603", "0620", "0621", "0622", "0623", "0700", "0701", "0702", "0703"],
            "SFR": ["0610", "0611", "0612", "0613", "0630", "0631", "0632", "0633", "0710", "0711", "0712", "0713"],
            "Bouygues Telecom": ["0650", "0651", "0652", "0653", "0654", "0655", "0656", "0657", "0658", "0659", "0750", "0751", "0752", "0753"],
            "Free Mobile": ["0695", "0696", "0697", "0698", "0699", "0755", "0756", "0757", "0758", "0780", "0781", "0782", "0783"],
            "La Poste Mobile": ["0630", "0631", "0632"],
            "NRJ Mobile": ["0670", "0671", "0672"],
            "Prixtel": ["0688", "0689"],
            "Coriolis": ["0760", "0761", "0762"],
        }

    def generate_number(self, operator: str = None) -> str:
        chosen_operator = operator if operator in self.operators_data else random.choice(list(self.operators_data.keys()))
        prefix = random.choice(self.operators_data[chosen_operator])
        remaining = "".join(str(random.randint(0, 9)) for _ in range(6))
        return f"{prefix}{remaining}"

    def generate_batch(self, count: int, operator: str = None) -> list[tuple]:
        results = []
        for _ in range(count):
            chosen_operator = operator if operator and operator != "mixte" else random.choice(list(self.operators_data.keys()))
            results.append((self.generate_number(chosen_operator), chosen_operator))
        return results


def main_menu():
    first_run = True

    while True:
        if first_run:
            choix = input("Tu Veux Rentrer Ta Grande Mere ? (y/n) : ")
            if choix.lower() == "y":
                print("Azy Toi Ta Quelqun A Bz ")
            elif choix.lower() == "n":
                print("Tes Un Bizzare Pourquoi Tu Me Lance Alors ? ")
                break
            else:
                print("Tes Con Ou Quoi!?")
            first_run = False

        logo = r"""
        
 _________    ___      ___   _____     
|  _   _  | .'   `.  .'   `.|_   _|    
|_/ | | \_|/  .-.  \/  .-.  \ | |      
    | |    | |   | || |   | | | |   _  
   _| |_   \  `-'  /\  `-'  /_| |__/ | 
  |_____|   `.___.'  `.___.'|________|   
  _   ____     ____   _  _     ____  
 | | / ___|   / ___| | || |   |  _ \ 
 | | \___ \  | |     | || |_  | |_) |
 |_|  ___) | | |___  |__   _| |  _ < 
 (_) |____/   \____|    |_|   |_| \_\

"""

        for ligne in logo.splitlines():
            console.print(ligne)
            time.sleep(0.05)
        
        print("\nMenu : ")
        print("1 - Lancer Le Generateur De Numeros ")
        print("2 - Lookup Num ")
        print("3 - doxcreater ")
        print("4 - Scan Ip ")
        print("5 - Later ")
        print("6 - PortScanner ")
        print("7 - obfuscator ")         
        print("8 - trackerName ")
        print("9 - EmailInfo ")
        print("10 - Quitter ")
        choix = input("Alors!? ")

        if choix == "1":
            menu_gen()
        elif choix == "2":
            clear_screen()
            print(Fore.LIGHTWHITE_EX + "Phone LOOKUP\n ")
            tel = input("[+] Phone Number (ex: +33658182243) : ")
            get_phone_info(tel)
        elif choix == "3":
            doxcreater.main()
        elif choix == "4":
            iptool.main()
        elif choix == "6":
         scannerport.main()
        elif choix == "7":
         obfuscator.main()
        elif choix == "8":
         trackername.main()
        elif choix == "9":
         EmailInfo.main()
        elif choix == "10":
            print("Au revoir !")
            break
        else:
            print("Choix invalide.")
            time.sleep(1)


def menu_gen():
    gen = PhoneNumberGenerator()
    operators = gen.get_operators()

    logo = r"""
 _   ____     ____   _  _     ____  
| | / ___|   / ___| | || |   |  _ \ 
| | \___ \  | |     | || |_  | |_) |
|_|  ___) | | |___  |__   _| |  _ < 
(_) |____/   \____|    |_|   |_| \_\
"""
    print(Fore.WHITE + logo)

    while True:
        print("\n=== GENERATEUR DE NUMEROS ===")
        print("1 - Generer des numeros")
        print("2 - Retour au menu principal")
        choix = input("Choix : ").strip()

        if choix == "1":
            while True:
                try:
                    count = int(input("Combien de numeros voulez-vous generer ? ").strip())
                    if count <= 0:
                        print("Entrez un nombre positif.")
                        continue
                    break
                except ValueError:
                    print("Entrez un nombre valide.")

            print("\nOperateurs disponibles :")
            for i, op in enumerate(operators, 1):
                print(f"{i}. {op}")
            print(f"{len(operators)+1}. MIXTE (tous operateurs)")

            while True:
                try:
                    op_choice = int(input(f"Quel operateur ? (1-{len(operators)+1}): ").strip())
                    if op_choice == len(operators)+1:
                        selected_operator = "mixte"
                        break
                    elif 1 <= op_choice <= len(operators):
                        selected_operator = operators[op_choice-1]
                        break
                    else:
                        print(f"Choisissez entre 1 et {len(operators)+1}.")
                except ValueError:
                    print("Entrez un nombre valide.")

            results = gen.generate_batch(count, selected_operator)

            print("\nNumeros generes :")
            for i, (num, op) in enumerate(results, 1):
                if selected_operator == "mixte":
                    print(f"{i:3d}. {num} -> {op}")
                else:
                    print(f"{i:3d}. {num}")

            save_folder = os.path.join(os.getcwd(), "numeros_generes")
            os.makedirs(save_folder, exist_ok=True)

            filename = input("\nNom du fichier (sans extension) : ").strip() or "numeros_generes"
            full_path = os.path.join(save_folder, f"{filename}.txt")

            try:
                with open(full_path, "w", encoding="utf-8") as f:
                    for num, op in results:
                        f.write(f"{num}\n")
                print(f"Fichier sauvegarde dans : {full_path}")
            except Exception as e:
                print(f"Erreur lors de la sauvegarde : {e}")

        elif choix == "2":
            break
        else:
            print("Choix invalide.")


if __name__ == "__main__":
    main_menu()
