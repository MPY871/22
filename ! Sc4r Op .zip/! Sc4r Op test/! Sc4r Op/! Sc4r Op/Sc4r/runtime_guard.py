"""Contrôle de statut partagé par les scripts distribués."""
import sys

import auth_system


def require_active():
    if not auth_system.load_local_account():
        print("Accès refusé : cette installation n'est pas activée.")
        raise SystemExit(1)
    if not auth_system.access_allowed():
        print("Accès refusé : compte bloqué ou Firebase inaccessible.")
        raise SystemExit(1)
