# Vérifications et éléments restant à valider

Préparation du 4 octobre 2026.

## Effectué dans l’environnement de préparation

| Vérification | Résultat |
| --- | --- |
| Analyse syntaxique des 14 fichiers Swift par le parseur Swift tree-sitter | Aucun nœud d’erreur syntaxique détecté. Ce contrôle ne résout pas les types Swift ni les API Apple. |
| Lecture du fichier `project.pbxproj` par un parseur de projet Xcode | Projet lisible avec une app, une cible de tests unitaires et une cible de tests d’interface. |
| Présence des fichiers référencés, des ressources, du schéma et du workspace | Références présentes, JSON/plist/XML lisibles. |
| Opérateurs du générateur | Dictionnaire exactement égal au jeu de secours du `number_generator.py` de référence ; huit opérateurs. |
| Icône de l’app | PNG RGB de 1 024 × 1 024 pixels sans canal alpha, créé à partir du signe vectoriel natif. |
| Workflows de compilation | YAML lisible ; scripts Bash et Python inclus syntaxiquement valides. Déclenchement manuel et runner `macos-26`. Aucun lancement distant effectué. |
| Choix automatique du simulateur | Contrôle avec une liste d’exemple et du cas sans runtime iPhone disponible. |
| Service IP | Requête HTTPS vers ipwho.is pour l’IP d’exemple `8.8.8.8` : HTTP 200, succès, ASN entier et identifiant de fuseau. Vérification du contrat de réponse, hors app iOS. |
| Service DNS | Requête HTTPS MX pour `example.org` : HTTP 200, statut DNS entier et données de réponse de type chaîne. Vérification du contrat de réponse, hors app iOS. |
| Dépendance téléphonique | Version 5.0.11 et révision vérifiées sur le dépôt officiel ; API de parsing et enum `fixedOrMobile` vérifiées ; licence incluse. |

## Préparé, non exécuté

Les **27 tests XCTest/XCUITest** suivants sont inclus. Ils seront exécutés par `scripts/build-ios.sh` et par les workflows, avant de produire une IPA.

| Suite | Tests inclus | Couverture prévue |
| --- | --- | --- |
| GeneratorTests | 8 | Pas de résultats avant le choix opérateur ; quantité invalide ; retour ; remise à zéro ; 1 000 numéros uniques ; mixte ; préfixes invalides ; ressource opérateurs embarquée. |
| PersistenceTests | 10 | Profil/journal/fiches après relecture ; photo après relance ; suppression persistante ; réduction d’image ; échec de sauvegarde ; profil illisible sauvegardé à part ; modification de fiche ; limites du journal ; import indépendant de l’écran ; protection contre les anciens imports. |
| ToolTests | 7 | Fusion/doublons ; recherche sans distinction d’accent/casse ; export JSON ; validation de ports et d’email ; parsing de numéros ; annulation et résultat récent. |
| GeneratorFlowTests | 2 | Navigation réelle quantité → opérateur → résultats ; retour à la quantité ; captures de l’interface via XCTest. |

## Non validé à ce stade

- Compilation et résolution des types Swift avec le SDK iOS : Xcode n’est pas disponible dans cet environnement.
- Exécution des tests natifs, affichage sur simulateur, Dynamic Type et mise en page sur appareils de différentes tailles.
- Sélection d’une photo réelle, changements d’onglet pendant son import et persistance après fermeture forcée sur un iPhone.
- Autorisation réseau local, état des connexions TCP et services Internet depuis iOS.
- Import iCloud/Fichiers, extraction PDF réelle et export vers Fichiers/partage sur l’appareil.
- Signature Apple, export signé, traitement App Store Connect et installation TestFlight.

Il faut encore connecter un compte de compilation, exécuter la compilation et ces contrôles, corriger les éventuelles erreurs natives révélées, puis signer et installer l’app. **Aucun résultat XCTest réussi, binaire compilé, profil signé ou lien TestFlight ne doit être déduit des contrôles locaux.**
