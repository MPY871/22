import XCTest
@testable import SC4R

final class ToolTests: XCTestCase {
    private let files = [
        ImportedText(name: "a.txt", text: "Alice\nBenoît\nAlice\n", sha256: "a", byteCount: 23),
        ImportedText(name: "b.txt", text: "Benoît\nChloé\n", sha256: "b", byteCount: 15)
    ]

    func testMergePreservesOrderAndOptionalDuplicates() {
        XCTAssertEqual(FileTools.merge(files, unique: true), "Alice\nBenoît\nChloé")
        XCTAssertEqual(FileTools.merge(files, unique: false), "Alice\nBenoît\nAlice\nBenoît\nChloé")
        XCTAssertTrue(FileTools.duplicates(files).contains("2 occurrences — Alice"))
        XCTAssertTrue(FileTools.duplicates(files).contains("2 occurrences — Benoît"))
    }

    func testSearchIgnoresAccentsAndReportsOriginalLineNumber() throws {
        let result = try FileTools.search(files, term: "BENOIT")
        XCTAssertTrue(result.contains("a.txt:2 — Benoît"))
        XCTAssertTrue(result.contains("b.txt:1 — Benoît"))
        XCTAssertEqual(try FileTools.search(files, term: "absent"), "Aucun résultat.")
        XCTAssertThrowsError(try FileTools.search(files, term: "  "))
    }

    func testJSONExportRetainsTextAndNames() throws {
        let data = Data(try FileTools.json(files).utf8)
        let result = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: [[String: String]]])
        XCTAssertEqual(result["files"]?.count, 2)
        XCTAssertEqual(result["files"]?.first?["text"], files[0].text)
        XCTAssertEqual(result["files"]?.first?["name"], "a.txt")
    }

    func testPortsAreValidatedDeduplicatedAndBounded() throws {
        XCTAssertEqual(try PortService.parse("443,22,80,22,8000-8002"), [22,80,443,8000,8001,8002])
        XCTAssertEqual(try PortService.parse("1-256").count, 256)
        for value in ["", "0", "65536", "3-1", "1-257", "a", "22,,80", "22,"] {
            XCTAssertThrowsError(try PortService.parse(value), value)
        }
    }

    func testEmailDomainValidationAndNormalization() throws {
        XCTAssertEqual(try EmailService.domain("  alice@EXEMPLE.FR  "), "exemple.fr")
        for value in ["@exemple.fr", "alice@", "alice", "alice@@exemple.fr", "alice@-test.fr", "alice@test..fr", "alice@te st.fr", "al ice@test.fr"] {
            XCTAssertThrowsError(try EmailService.domain(value), value)
        }
    }

    @MainActor
    func testPhoneLookupUsesInternationalAndDefaultCountry() throws {
        let lookup = PhoneLookup.shared
        XCTAssertTrue(try lookup.lookup("+33 6 89 01 73 83", region: "FR").contains("+33689017383"))
        XCTAssertTrue(try lookup.lookup("06 89 01 73 83", region: "FR").contains("+33689017383"))
        XCTAssertThrowsError(try lookup.lookup("invalid", region: "FR"))
    }

    @MainActor
    func testCancellationCannotReplaceNewerNetworkResult() async throws {
        let runner = NetworkRunner()
        var staleWasRecorded = false
        runner.run(operation: {
            try await Task.sleep(nanoseconds: 150_000_000)
            return "old"
        }) { _ in staleWasRecorded = true }
        runner.run(operation: { "new" }) { _ in }
        try await Task.sleep(nanoseconds: 220_000_000)
        XCTAssertEqual(runner.text, "new")
        XCTAssertFalse(runner.busy)
        XCTAssertFalse(staleWasRecorded)
        XCTAssertNil(runner.error)
    }
}
