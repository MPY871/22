import XCTest
import UIKit
@testable import SC4R

@MainActor
final class PersistenceTests: XCTestCase {
    private func root() -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("sc4r-tests-\(UUID().uuidString)", isDirectory: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }

    private func photo(_ color: UIColor = .purple, size: CGSize = CGSize(width: 32, height: 32)) -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).pngData { ctx in
            color.setFill(); ctx.cgContext.fill(CGRect(origin: .zero, size: size))
        }
    }

    func testProfileHistoryAndDossierSurviveReload() throws {
        let url = root(); let first = AppStore(root: url)
        first.updateProfile(name: "Alice", theme: "dark")
        XCTAssertTrue(first.record(tool: 1, title: "Exemple", text: "0607000000"))
        let dossier = Dossier(title: "Fiche", values: ["Notes": "Texte enregistré"])
        XCTAssertTrue(first.saveDossier(dossier))
        let second = AppStore(root: url)
        XCTAssertNil(second.error)
        XCTAssertEqual(second.state.name, "Alice")
        XCTAssertEqual(second.state.theme, "dark")
        XCTAssertEqual(second.state.history, first.state.history)
        XCTAssertEqual(second.state.dossiers, [dossier])
    }

    func testPhotoSurvivesNewAppStoreAndDeletionIsPersistent() throws {
        let url = root(); let normalized = try DiskStore.normalizePhoto(photo())
        let first = AppStore(root: url); first.saveAvatar(normalized)
        XCTAssertNil(first.error)
        let reopened = AppStore(root: url)
        XCTAssertEqual(reopened.avatarData, normalized)
        XCTAssertNotNil(reopened.avatarData.flatMap { UIImage(data: $0) })
        reopened.removeAvatar()
        XCTAssertNil(AppStore(root: url).avatarData)
        XCTAssertFalse(FileManager.default.fileExists(atPath: url.appendingPathComponent("avatar.jpg").path))
    }

    func testLargePhotoIsResizedAndBadDataIsRejected() throws {
        let normalized = try DiskStore.normalizePhoto(photo(size: CGSize(width: 2048, height: 1024)))
        let image = try XCTUnwrap(UIImage(data: normalized))
        XCTAssertLessThanOrEqual(max(image.size.width, image.size.height), 768)
        XCTAssertThrowsError(try DiskStore.normalizePhoto(Data("not a photo".utf8)))
    }

    func testFailedWriteDoesNotPublishUnsavedProfileOrPhoto() throws {
        let url = root(); let store = AppStore(root: url)
        try FileManager.default.createDirectory(at: url.appendingPathComponent("profile.json"), withIntermediateDirectories: true)
        store.updateProfile(name: "Unsaved", theme: "dark")
        XCTAssertEqual(store.state.name, "Utilisateur")
        XCTAssertNotNil(store.error)
        let good = try DiskStore.normalizePhoto(photo())
        store.saveAvatar(good)
        XCTAssertEqual(store.avatarData, good)
        try FileManager.default.removeItem(at: url.appendingPathComponent("avatar.jpg"))
        try FileManager.default.createDirectory(at: url.appendingPathComponent("avatar.jpg"), withIntermediateDirectories: true)
        store.saveAvatar(try DiskStore.normalizePhoto(photo(.red)))
        XCTAssertEqual(store.avatarData, good, "A failed save must not display a photo which was not stored")
    }

    func testUnreadableProfileIsBackedUpBeforeNewSave() throws {
        let url = root(); let disk = try DiskStore(root: url)
        let original = Data("{broken json".utf8)
        try original.write(to: disk.stateURL)
        let store = AppStore(root: url)
        XCTAssertNotNil(store.error)
        let backups = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("profile-backup-") }
        XCTAssertEqual(backups.count, 1)
        XCTAssertEqual(try Data(contentsOf: XCTUnwrap(backups.first)), original)
        store.updateProfile(name: "Restored", theme: "system")
        XCTAssertEqual(try disk.load().name, "Restored")
        XCTAssertEqual(try Data(contentsOf: XCTUnwrap(backups.first)), original)
    }

    func testDossierEditUpdatesExistingRecord() {
        let store = AppStore(root: root())
        var dossier = Dossier(title: "Avant", values: ["Notes": "A"])
        XCTAssertTrue(store.saveDossier(dossier))
        dossier.title = "Après"; dossier.values["Notes"] = "B"
        XCTAssertTrue(store.saveDossier(dossier))
        XCTAssertEqual(store.state.dossiers, [dossier])
    }

    func testHistoryHasBoundedLength() {
        let store = AppStore(root: root())
        for index in 0..<65 { store.record(tool: 1, title: "\(index)", text: "test") }
        XCTAssertEqual(store.state.history.count, 60)
        XCTAssertEqual(store.state.history.first?.title, "64")
        store.record(tool: 5, title: "Long", text: String(repeating: "a", count: 60_000))
        XCTAssertTrue(store.state.history[0].text.contains("aperçu limité"))
        XCTAssertLessThan(store.state.history[0].text.count, 51_000)
    }

    func testPhotoImportOutlivesCallerAndIsStored() async throws {
        let url = root(); let store = AppStore(root: url); let data = photo()
        store.importAvatar { data }
        try await waitUntil { !store.avatarSaving }
        XCTAssertNil(store.error)
        XCTAssertNotNil(AppStore(root: url).avatarData)
    }

    func testRemovalCannotBeUndoneByAnOlderPhotoImport() async throws {
        let url = root(); let store = AppStore(root: url); let data = photo()
        var continuation: CheckedContinuation<Data?, Error>?
        store.importAvatar {
            try await withCheckedThrowingContinuation { continuation = $0 }
        }
        try await waitUntil { continuation != nil }
        store.removeAvatar()
        continuation?.resume(returning: data)
        try await Task.sleep(nanoseconds: 80_000_000)
        XCTAssertNil(store.avatarData)
        XCTAssertNil(AppStore(root: url).avatarData)
        XCTAssertFalse(store.avatarSaving)
    }

    func testNewPhotoSupersedesSlowOlderSelection() async throws {
        let url = root(); let store = AppStore(root: url)
        let old = photo(.red), new = photo(.blue)
        var continuation: CheckedContinuation<Data?, Error>?
        store.importAvatar { try await withCheckedThrowingContinuation { continuation = $0 } }
        try await waitUntil { continuation != nil }
        store.importAvatar { new }
        try await waitUntil { !store.avatarSaving }
        let expected = try DiskStore.normalizePhoto(new)
        continuation?.resume(returning: old)
        try await Task.sleep(nanoseconds: 80_000_000)
        XCTAssertEqual(store.avatarData, expected)
        XCTAssertEqual(AppStore(root: url).avatarData, expected)
    }

    private func waitUntil(_ condition: () -> Bool) async throws {
        for _ in 0..<300 {
            if condition() { return }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTFail("The asynchronous photo operation did not complete")
        throw AppError.message("Test timeout")
    }
}
