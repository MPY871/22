import XCTest
@testable import SC4R

@MainActor
final class GeneratorTests: XCTestCase {
    private let sample = ["Orange": ["0607", "0610"], "SFR": ["0612"]]

    func testResultsRequireQuantityThenOperatorChoice() throws {
        let model = GeneratorModel()
        XCTAssertEqual(model.step, .quantity)
        XCTAssertThrowsError(try model.choose("Orange", operators: sample))
        XCTAssertTrue(model.results.isEmpty)
        model.quantity = "5"
        try model.next()
        XCTAssertEqual(model.step, .operatorChoice)
        XCTAssertTrue(model.results.isEmpty, "Going to the operator menu must not generate results")
        try model.choose("Orange", operators: sample)
        XCTAssertEqual(model.step, .results)
        XCTAssertEqual(model.results.count, 5)
        XCTAssertTrue(model.results.allSatisfy { $0.operatorName == "Orange" })
        XCTAssertThrowsError(try model.choose("SFR", operators: sample))
        XCTAssertEqual(model.results.count, 5)
    }

    func testInvalidQuantitiesStayAtFirstStep() {
        for value in ["", "0", "-1", "1001", "1.5", "abc"] {
            let model = GeneratorModel(); model.quantity = value
            XCTAssertThrowsError(try model.next(), value)
            XCTAssertEqual(model.step, .quantity)
            XCTAssertTrue(model.results.isEmpty)
        }
    }

    func testFailedOperatorDoesNotChangeScreen() throws {
        let model = GeneratorModel(); try model.next()
        XCTAssertThrowsError(try model.choose("Unknown", operators: sample))
        XCTAssertEqual(model.step, .operatorChoice)
        XCTAssertTrue(model.results.isEmpty)
    }

    func testBackAllowsQuantityChangeAndResetClearsResults() throws {
        let model = GeneratorModel(); try model.next(); model.back()
        XCTAssertEqual(model.step, .quantity)
        model.quantity = "3"; try model.next(); try model.choose(nil, operators: sample)
        XCTAssertEqual(model.results.count, 3)
        model.reset()
        XCTAssertEqual(model.step, .quantity)
        XCTAssertTrue(model.results.isEmpty)
        try model.next()
        XCTAssertEqual(model.step, .operatorChoice)
        XCTAssertTrue(model.results.isEmpty)
    }

    func testMaximumQuantityIsUniqueAndUsesSelectedPrefixes() throws {
        let results = try NumberGenerator.generate(count: 1000, operatorName: "Orange", operators: sample)
        XCTAssertEqual(results.count, 1000)
        XCTAssertEqual(Set(results.map(\.number)).count, 1000)
        for number in results {
            XCTAssertEqual(number.number.count, 10)
            XCTAssertTrue(sample["Orange"]!.contains(String(number.number.prefix(4))))
            XCTAssertTrue(number.number.unicodeScalars.allSatisfy { (48...57).contains($0.value) })
        }
    }

    func testMixedNumbersKeepCorrectOperatorLabels() throws {
        let results = try NumberGenerator.generate(count: 80, operatorName: nil, operators: sample)
        for number in results { XCTAssertTrue(sample[number.operatorName]!.contains(String(number.number.prefix(4)))) }
    }

    func testInvalidPrefixDataIsRejected() {
        for values in [[String: [String]](), ["Orange": []], ["Orange": ["123"]], ["Orange": ["abcd"]], ["Orange": ["٠٦٠٧"]]] {
            XCTAssertThrowsError(try NumberGenerator.generate(count: 1, operatorName: nil, operators: values))
        }
        XCTAssertThrowsError(try NumberGenerator.generate(count: 0, operatorName: nil, operators: sample))
        XCTAssertThrowsError(try NumberGenerator.generate(count: 1001, operatorName: nil, operators: sample))
    }

    func testOriginalOperatorResourceIsBundled() throws {
        XCTAssertEqual(NumberGenerator.operators.count, 8)
        XCTAssertTrue(NumberGenerator.operators.keys.contains("Orange"))
        for name in NumberGenerator.operators.keys {
            XCTAssertEqual(try NumberGenerator.generate(count: 1, operatorName: name).count, 1)
        }
    }
}
