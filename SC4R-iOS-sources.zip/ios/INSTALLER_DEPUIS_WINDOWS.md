# Installer SC4R sur un iPhone depuis Windows

**À ce stade il faut encore compiler, tester et signer l’application. Le ZIP source ne s’installe pas directement sur un iPhone.** Aucune IPA ni invitation TestFlight n’a été créée ici.

## La voie adaptée à l’utilisation sans PC : TestFlight

L’application elle-même n’a pas besoin du PC. TestFlight permet également de l’installer et de recevoir les mises à jour sur l’iPhone sans renouvellement hebdomadaire depuis Windows. Il faut un compte **Apple Developer Program**, une fiche App Store Connect et une compilation/signature sur un Mac distant. Une build TestFlight expire après 90 jours : il faut ensuite une nouvelle build. Une distribution finale sur l’App Store nécessite une soumission distincte.

Les workflows du projet utilisent le runner GitHub **macos-26**. Ils sont préparés mais n’ont pas été exécutés. Une connexion au compte GitHub et des éléments de signature Apple sont encore nécessaires. Le lancement consomme les minutes GitHub Actions de ton compte selon ton forfait.

1. Créer un dépôt privé GitHub et y envoyer **le contenu du dossier `SC4R-iOS` uniquement**, y compris `.github`, `SC4R.xcodeproj`, `SC4R`, les tests et `scripts`. La racine du dépôt doit contenir `SC4R.xcodeproj`, pas un dossier parent supplémentaire. Ne pas y envoyer l’archive Python de référence.
2. Dans l’onglet **Actions**, lancer **Compiler et tester SC4R iPhone** avec **Run workflow**. Attendre que les tests de simulateur et la compilation passent. En cas d’échec, les fichiers de résultat et les journaux sont disponibles dans l’artefact **SC4R-tests-natifs**. Le premier objectif est de corriger les erreurs réelles de compilation ou de tests avant installation.
3. Dans le portail Apple Developer, enregistrer un identifiant d’app explicite et unique, préparer un certificat **Apple Distribution** avec sa clé privée exportée en `.p12`, et un profil de distribution **App Store Connect** pour cet identifiant. Créer la fiche de l’app dans App Store Connect avec le même identifiant. Ces éléments ne peuvent pas être fabriqués sans ton compte Apple.
4. Dans **Settings → Secrets and variables → Actions** du dépôt, saisir les variables et secrets ci-dessous. Les valeurs privées vont dans **Secrets**, jamais dans les fichiers du dépôt ni dans une conversation.
5. Lancer **Signer pour TestFlight**, d’abord sans cocher l’envoi. Après les tests et l’export signé, relancer avec **Envoyer aussi cette build à App Store Connect** si les accès d’envoi sont configurés. Cette case est désactivée par défaut. L’IPA signée « App Store Connect » se distribue via Apple ; ce n’est pas une IPA ad hoc à ouvrir directement depuis Fichiers.
6. Après le traitement Apple, activer la build dans l’onglet **TestFlight** d’App Store Connect et l’installer avec l’app **TestFlight** sur l’iPhone. Les tests externes peuvent nécessiter une vérification Apple. Vérifier sur le téléphone la photo après relance, les menus du générateur, les exports, les appels réseau et les autorisations iOS.

| Type | Nom dans GitHub | Valeur attendue |
| --- | --- | --- |
| Variable | `APPLE_TEAM_ID` | Identifiant de l’équipe Apple, 10 caractères |
| Variable | `IOS_BUNDLE_ID` | Identifiant unique, par exemple `fr.tonnom.sc4r` |
| Secret | `IOS_P12_BASE64` | Certificat de distribution et clé privée `.p12`, encodés en base64 |
| Secret | `IOS_P12_PASSWORD` | Mot de passe d’export du `.p12` |
| Secret | `IOS_PROFILE_BASE64` | Profil App Store Connect `.mobileprovision`, encodé en base64 |
| Secret | `IOS_KEYCHAIN_PASSWORD` | Mot de passe aléatoire pour le trousseau temporaire du Mac distant |
| Secret, pour l’envoi | `ASC_KEY_BASE64` | Clé API d’équipe App Store Connect `.p8`, encodée en base64 |
| Secret, pour l’envoi | `ASC_KEY_ID` | Identifiant de cette clé API |
| Secret, pour l’envoi | `ASC_ISSUER_ID` | Issuer ID de cette équipe App Store Connect |

Pour transformer un fichier en base64 depuis PowerShell, adapter le chemin puis copier la valeur dans le secret correspondant :

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\ton-dossier\distribution.p12')) | Set-Clipboard
```

Même opération pour le profil et, si nécessaire, la clé API. Les scripts importent les éléments sur un Mac temporaire, puis les effacent à la fin. Le certificat doit inclure sa clé privée : un simple fichier `.cer` ne suffit pas.

## Essai avec un compte Apple classique : AltStore Classic

Cette voie permet d’utiliser Windows pour signer et installer l’IPA issue du workflow **Compiler et tester SC4R iPhone**. **L’app fonctionne sans PC quand elle est ouverte, mais cette installation nécessite un renouvellement de signature : les apps AltStore Classic expirent après 7 jours et le rafraîchissement utilise AltServer.** Choisir TestFlight si tu veux éviter cette dépendance régulière au PC.

1. Télécharger l’artefact **SC4R-iPhone-non-signe**, puis extraire `SC4R-unsigned.ipa`.
2. Suivre le [guide officiel AltStore pour Windows](https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows) afin d’installer AltServer et AltStore Classic. Les instructions courantes décrivent les versions iTunes/iCloud compatibles, l’association du téléphone et le mode développeur iOS.
3. Envoyer l’IPA sur l’iPhone, l’importer dans **My Apps → +** dans AltStore et la signer avec ton compte Apple dans AltStore/AltServer.
4. Une fois l’installation réussie, tester avec le PC éteint. La génération, la photo, le profil, les fiches et le journal doivent rester utilisables ; les outils Internet utilisent la connexion mobile ou Wi-Fi du téléphone.

Ni l’IPA non signée ni l’IPA destinée à App Store Connect ne s’installent par simple téléchargement dans Safari. Les mots de passe Apple s’entrent uniquement dans le logiciel de connexion choisi, jamais dans le code SC4R.

## Références officielles

- [Présentation TestFlight et durée de 90 jours](https://developer.apple.com/help/app-store-connect/test-a-beta-version/testflight-overview/)
- [Distribution Apple](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases/)
- [Signature sur un runner GitHub](https://docs.github.com/en/actions/how-tos/deploy/deploy-to-third-party-platforms/sign-xcode-applications)
- [Préparer AltStore Classic sur Windows](https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows)
- [Expiration et rafraîchissement AltStore](https://faq.altstore.io/altstore-classic/your-altstore)
