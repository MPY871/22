import Foundation
import SwiftUI
import UIKit
import ImageIO

struct DiskStore {
    let root: URL

    init(root: URL? = nil) throws {
        if let root { self.root = root }
        else {
            let support = try FileManager.default.url(for: .applicationSupportDirectory,
                in: .userDomainMask, appropriateFor: nil, create: true)
            self.root = support.appendingPathComponent("SC4R", isDirectory: true)
        }
        try FileManager.default.createDirectory(at: self.root, withIntermediateDirectories: true)
    }

    var stateURL: URL { root.appendingPathComponent("profile.json") }
    var avatarURL: URL { root.appendingPathComponent("avatar.jpg") }

    func load() throws -> ProfileState {
        guard FileManager.default.fileExists(atPath: stateURL.path) else { return ProfileState() }
        return try JSONDecoder().decode(ProfileState.self, from: Data(contentsOf: stateURL))
    }

    func save(_ state: ProfileState) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(state).write(to: stateURL, options: [.atomic, .completeFileProtection])
    }

    func saveAvatar(_ data: Data) throws {
        try data.write(to: avatarURL, options: [.atomic, .completeFileProtection])
    }

    func avatar() -> Data? { try? Data(contentsOf: avatarURL) }
    func removeAvatar() throws {
        if FileManager.default.fileExists(atPath: avatarURL.path) {
            try FileManager.default.removeItem(at: avatarURL)
        }
    }

    static func normalizePhoto(_ source: Data) throws -> Data {
        guard source.count <= 20 * 1024 * 1024,
              let imageSource = CGImageSourceCreateWithData(source as CFData, nil) else {
            throw AppError.message("Choisis une photo lisible de moins de 20 Mo.")
        }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: 768,
            kCGImageSourceShouldCacheImmediately: true
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary),
              let data = UIImage(cgImage: cgImage).jpegData(compressionQuality: 0.9) else {
            throw AppError.message("Cette photo ne peut pas être lue. Essaie une image JPEG ou PNG.")
        }
        return data
    }
}

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var state = ProfileState()
    @Published private(set) var avatarData: Data?
    @Published private(set) var avatarSaving = false
    @Published var error: String?
    private var disk: DiskStore?
    private var avatarTask: Task<Void, Never>?
    private var avatarGeneration = UUID()

    init(root: URL? = nil) {
        do {
            let storage = try DiskStore(root: root)
            disk = storage
            do { state = try storage.load() }
            catch {
                // Keep the unreadable file so a later save cannot erase the only copy.
                let backup = storage.root.appendingPathComponent("profile-backup-\(UUID().uuidString).json")
                try FileManager.default.copyItem(at: storage.stateURL, to: backup)
                self.error = "Le profil a été sauvegardé à part car il était illisible."
            }
            avatarData = storage.avatar()
        } catch {
            disk = nil
            self.error = "Stockage indisponible : \(error.localizedDescription)"
        }
    }

    private func commit(_ newState: ProfileState) -> Bool {
        do {
            guard let disk else { throw AppError.message("Le stockage de l’application est indisponible.") }
            try disk.save(newState)
            state = newState
            return true
        } catch { self.error = error.localizedDescription; return false }
    }

    func updateProfile(name: String, theme: String) {
        var next = state
        next.name = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(32))
        if next.name.isEmpty { next.name = "Utilisateur" }
        next.theme = ["system", "dark", "light"].contains(theme) ? theme : "system"
        _ = commit(next)
    }

    @discardableResult
    func record(tool: Int, title: String, text: String) -> Bool {
        var next = state
        let excerpt = text.count > 50_000 ? String(text.prefix(50_000)) + "\n\n[Historique : aperçu limité. Le résultat complet peut être exporté depuis l’outil.]" : text
        next.history.insert(HistoryEntry(toolID: tool, title: title, text: excerpt), at: 0)
        next.history = Array(next.history.prefix(60))
        return commit(next)
    }

    func removeHistory(_ offsets: IndexSet) {
        var next = state; next.history.remove(atOffsets: offsets); _ = commit(next)
    }
    func clearHistory() { var next = state; next.history = []; _ = commit(next) }

    @discardableResult
    func saveDossier(_ dossier: Dossier) -> Bool {
        var next = state
        if let i = next.dossiers.firstIndex(where: { $0.id == dossier.id }) { next.dossiers[i] = dossier }
        else { next.dossiers.insert(dossier, at: 0) }
        return commit(next)
    }
    func removeDossiers(_ offsets: IndexSet) {
        var next = state; next.dossiers.remove(atOffsets: offsets); _ = commit(next)
    }

    func saveAvatar(_ normalizedData: Data) {
        do {
            guard let disk else { throw AppError.message("Stockage indisponible.") }
            try disk.saveAvatar(normalizedData)
            avatarData = normalizedData
        } catch { self.error = error.localizedDescription }
    }

    // The import belongs to the app store, so changing tabs cannot discard a selected photo.
    func importAvatar(loader: @escaping () async throws -> Data?) {
        avatarTask?.cancel()
        let generation = UUID(); avatarGeneration = generation; avatarSaving = true
        avatarTask = Task {
            defer {
                if avatarGeneration == generation { avatarSaving = false; avatarTask = nil }
            }
            do {
                guard let data = try await loader() else { throw AppError.message("Cette photo ne peut pas être importée.") }
                try Task.checkCancellation()
                let normalized = try await Task.detached(priority: .userInitiated) { try DiskStore.normalizePhoto(data) }.value
                guard !Task.isCancelled, avatarGeneration == generation else { return }
                saveAvatar(normalized)
            } catch {
                if !Task.isCancelled, avatarGeneration == generation { self.error = error.localizedDescription }
            }
        }
    }

    func removeAvatar() {
        avatarGeneration = UUID(); avatarTask?.cancel(); avatarTask = nil; avatarSaving = false
        do {
            guard let disk else { throw AppError.message("Stockage indisponible.") }
            try disk.removeAvatar(); avatarData = nil
        }
        catch { self.error = error.localizedDescription }
    }
}
