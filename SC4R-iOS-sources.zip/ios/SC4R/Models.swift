import Foundation

struct Tool: Identifiable, Hashable {
    let id: Int
    let name: String
    let subtitle: String
    let symbol: String
    let offline: Bool
    let available: Bool

    static let all: [Tool] = [
        .init(id: 1, name: "Générateur de numéros", subtitle: "Quantité, opérateur et export", symbol: "number", offline: true, available: true),
        .init(id: 2, name: "Informations numéro", subtitle: "Format, pays et type de ligne", symbol: "phone", offline: true, available: true),
        .init(id: 3, name: "Fiches", subtitle: "Créer et conserver tes dossiers", symbol: "person.text.rectangle", offline: true, available: true),
        .init(id: 4, name: "Informations IP", subtitle: "Données publiques sur une adresse", symbol: "network", offline: false, available: true),
        .init(id: 5, name: "Vérifier des fichiers", subtitle: "Doublons, recherche et fusion", symbol: "doc.text.magnifyingglass", offline: true, available: true),
        .init(id: 6, name: "Ports TCP", subtitle: "Tester une adresse depuis l’iPhone", symbol: "antenna.radiowaves.left.and.right", offline: false, available: true),
        .init(id: 7, name: "Obfuscateur Python", subtitle: "Module Python conservé dans le projet original", symbol: "curlybraces", offline: true, available: false),
        .init(id: 8, name: "Recherche de pseudo", subtitle: "Pages publiques et liens à vérifier", symbol: "at", offline: false, available: true),
        .init(id: 9, name: "Informations email", subtitle: "Format et configuration du domaine", symbol: "envelope", offline: false, available: true),
        .init(id: 10, name: "Analyse Windows", subtitle: "Ce module nécessite l’environnement Windows", symbol: "desktopcomputer", offline: true, available: false),
        .init(id: 11, name: "Décompileur", subtitle: "Chaîne de compilation du projet Python", symbol: "doc.zipper", offline: true, available: false)
    ]
}

struct HistoryEntry: Codable, Identifiable, Hashable {
    var id = UUID()
    var date = Date()
    var toolID: Int
    var title: String
    var text: String
}

struct Dossier: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var date = Date()
    var values: [String: String]

    var text: String {
        ([title, date.formatted(date: .numeric, time: .shortened), ""] +
         values.keys.sorted().filter { !(values[$0] ?? "").isEmpty }
            .map { "\($0) : \(values[$0] ?? "")" }).joined(separator: "\n")
    }
}

struct ProfileState: Codable {
    var name = "Utilisateur"
    var theme = "system"
    var history: [HistoryEntry] = []
    var dossiers: [Dossier] = []
}

struct GeneratedNumber: Identifiable, Hashable {
    let id = UUID()
    let number: String
    let operatorName: String
}

enum GeneratorStep: String, CaseIterable {
    case quantity, operatorChoice, results
}

enum AppError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        switch self { case .message(let text): return text }
    }
}
