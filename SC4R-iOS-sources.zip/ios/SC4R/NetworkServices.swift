import Foundation
import Network

struct HTTPClient {
    static let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 20
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config)
    }()

    static func data(_ url: URL, accept: String = "application/json") async throws -> (Data, HTTPURLResponse) {
        var request = URLRequest(url: url)
        request.setValue(accept, forHTTPHeaderField: "Accept")
        request.setValue("SC4R-iOS/1.0", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw AppError.message("Réponse réseau invalide.") }
        guard data.count <= 2 * 1024 * 1024 else { throw AppError.message("La réponse est trop volumineuse.") }
        if http.statusCode == 429 { throw AppError.message("Le service limite les demandes. Réessaie plus tard.") }
        return (data, http)
    }

    static func decode<T: Decodable>(_ type: T.Type, url: URL, accept: String = "application/json") async throws -> T {
        let (data, http) = try await Self.data(url, accept: accept)
        guard (200...299).contains(http.statusCode) else { throw AppError.message("Service indisponible (HTTP \(http.statusCode)).") }
        return try JSONDecoder().decode(type, from: data)
    }
}

enum IPService {
    struct Reply: Decodable {
        var success: Bool
        var message: String?
        var ip: String?
        var country: String?
        var region: String?
        var city: String?
        var postal: String?
        var latitude: Double?
        var longitude: Double?
        var connection: Connection?
        var timezone: Zone?
        struct Connection: Decodable { var isp: String?; var org: String?; var asn: Int? }
        struct Zone: Decodable { var id: String? }
    }

    static func lookup(_ address: String) async throws -> String {
        let value = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard value.isEmpty || IPv4Address(value) != nil || IPv6Address(value) != nil else {
            throw AppError.message("Saisis une adresse IPv4 ou IPv6.")
        }
        let url = URL(string: "https://ipwho.is/")!.appendingPathComponent(value)
        let reply = try await HTTPClient.decode(Reply.self, url: url)
        guard reply.success else { throw AppError.message(reply.message ?? "Aucune information disponible pour cette adresse.") }
        return ["IP : \(reply.ip ?? value)", "Pays : \(reply.country ?? "—")", "Région : \(reply.region ?? "—")",
                "Ville : \(reply.city ?? "—")", "Code postal : \(reply.postal ?? "—")",
                "Réseau : \(reply.connection?.org ?? reply.connection?.isp ?? "—")",
                "ASN : \(reply.connection?.asn.map(String.init) ?? "—")", "Fuseau : \(reply.timezone?.id ?? "—")", "",
                "Source : ipwho.is. La localisation IP est approximative ; elle ne localise pas une personne."].joined(separator: "\n")
    }
}

enum EmailService {
    struct DNSReply: Decodable {
        let Status: Int
        let Answer: [AnswerItem]?
        struct AnswerItem: Decodable { let type: Int; let data: String }
    }

    static func domain(_ email: String) throws -> String {
        let parts = email.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: "@", omittingEmptySubsequences: false)
        guard parts.count == 2, !parts[0].isEmpty, parts[0].count <= 64,
              !parts[0].contains(where: { $0.isWhitespace }), parts[1].count <= 253 else {
            throw AppError.message("Saisis une adresse email complète.")
        }
        let labels = parts[1].split(separator: ".", omittingEmptySubsequences: false)
        guard labels.count >= 2, labels.allSatisfy({ label in
            !label.isEmpty && label.count <= 63 && label.first != "-" && label.last != "-" &&
            label.unicodeScalars.allSatisfy { (48...57).contains($0.value) || (65...90).contains($0.value) || (97...122).contains($0.value) || $0.value == 45 }
        }) else { throw AppError.message("Le domaine de l’adresse email est invalide.") }
        return String(parts[1]).lowercased()
    }

    static func lookup(_ email: String) async throws -> String {
        let name = try domain(email)
        var components = URLComponents(string: "https://cloudflare-dns.com/dns-query")!
        components.queryItems = [.init(name: "name", value: name), .init(name: "type", value: "MX")]
        let reply = try await HTTPClient.decode(DNSReply.self, url: components.url!, accept: "application/dns-json")
        guard reply.Status == 0 || reply.Status == 3 else { throw AppError.message("Le serveur DNS n’a pas pu répondre (code \(reply.Status)).") }
        let mx = (reply.Answer ?? []).filter { $0.type == 15 }.map(\.data)
        let summary: String
        if reply.Status == 3 { summary = "Domaine inexistant dans le DNS." }
        else if mx.contains(where: { $0.trimmingCharacters(in: .whitespaces) == "0 ." }) { summary = "Le domaine déclare ne pas accepter d’email (Null MX)." }
        else { summary = mx.isEmpty ? "Aucun enregistrement MX déclaré." : "Serveurs de messagerie déclarés." }
        return (["Adresse : \(email)", "Domaine : \(name)", summary, ""] + mx + ["", "Seul le domaine est envoyé au résolveur DNS Cloudflare. Ces informations ne confirment pas l’existence de la boîte email."]).joined(separator: "\n")
    }
}

struct UsernameCheck: Identifiable, Sendable {
    let id: String
    let url: URL
    let state: String
}

enum UsernameService {
    private struct GitHubProfile: Decodable { let login: String }
    static func check(_ username: String) async throws -> [UsernameCheck] {
        let user = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !user.isEmpty, user.count <= 40,
              user.unicodeScalars.allSatisfy({ (48...57).contains($0.value) || (65...90).contains($0.value) || (97...122).contains($0.value) || [45, 46, 95].contains($0.value) }) else {
            throw AppError.message("Utilise un pseudo de 1 à 40 caractères : lettres, chiffres, point, tiret ou underscore.")
        }
        let sites: [(String, String)] = [
            ("GitHub", "https://github.com/\(user)"), ("GitLab", "https://gitlab.com/\(user)"),
            ("Reddit", "https://www.reddit.com/user/\(user)/"), ("Twitch", "https://www.twitch.tv/\(user)"),
            ("Instagram", "https://www.instagram.com/\(user)/"), ("TikTok", "https://www.tiktok.com/@\(user)"),
            ("YouTube", "https://www.youtube.com/@\(user)"), ("Pinterest", "https://www.pinterest.com/\(user)/")
        ]
        return await withTaskGroup(of: UsernameCheck.self, returning: [UsernameCheck].self) { group in
            for (name, link) in sites {
                group.addTask {
                    let page = URL(string: link)!
                    do {
                        let endpoint = name == "GitHub" ? URL(string: "https://api.github.com/users/\(user)")! : page
                        let (data, response) = try await HTTPClient.data(endpoint, accept: name == "GitHub" ? "application/vnd.github+json" : "text/html")
                        let label: String
                        if name == "GitHub", response.statusCode == 200,
                           let profile = try? JSONDecoder().decode(GitHubProfile.self, from: data),
                           profile.login.caseInsensitiveCompare(user) == .orderedSame { label = "Profil public trouvé" }
                        else if response.statusCode == 404 { label = "Page non trouvée" }
                        else if response.statusCode == 403 || response.statusCode == 429 { label = "Vérification bloquée" }
                        else { label = "À vérifier dans la page" }
                        return .init(id: name, url: page, state: label)
                    } catch { return .init(id: name, url: page, state: "Vérification indisponible") }
                }
            }
            var values: [UsernameCheck] = []
            for await item in group { values.append(item) }
            return values.sorted { $0.id < $1.id }
        }
    }
}

struct PortResult: Identifiable, Sendable { let port: Int; let state: String; var id: Int { port } }

private final class TCPAttempt: @unchecked Sendable {
    private let lock = NSLock()
    private var finished = false
    private var continuation: CheckedContinuation<String, Never>?
    private var connection: NWConnection?
    private var timeout: DispatchWorkItem?

    func run(host: String, port: UInt16) async -> String {
        await withTaskCancellationHandler(operation: {
            await withCheckedContinuation { continuation in
                lock.lock()
                if finished { lock.unlock(); continuation.resume(returning: "Annulé"); return }
                self.continuation = continuation
                let connection = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!, using: .tcp)
                self.connection = connection
                let timer = DispatchWorkItem { [weak self] in self?.finish("Sans réponse") }
                timeout = timer
                lock.unlock()
                connection.stateUpdateHandler = { [weak self] state in
                    switch state {
                    case .ready: self?.finish("Ouvert")
                    case .failed: self?.finish("Fermé ou inaccessible")
                    case .cancelled: self?.finish("Annulé")
                    default: break
                    }
                }
                connection.start(queue: .global(qos: .userInitiated))
                DispatchQueue.global().asyncAfter(deadline: .now() + 2, execute: timer)
            }
        }, onCancel: { self.finish("Annulé") })
    }

    private func finish(_ value: String) {
        lock.lock()
        guard !finished else { lock.unlock(); return }
        finished = true
        let callback = continuation, connection = self.connection, timer = timeout
        continuation = nil; self.connection = nil; timeout = nil
        lock.unlock()
        timer?.cancel(); connection?.cancel(); callback?.resume(returning: value)
    }
}

enum PortService {
    static func parse(_ value: String) throws -> [Int] {
        var ports = Set<Int>()
        for part in value.split(separator: ",", omittingEmptySubsequences: false) {
            let clean = part.trimmingCharacters(in: .whitespaces)
            let limits = clean.split(separator: "-", omittingEmptySubsequences: false)
            if limits.count == 2, let first = Int(limits[0]), let last = Int(limits[1]), first <= last,
               first >= 1, last <= 65535, last - first < 256 {
                ports.formUnion(first...last)
            } else if limits.count == 1, let port = Int(clean), (1...65535).contains(port) { ports.insert(port) }
            else { throw AppError.message("Ports invalides. Exemple : 22,80,443 ou 8000-8010.") }
        }
        guard !ports.isEmpty, ports.count <= 256 else { throw AppError.message("Choisis entre 1 et 256 ports.") }
        return ports.sorted()
    }

    static func scan(host: String, ports: String) async throws -> [PortResult] {
        let target = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !target.isEmpty, target.count <= 253, !target.contains(where: { $0.isWhitespace }), !target.contains("/") else {
            throw AppError.message("Saisis un nom de domaine ou une adresse IP.")
        }
        let values = try parse(ports)
        return await withTaskGroup(of: PortResult.self, returning: [PortResult].self) { group in
            var iterator = values.makeIterator()
            for _ in 0..<min(12, values.count) {
                if let port = iterator.next() { group.addTask { await probe(host: target, port: port) } }
            }
            var results: [PortResult] = []
            while let value = await group.next() {
                results.append(value)
                if !Task.isCancelled, let port = iterator.next() { group.addTask { await probe(host: target, port: port) } }
            }
            return results.sorted { $0.port < $1.port }
        }
    }

    private static func probe(host: String, port: Int) async -> PortResult {
        if Task.isCancelled { return .init(port: port, state: "Annulé") }
        let state = await TCPAttempt().run(host: host, port: UInt16(port))
        return .init(port: port, state: state)
    }
}
