import SwiftUI
import PhotosUI

@MainActor
struct ProfileView: View {
    @EnvironmentObject private var store: AppStore
    @State private var name = ""
    @State private var theme = "system"
    @State private var selectedPhoto: PhotosPickerItem?
    var body: some View {
        Form {
            Section {
                HStack { Spacer(); AvatarView(size: 100); Spacer() }.padding(.vertical, 15)
                PhotosPicker(selection: $selectedPhoto, matching: .images, photoLibrary: .shared()) {
                    Label(store.avatarData == nil ? "Choisir ma photo" : "Changer ma photo", systemImage: "photo")
                }.disabled(store.avatarSaving)
                if store.avatarSaving { ProgressView("Enregistrement de la photo…") }
                if store.avatarData != nil || store.avatarSaving {
                    Button("Retirer ma photo", role: .destructive) {
                        store.removeAvatar(); selectedPhoto = nil
                    }
                }
            } footer: { Text("La photo est enregistrée sur cet iPhone et conservée aux prochains lancements.") }
            Section("Mon profil") {
                TextField("Nom affiché", text: $name)
                Picker("Apparence", selection: $theme) {
                    Text("Comme l’iPhone").tag("system"); Text("Sombre").tag("dark"); Text("Clair").tag("light")
                }
                Button("Enregistrer mon profil") { store.updateProfile(name: name, theme: theme) }
            }
            Section("SC4R natif") {
                Label("Fonctionne sans PC", systemImage: "iphone")
                Text("La génération, les informations de format téléphonique, les fiches, les fichiers et l’historique fonctionnent hors ligne. Les recherches réseau ont besoin d’Internet ou du réseau local.")
                    .font(.subheadline).foregroundStyle(.secondary)
                Text("Version 1.0 · iOS 16 et versions suivantes").font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("Mon profil")
            .onAppear { name = store.state.name; theme = store.state.theme }
            .onChange(of: selectedPhoto) { item in
                guard let item else { return }
                store.importAvatar { try await item.loadTransferable(type: Data.self) }
            }
    }
}
