import SwiftUI

@main
@MainActor
struct SC4RApp: App {
    @StateObject private var store = AppStore()
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).tint(Brand.purple)
                .preferredColorScheme(store.state.theme == "dark" ? .dark : store.state.theme == "light" ? .light : nil)
                .alert("SC4R", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                    Button("OK", role: .cancel) { store.error = nil }
                } message: { Text(store.error ?? "") }
        }
    }
}
