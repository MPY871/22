import SwiftUI

@MainActor
struct RootView: View {
    var body: some View {
        TabView {
            NavigationStack { HomeView() }.tabItem { Label("Accueil", systemImage: "house") }
            NavigationStack { ToolLibraryView() }.tabItem { Label("Outils", systemImage: "square.grid.2x2") }
            NavigationStack { HistoryView() }.tabItem { Label("Journal", systemImage: "clock") }
            NavigationStack { ProfileView() }.tabItem { Label("Profil", systemImage: "person.crop.circle") }
        }
    }
}

@MainActor
struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack(spacing: 12) {
                    BrandMark()
                    VStack(alignment: .leading, spacing: 3) {
                        Text("SC4R").font(.headline)
                        Text("TON ESPACE MOBILE").font(.caption2.weight(.semibold)).tracking(1.5).foregroundStyle(.secondary)
                    }
                    Spacer()
                    NavigationLink { ProfileView() } label: { AvatarView() }
                }
                VStack(alignment: .leading, spacing: 16) {
                    Text("Tes outils.\nSur ton iPhone.").font(.system(.largeTitle, design: .rounded).weight(.bold))
                    Text("Bonjour \(store.state.name). Ton espace fonctionne directement sur le téléphone.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    NavigationLink { GeneratorView() } label: { Label("Générer des numéros", systemImage: "number") }
                        .buttonStyle(PrimaryAction()).accessibilityIdentifier("generator.open")
                }.padding(24).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Brand.purple.opacity(0.1), in: RoundedRectangle(cornerRadius: 28))
                HStack(spacing: 12) {
                    metric("OUTILS IPHONE", value: "\(Tool.all.filter(\.available).count)", symbol: "iphone")
                    metric("DANS TON JOURNAL", value: "\(store.state.history.count)", symbol: "clock")
                }
                VStack(alignment: .leading, spacing: 12) {
                    Text("À portée de main").font(.title3.weight(.bold))
                    ForEach(Tool.all.filter { [1, 2, 3, 5].contains($0.id) }) { tool in
                        NavigationLink { ToolScreen(tool: tool) } label: { ToolRow(tool: tool) }
                            .buttonStyle(.plain)
                    }
                }.padding(20).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
                if let recent = store.state.history.first {
                    NavigationLink { HistoryDetail(entry: recent) } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Dernier résultat", systemImage: "arrow.up.right").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                            Text(recent.title).font(.headline)
                            Text(recent.date, style: .date).font(.caption).foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(20)
                            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24))
                    }.buttonStyle(.plain)
                }
            }.padding(20)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle("").navigationBarTitleDisplayMode(.inline)
    }
    private func metric(_ title: String, value: String, symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(title, systemImage: symbol).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
            Text(value).font(.system(.largeTitle, design: .rounded).weight(.bold))
        }.frame(maxWidth: .infinity, alignment: .leading).padding(18)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }
}

@MainActor
struct ToolLibraryView: View {
    @State private var search = ""
    private var filtered: [Tool] {
        Tool.all.filter { search.isEmpty || ($0.name + " " + $0.subtitle + " " + String(format: "%02d", $0.id))
            .range(of: search, options: [.caseInsensitive, .diacriticInsensitive]) != nil }
    }
    var body: some View {
        List {
            Section("Sur cet iPhone") {
                ForEach(filtered.filter(\.available)) { tool in
                    NavigationLink { ToolScreen(tool: tool) } label: { ToolRow(tool: tool) }
                }
            }
            if filtered.contains(where: { !$0.available }) {
                Section("Modules du projet original") {
                    ForEach(filtered.filter { !$0.available }) { tool in
                        NavigationLink { ToolScreen(tool: tool) } label: { ToolRow(tool: tool) }
                    }
                }
            }
            if filtered.isEmpty { Text("Aucun outil ne correspond à ta recherche.").foregroundStyle(.secondary) }
        }.navigationTitle("Tes outils").searchable(text: $search, prompt: "Nom ou numéro d’outil")
    }
}

@MainActor
struct ToolScreen: View {
    let tool: Tool
    @ViewBuilder var body: some View {
        switch tool.id {
        case 1: GeneratorView()
        case 2: PhoneView()
        case 3: DossiersView()
        case 4: IPView()
        case 5: FileToolsView()
        case 6: PortsView()
        case 8: UsernameView()
        case 9: EmailView()
        default:
            VStack(spacing: 20) {
                Image(systemName: tool.symbol).font(.system(size: 48)).foregroundStyle(Brand.purple)
                Text(tool.name).font(.title2.weight(.bold))
                Text(tool.subtitle).multilineTextAlignment(.center).foregroundStyle(.secondary)
                Text("Cette fonction n’est pas portée dans l’app autonome. Le code original est conservé dans l’archive fournie.")
                    .font(.subheadline).multilineTextAlignment(.center).foregroundStyle(.secondary)
            }.padding(28).navigationTitle("Module original").navigationBarTitleDisplayMode(.inline)
        }
    }
}

@MainActor
struct HistoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var clearing = false
    var body: some View {
        List {
            if store.state.history.isEmpty {
                VStack(spacing: 14) {
                    Image(systemName: "clock").font(.largeTitle).foregroundStyle(Brand.purple)
                    Text("Ton journal commence ici").font(.headline)
                    Text("Les résultats enregistrés resteront disponibles après la fermeture de l’app.")
                        .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }.frame(maxWidth: .infinity).padding(.vertical, 40)
            }
            ForEach(store.state.history) { item in
                NavigationLink { HistoryDetail(entry: item) } label: {
                    VStack(alignment: .leading, spacing: 7) {
                        Text(item.title).font(.subheadline.weight(.semibold))
                        Text(item.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                    }.padding(.vertical, 6)
                }
            }.onDelete(perform: store.removeHistory)
        }.navigationTitle("Ton journal")
            .toolbar { if !store.state.history.isEmpty { Button("Vider", role: .destructive) { clearing = true } } }
            .confirmationDialog("Vider l’historique ?", isPresented: $clearing) {
                Button("Vider l’historique", role: .destructive) { store.clearHistory() }
            }
    }
}

@MainActor
struct HistoryDetail: View {
    let entry: HistoryEntry
    var body: some View {
        ScrollView { ReportView(text: entry.text).padding(18) }
            .background(Color(uiColor: .systemGroupedBackground)).navigationTitle(entry.title).navigationBarTitleDisplayMode(.inline)
    }
}
