import SwiftUI

@MainActor
final class GeneratorModel: ObservableObject {
    @Published private(set) var step = GeneratorStep.quantity
    @Published var quantity = "20"
    @Published private(set) var results: [GeneratedNumber] = []
    private var count = 20

    func next() throws {
        guard step == .quantity, let amount = Int(quantity), (1...1000).contains(amount) else {
            throw AppError.message("Choisis une quantité entre 1 et 1 000.")
        }
        count = amount; step = .operatorChoice
    }
    func choose(_ name: String?, operators: [String: [String]] = NumberGenerator.operators) throws {
        guard step == .operatorChoice else { throw AppError.message("Choisis d’abord la quantité, puis l’opérateur.") }
        let values = try NumberGenerator.generate(count: count, operatorName: name, operators: operators)
        results = values; step = .results
    }
    func back() { if step == .operatorChoice { step = .quantity } }
    func reset() { results = []; step = .quantity }
    var text: String { results.map { "\($0.number) — \($0.operatorName)" }.joined(separator: "\n") }
}

@MainActor
struct GeneratorView: View {
    @EnvironmentObject private var store: AppStore
    @StateObject private var model = GeneratorModel()
    @State private var error: String?
    @FocusState private var focused: Bool
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(spacing: 8) {
                    ForEach(Array(GeneratorStep.allCases.enumerated()), id: \.offset) { index, step in
                        HStack(spacing: 6) {
                            Text("\(index + 1)").font(.caption.weight(.bold))
                                .frame(width: 25, height: 25).background(model.step == step ? Brand.purple : Color.secondary.opacity(0.15), in: Circle())
                                .foregroundStyle(model.step == step ? Color.white : Color.secondary)
                            Text(["Quantité", "Opérateur", "Résultats"][index]).font(.caption.weight(.semibold))
                        }
                        if index < 2 { Spacer(minLength: 2) }
                    }
                }.accessibilityElement(children: .combine)
                if model.step == .quantity { quantity }
                else if model.step == .operatorChoice { operators }
                else { results }
            }.padding(20)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle("Numéros")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Génération", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
    }
    private var quantity: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Combien de numéros ?").font(.title2.weight(.bold))
            Text("Choisis entre 1 et 1 000 numéros.").foregroundStyle(.secondary)
            TextField("Quantité", text: $model.quantity).keyboardType(.numberPad).focused($focused)
                .font(.largeTitle.weight(.semibold)).padding(18)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
                .accessibilityLabel("Quantité de numéros")
                .accessibilityIdentifier("generator.quantity")
            HStack { ForEach([10, 20, 50, 100], id: \.self) { count in
                Button("\(count)") { model.quantity = "\(count)" }.buttonStyle(.bordered).frame(maxWidth: .infinity)
            } }
            Button("Choisir l’opérateur") {
                focused = false
                do { try model.next() } catch { self.error = error.localizedDescription }
            }.buttonStyle(PrimaryAction()).accessibilityIdentifier("generator.next")
        }
    }
    private var operators: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Choisis ton opérateur").font(.title2.weight(.bold)).accessibilityIdentifier("generator.operator.title")
            Text("\(model.quantity) numéros seront générés après ton choix.").foregroundStyle(.secondary)
            ForEach(NumberGenerator.operators.keys.sorted(), id: \.self) { name in choice(name, value: name) }
            choice("Mixte — tous les opérateurs", value: nil)
            Button("Modifier la quantité") { model.back() }.padding(.top, 8).accessibilityIdentifier("generator.back")
        }
    }
    private func choice(_ label: String, value: String?) -> some View {
        Button {
            do {
                try model.choose(value)
                store.record(tool: 1, title: "\(model.results.count) numéros · \(value ?? "Mixte")", text: model.text)
            } catch { self.error = error.localizedDescription }
        } label: {
            HStack { Text(label).font(.headline); Spacer(); Image(systemName: "chevron.right").font(.caption) }
                .padding(18).foregroundStyle(.primary)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain).accessibilityIdentifier("generator.operator.\(value ?? "mixed")")
    }
    private var results: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("\(model.results.count) numéros générés").font(.title2.weight(.bold)).accessibilityIdentifier("generator.results.title")
            HStack {
                ExportButton(text: model.results.map(\.number).joined(separator: "\n"), filename: "numeros_generes.txt")
                Spacer()
                ShareLink(item: model.text) { Label("Partager", systemImage: "square.and.arrow.up") }
            }.font(.subheadline.weight(.semibold))
            Text("Numéros aléatoires. Les opérateurs correspondent aux préfixes du jeu de données original.")
                .font(.caption).foregroundStyle(.secondary)
            Button("Nouvelle génération") { model.reset() }.buttonStyle(.bordered).accessibilityIdentifier("generator.reset")
            LazyVStack(spacing: 8) {
                ForEach(model.results) { result in
                    HStack {
                        Text(result.number).font(.system(.body, design: .monospaced)).textSelection(.enabled)
                        Spacer(); Text(result.operatorName).font(.caption).foregroundStyle(.secondary)
                    }.padding(15).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
                }
            }
        }
    }
}
