import SwiftUI
import UniformTypeIdentifiers
import UIKit

@MainActor
struct PhoneView: View {
    @EnvironmentObject private var store: AppStore
    @State private var phone = ""
    @State private var region = "FR"
    @State private var result = ""
    @State private var error: String?
    private let lookup = PhoneLookup.shared
    @FocusState private var focused: Bool
    var body: some View {
        Form {
            Section("Numéro à vérifier") {
                TextField("+33 6…", text: $phone).keyboardType(.phonePad).focused($focused)
                Picker("Pays par défaut", selection: $region) {
                    ForEach(["FR", "BE", "CH", "CA", "GB", "US", "DE", "ES", "IT"], id: \.self) {
                        Text(Locale(identifier: "fr_FR").localizedString(forRegionCode: $0) ?? $0).tag($0)
                    }
                }
                Button("Analyser le numéro") {
                    focused = false
                    do {
                        let value = try lookup.lookup(phone, region: region)
                        result = value; store.record(tool: 2, title: "Numéro · \(phone)", text: value)
                    } catch { self.error = "Numéro invalide : \(error.localizedDescription)" }
                }
            }
            if !result.isEmpty { Section("Informations") { ReportView(text: result) } }
        }.navigationTitle("Informations numéro").navigationBarTitleDisplayMode(.inline)
            .alert("Numéro", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
    }
}

@MainActor
struct QueryView: View {
    @EnvironmentObject private var store: AppStore
    var title: String
    var placeholder: String
    var note: String
    var toolID: Int
    var keyboard: UIKeyboardType = .asciiCapable
    var allowEmpty = false
    var action: (String) async throws -> String
    @State private var query = ""
    @StateObject private var runner = NetworkRunner()
    @FocusState private var focused: Bool
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(title).font(.title2.weight(.bold))
                Text(note).font(.subheadline).foregroundStyle(.secondary)
                TextField(placeholder, text: $query).keyboardType(keyboard)
                    .textInputAutocapitalization(.never).autocorrectionDisabled().focused($focused)
                    .padding(16).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
                    .submitLabel(.search).onSubmit { start() }
                if runner.busy {
                    HStack { ProgressView(); Text("Recherche en cours…"); Spacer(); Button("Arrêter") { runner.cancel() } }
                } else {
                    Button("Rechercher") { start() }.buttonStyle(PrimaryAction())
                        .disabled(!allowEmpty && query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                if let error = runner.error { Text(error).font(.subheadline).foregroundStyle(.red) }
                if !runner.text.isEmpty { ReportView(text: runner.text) }
            }.padding(20)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle(title).navigationBarTitleDisplayMode(.inline)
            .onDisappear { runner.cancel() }
    }
    private func start() {
        guard !runner.busy else { return }
        focused = false
        let value = query
        runner.run(operation: { try await action(value) }) { text in
            store.record(tool: toolID, title: "\(title) · \(value.isEmpty ? "Cet iPhone" : value)", text: text)
        }
    }
}

@MainActor
struct IPView: View {
    var body: some View {
        QueryView(title: "Informations IP", placeholder: "8.8.8.8 ou une adresse IPv6",
                  note: "Consulte les données publiques d’une IP. Laisse le champ vide pour l’adresse publique de cette connexion. La demande est envoyée à ipwho.is.",
                  toolID: 4, allowEmpty: true, action: IPService.lookup)
    }
}

@MainActor
struct EmailView: View {
    var body: some View {
        QueryView(title: "Informations email", placeholder: "nom@exemple.fr",
                  note: "Vérifie le format et les serveurs du domaine. Seul le domaine est transmis au résolveur DNS Cloudflare.",
                  toolID: 9, keyboard: .emailAddress, action: EmailService.lookup)
    }
}

@MainActor
struct UsernameView: View {
    @EnvironmentObject private var store: AppStore
    @State private var username = ""
    @State private var checks: [UsernameCheck] = []
    @StateObject private var runner = NetworkRunner()
    @FocusState private var focused: Bool
    var body: some View {
        List {
            Section {
                TextField("Pseudo", text: $username).textInputAutocapitalization(.never).autocorrectionDisabled().focused($focused)
                if runner.busy { HStack { ProgressView(); Text("Vérification…"); Spacer(); Button("Arrêter") { runner.cancel() } } }
                else { Button("Rechercher les pages") { start() }.disabled(username.isEmpty) }
            } footer: {
                Text("Le pseudo est envoyé aux sites sélectionnés. Une page qui répond ne confirme pas à elle seule l’existence d’un profil.")
            }
            if let error = runner.error { Section { Text(error).foregroundStyle(.red) } }
            Section("Pages publiques") {
                ForEach(checks) { item in
                    Link(destination: item.url) {
                        HStack {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.id).font(.headline)
                                Text(item.state).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer(); Image(systemName: "arrow.up.right")
                        }.padding(.vertical, 5)
                    }
                }
            }
            if !runner.text.isEmpty { Section { ExportButton(text: runner.text) } }
        }.navigationTitle("Recherche de pseudo").navigationBarTitleDisplayMode(.inline).onDisappear { runner.cancel() }
    }
    private func start() {
        focused = false
        let value = username
        checks = []
        runner.run(operation: { try await UsernameService.check(value) }, render: { results in
            results.map { "\($0.id) — \($0.state) — \($0.url.absoluteString)" }.joined(separator: "\n")
        }) { results in
            checks = results
            store.record(tool: 8, title: "Pseudo · \(value)", text: runner.text)
        }
    }
}

@MainActor
struct PortsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var host = ""
    @State private var ports = "22,80,443,8080"
    @StateObject private var runner = NetworkRunner()
    @FocusState private var focused: Bool
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Tester les ports TCP").font(.title2.weight(.bold))
                Text("Les connexions partent de cet iPhone. iOS peut demander l’autorisation d’accéder au réseau local.")
                    .font(.subheadline).foregroundStyle(.secondary)
                Group {
                    TextField("Adresse IP ou domaine", text: $host)
                    TextField("22,80,443 ou 8000-8010", text: $ports)
                }.textInputAutocapitalization(.never).autocorrectionDisabled().focused($focused)
                    .padding(16).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
                if runner.busy {
                    HStack { ProgressView(); Text("Tests en cours…"); Spacer(); Button("Arrêter") { runner.cancel() } }
                } else {
                    Button("Tester les ports") { start() }.buttonStyle(PrimaryAction()).disabled(host.isEmpty)
                }
                if let error = runner.error { Text(error).foregroundStyle(.red) }
                if !runner.text.isEmpty { ReportView(text: runner.text) }
            }.padding(20)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle("Ports TCP").navigationBarTitleDisplayMode(.inline)
            .onDisappear { runner.cancel() }
    }
    private func start() {
        focused = false
        let address = host, selectedPorts = ports
        runner.run(operation: {
            let values = try await PortService.scan(host: address, ports: selectedPorts)
            try Task.checkCancellation()
            return (["Adresse : \(address)", ""] + values.map { "\($0.port)/TCP — \($0.state)" }).joined(separator: "\n")
        }) { value in store.record(tool: 6, title: "Ports · \(address)", text: value) }
    }
}

@MainActor
struct FileToolsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var files: [ImportedText] = []
    @State private var importing = false
    @State private var query = ""
    @State private var unique = true
    @State private var result = ""
    @State private var resultType = UTType.plainText
    @State private var busy = false
    @State private var error: String?
    @State private var work: Task<Void, Never>?
    var body: some View {
        List {
            Section {
                Button { importing = true } label: { Label("Ajouter des fichiers", systemImage: "folder.badge.plus") }.disabled(busy)
                ForEach(files) { file in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(file.name).font(.subheadline.weight(.semibold))
                        Text("\(file.lines.count) lignes · \(ByteCountFormatter.string(fromByteCount: Int64(file.byteCount), countStyle: .file))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.onDelete { offsets in files.remove(atOffsets: offsets); result = "" }.deleteDisabled(busy)
            } footer: { Text("Texte UTF-8, UTF-16 ou PDF contenant du texte. Jusqu’à 5 fichiers, 20 Mo par fichier et 25 Mo au total. Les PDF scannés nécessitent un OCR.") }
            if busy { Section { ProgressView("Traitement en cours…") } }
            if !files.isEmpty {
                Section("Opérations") {
                    Button("Analyser les doublons") { perform { FileTools.duplicates($0) } }.disabled(busy)
                    Toggle("Retirer les doublons de la fusion", isOn: $unique)
                    Button("Fusionner les fichiers") { let flag = unique; perform { FileTools.merge($0, unique: flag) } }.disabled(busy)
                    TextField("Texte à rechercher", text: $query)
                    Button("Rechercher dans les fichiers") { let term = query; perform { try FileTools.search($0, term: term) } }.disabled(busy || query.isEmpty)
                    Button("Afficher les empreintes SHA-256") {
                        perform { values in values.map { "\($0.name)\nSHA-256 : \($0.sha256)" }.joined(separator: "\n\n") }
                    }.disabled(busy)
                    Button("Convertir le texte en JSON") { perform(as: .json) { try FileTools.json($0) } }.disabled(busy)
                }
            }
            if let error { Section { Text(error).foregroundStyle(.red) } }
            if !result.isEmpty {
                Section("Résultat") {
                    ReportView(text: result, filename: resultType == .json ? "fichiers-sc4r.json" : "fichiers-sc4r.txt", contentType: resultType)
                }
            }
        }.navigationTitle("Fichiers").navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $importing, allowedContentTypes: [.plainText, .commaSeparatedText, .json, .text, .pdf], allowsMultipleSelection: true) { response in
                switch response {
                case .success(let urls): load(urls)
                case .failure(let reason): error = reason.localizedDescription
                }
            }.onDisappear { work?.cancel() }
    }
    private func load(_ urls: [URL]) {
        guard !urls.isEmpty, !busy else { return }
        guard files.count + urls.count <= 5 else { error = "Ajoute au maximum 5 fichiers."; return }
        busy = true; error = nil
        let current = files
        work = Task {
            defer { busy = false }
            do {
                let values = try await Task.detached(priority: .userInitiated) {
                    var loaded: [ImportedText] = []
                    var bytes = current.reduce(0, { $0 + $1.byteCount })
                    var textBytes = current.reduce(0, { $0 + $1.text.utf8.count })
                    for url in urls {
                        let file = try ImportedText.load(url: url)
                        bytes += file.byteCount; textBytes += file.text.utf8.count
                        guard bytes <= 25 * 1024 * 1024, textBytes <= 25 * 1024 * 1024 else {
                            throw AppError.message("Le total des fichiers et du texte extrait doit rester inférieur à 25 Mo.")
                        }
                        loaded.append(file)
                    }
                    return loaded
                }.value
                try Task.checkCancellation()
                let combined = current + values
                guard combined.reduce(0, { $0 + $1.byteCount }) <= 25 * 1024 * 1024,
                      combined.reduce(0, { $0 + $1.text.utf8.count }) <= 25 * 1024 * 1024 else {
                    throw AppError.message("Le total des fichiers doit rester inférieur à 25 Mo.")
                }
                files = combined; result = ""
            } catch { if !Task.isCancelled { self.error = error.localizedDescription } }
        }
    }
    private func perform(as type: UTType = .plainText, _ operation: @escaping @Sendable ([ImportedText]) throws -> String) {
        guard !busy else { return }; busy = true; error = nil
        let values = files
        work = Task {
            defer { busy = false }
            do {
                let text = try await Task.detached(priority: .userInitiated) { try operation(values) }.value
                try Task.checkCancellation(); result = text; resultType = type
                store.record(tool: 5, title: "Fichiers · \(values.count) sources", text: text)
            } catch { if !Task.isCancelled { self.error = error.localizedDescription } }
        }
    }
}

@MainActor
struct DossiersView: View {
    @EnvironmentObject private var store: AppStore
    @State private var creating = false
    var body: some View {
        List {
            Section { Button { creating = true } label: { Label("Créer une fiche", systemImage: "plus.circle") } }
            ForEach(store.state.dossiers) { dossier in
                NavigationLink { DossierDetailView(id: dossier.id) } label: {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(dossier.title).font(.headline)
                        Text(dossier.date, style: .date).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }.onDelete(perform: store.removeDossiers)
            if store.state.dossiers.isEmpty { Text("Tes fiches sont conservées dans l’application.").foregroundStyle(.secondary) }
        }.navigationTitle("Fiches").navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $creating) { NavigationStack { DossierEditor() }.environmentObject(store) }
    }
}

@MainActor
struct DossierDetailView: View {
    @EnvironmentObject private var store: AppStore
    let id: UUID
    @State private var editing = false
    private var dossier: Dossier? { store.state.dossiers.first { $0.id == id } }
    var body: some View {
        if let dossier {
            ScrollView { ReportView(text: dossier.text, filename: "fiche-sc4r.txt").padding(18) }
                .navigationTitle(dossier.title).navigationBarTitleDisplayMode(.inline)
                .toolbar { Button("Modifier") { editing = true } }
                .sheet(isPresented: $editing) {
                    NavigationStack { DossierEditor(dossier: dossier) }.environmentObject(store)
                }
        } else { Text("Cette fiche a été supprimée.") }
    }
}

@MainActor
struct DossierEditor: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var values: [String: String] = [:]
    @State private var id: UUID
    @State private var date: Date
    private let isEditing: Bool
    init(dossier: Dossier? = nil) {
        _title = State(initialValue: dossier?.title ?? "")
        _values = State(initialValue: dossier?.values ?? [:])
        _id = State(initialValue: dossier?.id ?? UUID())
        _date = State(initialValue: dossier?.date ?? Date())
        isEditing = dossier != nil
    }
    private let groups: [(String, [String])] = [
        ("Identité", ["Nom", "Prénom", "Pseudo", "Âge", "Date de naissance", "Profession", "Situation scolaire ou professionnelle", "Autres informations"]),
        ("Contact", ["Téléphone", "Email", "Adresse", "Ville", "Pays"]),
        ("Liens", ["Site web", "Profil public", "YouTube", "Instagram", "Discord", "Twitter", "Facebook", "Autres liens"]),
        ("Père", ["Nom du père", "Prénom du père", "Âge du père", "Résidence du père", "Profession du père", "Informations sur le père"]),
        ("Mère", ["Nom de la mère", "Prénom de la mère", "Âge de la mère", "Résidence de la mère", "Profession de la mère", "Intérêts de la mère", "Informations sur la mère"]),
        ("Appareil", ["Nom du PC", "Marque", "Modèle", "Système", "Adresse IP", "Adresse MAC", "Autres informations sur le PC"])
    ]
    var body: some View {
        Form {
            Section("Ta fiche") { TextField("Titre de la fiche", text: $title) }
            ForEach(groups.indices, id: \.self) { i in
                Section(groups[i].0) {
                    ForEach(groups[i].1, id: \.self) { label in
                        TextField(label, text: Binding(get: { values[label] ?? "" }, set: { values[label] = $0 }))
                    }
                }
            }
            Section("Notes") { TextEditor(text: Binding(get: { values["Notes"] ?? "" }, set: { values["Notes"] = $0 })).frame(minHeight: 140) }
        }.navigationTitle(isEditing ? "Modifier la fiche" : "Nouvelle fiche").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Annuler") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Enregistrer") {
                        let dossier = Dossier(id: id, title: title.trimmingCharacters(in: .whitespacesAndNewlines), date: date, values: values)
                        if store.saveDossier(dossier) { dismiss() }
                    }.disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
    }
}
