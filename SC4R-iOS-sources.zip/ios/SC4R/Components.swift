import SwiftUI
import UniformTypeIdentifiers
import UIKit

enum Brand {
    static let purple = Color(red: 0.43, green: 0.29, blue: 0.92)
    static let cyan = Color(red: 0.21, green: 0.8, blue: 0.88)
    static let gradient = LinearGradient(colors: [purple, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
}

@MainActor
struct BrandMark: View {
    var size: CGFloat = 46
    var body: some View {
        Text("S").font(.system(size: size * 0.58, weight: .bold, design: .rounded))
            .foregroundStyle(.white).frame(width: size, height: size)
            .background(Brand.gradient, in: RoundedRectangle(cornerRadius: size * 0.3))
    }
}

@MainActor
struct AvatarView: View {
    @EnvironmentObject private var store: AppStore
    var size: CGFloat = 46
    var body: some View {
        Group {
            if let data = store.avatarData, let image = UIImage(data: data) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Text(String(store.state.name.prefix(1)).uppercased())
                    .font(.system(size: size * 0.4, weight: .semibold)).foregroundStyle(Brand.purple)
                    .frame(maxWidth: .infinity, maxHeight: .infinity).background(Brand.purple.opacity(0.12))
            }
        }.frame(width: size, height: size).clipShape(Circle())
            .accessibilityLabel("Photo de profil")
    }
}

struct PrimaryAction: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline).frame(maxWidth: .infinity).padding(.vertical, 15)
            .foregroundStyle(.white).background(Brand.purple, in: RoundedRectangle(cornerRadius: 16))
            .opacity(configuration.isPressed ? 0.75 : 1)
    }
}

struct TextExportDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.plainText, .json] }
    var text: String
    init(text: String) { self.text = text }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents, let value = String(data: data, encoding: .utf8) else {
            throw AppError.message("Fichier texte illisible.")
        }
        text = value
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}

@MainActor
struct ExportButton: View {
    var text: String
    var filename: String = "resultats-sc4r.txt"
    var contentType: UTType = .plainText
    @State private var presenting = false
    @State private var error: String?
    var body: some View {
        Button { presenting = true } label: { Label(contentType == .json ? "Exporter JSON" : "Exporter TXT", systemImage: "square.and.arrow.up") }
            .disabled(text.isEmpty)
            .fileExporter(isPresented: $presenting, document: TextExportDocument(text: text), contentType: contentType,
                defaultFilename: filename) { result in
                    if case .failure(let reason) = result { error = reason.localizedDescription }
                }
            .alert("Export", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
    }
}

@MainActor
struct ReportView: View {
    let text: String
    var filename: String = "resultats-sc4r.txt"
    var contentType: UTType = .plainText
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                ExportButton(text: text, filename: filename, contentType: contentType)
                Spacer()
                ShareLink(item: text) { Image(systemName: "square.and.arrow.up") }
                    .accessibilityLabel("Partager le résultat")
            }.font(.subheadline.weight(.semibold))
            Text(String(text.prefix(20_000))).font(.system(.subheadline, design: .monospaced))
                .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
            if text.count > 20_000 {
                Text("Aperçu limité à 20 000 caractères. L’export contient le résultat complet.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.padding(18).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20))
    }
}

@MainActor
struct ToolRow: View {
    let tool: Tool
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: tool.symbol).font(.system(size: 20, weight: .medium))
                .foregroundStyle(Brand.purple).frame(width: 46, height: 46)
                .background(Brand.purple.opacity(0.1), in: RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading, spacing: 5) {
                Text(tool.name).font(.subheadline.weight(.semibold))
                Text(tool.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                Text(tool.available ? (tool.offline ? "Hors ligne" : "Connexion requise") : "Non porté sur iPhone")
                    .font(.caption2.weight(.medium)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 2)
            Text(String(format: "%02d", tool.id)).font(.caption.monospaced()).foregroundStyle(.secondary)
        }.padding(.vertical, 6)
    }
}

@MainActor
final class NetworkRunner: ObservableObject {
    @Published var text = ""
    @Published var busy = false
    @Published var error: String?
    private var task: Task<Void, Never>?
    private var generation = UUID()

    func run(operation: @escaping () async throws -> String, completed: @escaping (String) -> Void) {
        run(operation: operation, render: { $0 }, completed: completed)
    }

    func run<Value>(operation: @escaping () async throws -> Value, render: @escaping (Value) -> String, completed: @escaping (Value) -> Void) {
        cancel()
        let current = UUID(); generation = current; busy = true; error = nil; text = ""
        task = Task {
            defer { if generation == current { busy = false; task = nil } }
            do {
                let value = try await operation()
                guard !Task.isCancelled, generation == current else { return }
                text = render(value); completed(value)
            } catch {
                guard !Task.isCancelled, generation == current else { return }
                self.error = error.localizedDescription
            }
        }
    }
    func cancel() { generation = UUID(); task?.cancel(); task = nil; busy = false }
}
