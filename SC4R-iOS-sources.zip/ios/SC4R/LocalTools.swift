import Foundation
import CryptoKit
import PhoneNumberKit
import PDFKit

enum NumberGenerator {
    static let operators: [String: [String]] = {
        guard let url = Bundle.main.url(forResource: "operators", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let values = try? JSONDecoder().decode([String: [String]].self, from: data) else { return [:] }
        return values
    }()

    static func generate(count: Int, operatorName: String?, operators: [String: [String]] = NumberGenerator.operators) throws -> [GeneratedNumber] {
        guard (1...1000).contains(count) else { throw AppError.message("Choisis une quantité entre 1 et 1 000.") }
        let names = operators.keys.sorted()
        guard !names.isEmpty else { throw AppError.message("La liste des opérateurs est indisponible.") }
        if let name = operatorName, operators[name] == nil { throw AppError.message("Opérateur inconnu.") }
        let selected = operatorName.map { [$0] } ?? names
        guard selected.allSatisfy({ name in
            guard let prefixes = operators[name], !prefixes.isEmpty else { return false }
            return prefixes.allSatisfy { prefix in
                prefix.count == 4 && prefix.unicodeScalars.allSatisfy { (48...57).contains($0.value) }
            }
        }) else { throw AppError.message("Les préfixes d’opérateur sont invalides.") }
        var values: [GeneratedNumber] = []
        var used = Set<String>()
        while values.count < count {
            guard let name = operatorName ?? names.randomElement(),
                  let prefix = operators[name]?.randomElement(),
                  prefix.count == 4 else {
                throw AppError.message("Les préfixes d’opérateur sont invalides.")
            }
            let number = prefix + String(format: "%06d", Int.random(in: 0...999999))
            if used.insert(number).inserted { values.append(.init(number: number, operatorName: name)) }
        }
        return values
    }
}

@MainActor
final class PhoneLookup {
    static let shared = PhoneLookup()
    private let utility = PhoneNumberUtility()
    func lookup(_ raw: String, region: String) throws -> String {
        let number = try utility.parse(raw, withRegion: region.uppercased())
        let countries = utility.countries(withCode: number.countryCode) ?? []
        let countryNames = countries.map { Locale(identifier: "fr_FR").localizedString(forRegionCode: $0) ?? $0 }
        let type: String
        switch number.type {
        case .mobile: type = "Mobile"
        case .fixedLine: type = "Fixe"
        case .fixedOrMobile: type = "Fixe ou mobile"
        default: type = "\(number.type)"
        }
        return [
            "Format : valide selon les métadonnées téléphoniques",
            "International : \(utility.format(number, toType: .international))",
            "National : \(utility.format(number, toType: .national))",
            "E.164 : \(utility.format(number, toType: .e164))",
            "Indicatif : +\(number.countryCode)",
            "Pays correspondant à l’indicatif : \(countryNames.joined(separator: ", "))",
            "Type : \(type)", "",
            "Le format valide ne confirme pas que la ligne est attribuée ou active."
        ].joined(separator: "\n")
    }
}

struct ImportedText: Identifiable, Sendable {
    let id = UUID()
    let name: String
    let text: String
    let sha256: String
    let byteCount: Int
    let lines: [String]

    init(name: String, text: String, sha256: String, byteCount: Int) {
        self.name = name; self.text = text; self.sha256 = sha256; self.byteCount = byteCount
        lines = text.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    static func load(url: URL) throws -> ImportedText {
        let allowed = url.startAccessingSecurityScopedResource()
        defer { if allowed { url.stopAccessingSecurityScopedResource() } }
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        let size = (attributes[.size] as? NSNumber)?.intValue ?? 0
        guard size <= 20 * 1024 * 1024 else { throw AppError.message("Choisis un fichier de moins de 20 Mo.") }
        let data = try Data(contentsOf: url)
        guard data.count <= 20 * 1024 * 1024 else { throw AppError.message("Fichier trop volumineux.") }
        let text: String
        if url.pathExtension.lowercased() == "pdf" {
            guard let document = PDFDocument(data: data), !document.isLocked, document.pageCount <= 500 else {
                throw AppError.message("Choisis un PDF non verrouillé de 500 pages au maximum.")
            }
            var pages: [String] = []; var total = 0
            for index in 0..<document.pageCount {
                let page = document.page(at: index)?.string ?? ""
                total += page.utf8.count
                guard total <= 20 * 1024 * 1024 else { throw AppError.message("Le texte extrait du PDF est trop volumineux.") }
                pages.append(page)
            }
            text = pages.joined(separator: "\n\n")
            guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw AppError.message("Ce PDF ne contient pas de texte lisible. Les documents scannés nécessitent un OCR.")
            }
        } else {
            guard let decoded = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) else {
                throw AppError.message("Le fichier doit être du texte UTF-8, UTF-16 ou un PDF contenant du texte.")
            }
            text = decoded
        }
        return .init(name: url.lastPathComponent, text: text,
                     sha256: SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined(), byteCount: data.count)
    }
}

enum FileTools {
    static func json(_ files: [ImportedText]) throws -> String {
        let values = files.map { ["name": $0.name, "sha256": $0.sha256, "text": $0.text] }
        let data = try JSONSerialization.data(withJSONObject: ["files": values], options: [.prettyPrinted, .sortedKeys])
        return String(decoding: data, as: UTF8.self)
    }

    static func duplicates(_ files: [ImportedText]) -> String {
        var seen = [String: Int]()
        for line in files.flatMap(\.lines) { seen[line, default: 0] += 1 }
        let repeated = seen.filter { $0.value > 1 }.sorted { $0.key < $1.key }
        let summary = ["Fichiers : \(files.count)", "Lignes : \(files.flatMap(\.lines).count)",
                "Lignes distinctes : \(seen.count)", "Lignes répétées : \(repeated.count)", ""] +
            repeated.map { "\($0.value) occurrences — \($0.key)" }
        return summary.joined(separator: "\n")
    }

    static func merge(_ files: [ImportedText], unique: Bool) -> String {
        var seen = Set<String>()
        return files.flatMap(\.lines).filter { !unique || seen.insert($0).inserted }.joined(separator: "\n")
    }

    static func search(_ files: [ImportedText], term: String) throws -> String {
        guard !term.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AppError.message("Saisis un texte à rechercher.") }
        var matches: [String] = []
        for file in files {
            for (i, line) in file.text.components(separatedBy: .newlines).enumerated()
                where line.range(of: term, options: [.caseInsensitive, .diacriticInsensitive]) != nil {
                matches.append("\(file.name):\(i + 1) — \(line)")
            }
        }
        return matches.isEmpty ? "Aucun résultat." : matches.joined(separator: "\n")
    }
}
