#!/bin/bash
# Requires Apple Distribution signing assets. Called only on an ephemeral Mac CI runner.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SC4R_TEAM_ID:?Identifiant d’équipe Apple manquant}"
: "${SC4R_BUNDLE_ID:?Identifiant d’application manquant}"
: "${SC4R_PROFILE_PATH:?Profil de distribution manquant}"
: "${SC4R_PROFILE_NAME:?Nom du profil manquant}"
: "${SC4R_BUILD_NUMBER:?Numéro de build manquant}"
mkdir -p build/signed
sdk="$(xcrun --sdk iphoneos --show-sdk-version)"
python3 - "$sdk" <<'PY'
import sys
if int(sys.argv[1].split('.')[0]) < 26:
    raise SystemExit('Un SDK iOS 26+ est requis pour App Store Connect depuis avril 2026. Sélectionner Xcode 26+ dans ce Mac.')
PY
python3 - <<'PY'
import os, plistlib, re
from pathlib import Path
team = os.environ['SC4R_TEAM_ID']; bundle = os.environ['SC4R_BUNDLE_ID']
if not re.fullmatch(r'[A-Z0-9]{10}', team) or not re.fullmatch(r'[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+', bundle):
    raise SystemExit('Identifiants Apple invalides')
profile = plistlib.loads(Path(os.environ['SC4R_PROFILE_PATH']).read_bytes())
if profile.get('Entitlements', {}).get('application-identifier') != team + '.' + bundle:
    raise SystemExit('Le profil Apple ne correspond pas à cette app et cette équipe')
options = {'method':'app-store-connect','signingStyle':'manual','teamID':team,
           'signingCertificate':'Apple Distribution','provisioningProfiles':{bundle:os.environ['SC4R_PROFILE_NAME']},
           'manageAppVersionAndBuildNumber':False,'uploadSymbols':True,'destination':'export'}
Path('build/ExportOptions.plist').write_bytes(plistlib.dumps(options))
PY
xcodebuild -project SC4R.xcodeproj -scheme SC4R -configuration Release -destination 'generic/platform=iOS' \
  -clonedSourcePackagesDirPath "$PWD/build/Packages" -derivedDataPath "$PWD/build/SignedDerivedData" \
  -archivePath "$PWD/build/SC4R-signed.xcarchive" archive \
  CODE_SIGN_STYLE=Manual CODE_SIGN_IDENTITY='Apple Distribution' DEVELOPMENT_TEAM="$SC4R_TEAM_ID" \
  PROVISIONING_PROFILE_SPECIFIER="$SC4R_PROFILE_NAME" PRODUCT_BUNDLE_IDENTIFIER="$SC4R_BUNDLE_ID" \
  CURRENT_PROJECT_VERSION="$SC4R_BUILD_NUMBER" | tee build/signed-archive.log
xcodebuild -exportArchive -archivePath "$PWD/build/SC4R-signed.xcarchive" \
  -exportOptionsPlist "$PWD/build/ExportOptions.plist" -exportPath "$PWD/build/signed" | tee build/signed-export.log
test -f build/signed/SC4R.ipa
codesign --verify --deep --strict "$PWD/build/SC4R-signed.xcarchive/Products/Applications/SC4R.app"
