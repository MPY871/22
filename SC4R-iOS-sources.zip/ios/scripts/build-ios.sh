#!/bin/bash
# Execute on macOS with Xcode. Never run an unsigned IPA as though it were signed.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo "La compilation iOS nécessite macOS avec Xcode." >&2; exit 1; }
mkdir -p build
xcodebuild -version
shared=(-project SC4R.xcodeproj -scheme SC4R -clonedSourcePackagesDirPath "$PWD/build/Packages")
xcodebuild "${shared[@]}" -resolvePackageDependencies | tee build/dependencies.log
mode="${1:-all}"
if [[ "$mode" == "all" || "$mode" == "tests" ]]; then
  simulator="$(xcrun simctl list devices available -j | python3 scripts/select_simulator.py)"
  xcrun simctl boot "$simulator" 2>/dev/null || true
  xcrun simctl bootstatus "$simulator" -b
  rm -rf build/Tests.xcresult
  xcodebuild "${shared[@]}" test -configuration Debug -destination "platform=iOS Simulator,id=$simulator" \
    -derivedDataPath "$PWD/build/DerivedData" -resultBundlePath "$PWD/build/Tests.xcresult" \
    -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO | tee build/tests.log
fi
if [[ "$mode" == "all" || "$mode" == "archive" ]]; then
  xcodebuild "${shared[@]}" archive -configuration Release -destination 'generic/platform=iOS' \
    -archivePath "$PWD/build/SC4R-unsigned.xcarchive" -derivedDataPath "$PWD/build/DerivedData" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
    CURRENT_PROJECT_VERSION="${SC4R_BUILD_NUMBER:-1}" | tee build/archive.log
  app="$PWD/build/SC4R-unsigned.xcarchive/Products/Applications/SC4R.app"
  test -x "$app/SC4R"
  /usr/bin/file "$app/SC4R"
  xcrun lipo -archs "$app/SC4R"
  rm -rf build/unsigned
  mkdir -p build/unsigned/Payload
  ditto "$app" build/unsigned/Payload/SC4R.app
  ditto -c -k --sequesterRsrc --keepParent build/unsigned/Payload build/SC4R-unsigned.ipa
  printf '%s\n' 'SC4R-unsigned.ipa : application native compilée mais NON SIGNÉE.' \
    'Installation uniquement après signature Apple, par exemple dans AltStore Classic.' \
    'Les tests natifs et captures sont dans Tests.xcresult ; consulte aussi tests.log.' > build/LIRE_AVANT_INSTALLATION.txt
fi
if [[ "$mode" != "all" && "$mode" != "tests" && "$mode" != "archive" ]]; then
  echo 'Mode attendu : all, tests ou archive.' >&2; exit 2
fi
