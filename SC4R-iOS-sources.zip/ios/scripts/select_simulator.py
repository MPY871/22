#!/usr/bin/env python3
"""Select an available iPhone dynamically; do not hardcode a simulator model."""
import json
import re
import sys

data = json.load(sys.stdin)
candidates = []
for runtime, devices in data.get("devices", {}).items():
    if ".iOS-" not in runtime:
        continue
    version = tuple(int(value) for value in re.findall(r"\d+", runtime.rsplit("iOS-", 1)[1]))
    if version[0] < 16:
        continue
    for device in devices:
        if device.get("isAvailable") and device.get("name", "").startswith("iPhone"):
            candidates.append((version, device.get("state") == "Booted", device["name"], device["udid"]))
if not candidates:
    raise SystemExit("Aucun simulateur iPhone iOS 16+ disponible. Installer un runtime iOS dans Xcode.")
print(max(candidates)[-1])
