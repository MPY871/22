#!/usr/bin/env python3
"""Regenerate the small checked-in Xcode project without an external generator."""
from pathlib import Path
import hashlib
import json
import plistlib
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
objects = {}


def uid(label):
    return hashlib.sha256(label.encode()).hexdigest()[:24].upper()


def add(label, isa, **fields):
    key = uid(label)
    objects[key] = {"isa": isa, **fields}
    return key


def file(path, kind):
    return add("file:" + path, "PBXFileReference", lastKnownFileType=kind, path=path, sourceTree="<group>")


def build_file(ref):
    return add("build:" + ref, "PBXBuildFile", fileRef=ref)


sources = {}
groups = {}
for folder in ["SC4R", "SC4RTests", "SC4RUITests"]:
    refs = [file(path.name, "sourcecode.swift") for path in sorted((ROOT / folder).glob("*.swift"))]
    sources[folder] = [build_file(ref) for ref in refs]
    groups[folder] = refs

resource_refs = [file("Assets.xcassets", "folder.assetcatalog"), file("PrivacyInfo.xcprivacy", "text.xml")]
operators = file("operators.json", "text.json")
resource_group = add("group:Resources", "PBXGroup", children=[operators], path="Resources", sourceTree="<group>")
resources = [build_file(ref) for ref in resource_refs + [operators]]
groups["SC4R"] += resource_refs + [resource_group, file("Info.plist", "text.plist.xml")]
for folder in groups:
    groups[folder] = add("group:" + folder, "PBXGroup", children=groups[folder], path=folder, sourceTree="<group>")

package = add("package:PhoneNumberKit", "XCRemoteSwiftPackageReference",
              repositoryURL="https://github.com/PhoneNumberKit/PhoneNumberKit",
              requirement={"kind": "exactVersion", "version": "5.0.11"})
product = add("product:PhoneNumberKit", "XCSwiftPackageProductDependency", package=package, productName="PhoneNumberKit")
package_build = add("build:PhoneNumberKit", "PBXBuildFile", productRef=product)

project_id = uid("project")
target_ids = {name: uid("target:" + name) for name in groups}
products = {}
for name in groups:
    products[name] = add("product:" + name, "PBXFileReference", explicitFileType="wrapper.application" if name == "SC4R" else "wrapper.cfbundle",
                         includeInIndex=0, path=name + (".app" if name == "SC4R" else ".xctest"), sourceTree="BUILT_PRODUCTS_DIR")
product_group = add("group:Products", "PBXGroup", children=list(products.values()), name="Products", sourceTree="<group>")
main_group = add("group:Main", "PBXGroup", children=list(groups.values()) + [product_group], sourceTree="<group>")

base = {
    "CLANG_ENABLE_MODULES": "YES", "CLANG_ENABLE_OBJC_ARC": "YES", "IPHONEOS_DEPLOYMENT_TARGET": "16.0",
    "SDKROOT": "iphoneos", "SWIFT_VERSION": "5.0", "ENABLE_USER_SCRIPT_SANDBOXING": "YES",
    "SWIFT_STRICT_CONCURRENCY": "minimal", "ENABLE_TESTABILITY": "YES",
    "GCC_WARN_64_TO_32_BIT_CONVERSION": "YES", "GCC_WARN_ABOUT_RETURN_TYPE": "YES_ERROR",
}


def config_list(label, settings):
    refs = []
    for name in ["Debug", "Release"]:
        values = dict(settings)
        values.update({"DEBUG_INFORMATION_FORMAT": "dwarf" if name == "Debug" else "dwarf-with-dsym",
                       "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if name == "Debug" else "-O"})
        if name == "Debug":
            values["SWIFT_ACTIVE_COMPILATION_CONDITIONS"] = "$(inherited) DEBUG"
            values["ONLY_ACTIVE_ARCH"] = "YES"
        refs.append(add(label + ":" + name, "XCBuildConfiguration", buildSettings=values, name=name))
    return add(label + ":list", "XCConfigurationList", buildConfigurations=refs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")


project_config = config_list("config:project", base)
for name in groups:
    settings = {
        "PRODUCT_NAME": "$(TARGET_NAME)", "PRODUCT_BUNDLE_IDENTIFIER": "com.sc4r.mobile" + ("" if name == "SC4R" else "." + name.lower()),
        "CODE_SIGN_STYLE": "Automatic", "DEVELOPMENT_TEAM": "", "TARGETED_DEVICE_FAMILY": "1",
        "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator", "SUPPORTS_MACCATALYST": "NO", "SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD": "NO",
        "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
    }
    if name == "SC4R":
        settings.update({"INFOPLIST_FILE": "SC4R/Info.plist", "GENERATE_INFOPLIST_FILE": "NO", "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
                         "CURRENT_PROJECT_VERSION": "1", "MARKETING_VERSION": "1.0", "SWIFT_EMIT_LOC_STRINGS": "YES"})
    else:
        settings.update({"GENERATE_INFOPLIST_FILE": "YES", "TEST_TARGET_NAME": "SC4R"})
        if name == "SC4RTests":
            settings.update({"TEST_HOST": "$(BUILT_PRODUCTS_DIR)/SC4R.app/SC4R", "BUNDLE_LOADER": "$(TEST_HOST)"})
    phases = [add("sources:" + name, "PBXSourcesBuildPhase", buildActionMask=2147483647, files=sources[name], runOnlyForDeploymentPostprocessing=0),
              add("frameworks:" + name, "PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[package_build] if name == "SC4R" else [], runOnlyForDeploymentPostprocessing=0),
              add("resources:" + name, "PBXResourcesBuildPhase", buildActionMask=2147483647, files=resources if name == "SC4R" else [], runOnlyForDeploymentPostprocessing=0)]
    dependencies = []
    if name != "SC4R":
        proxy = add("proxy:" + name, "PBXContainerItemProxy", containerPortal=project_id, proxyType=1,
                    remoteGlobalIDString=target_ids["SC4R"], remoteInfo="SC4R")
        dependencies.append(add("dependency:" + name, "PBXTargetDependency", target=target_ids["SC4R"], targetProxy=proxy))
    add("target:" + name, "PBXNativeTarget", buildConfigurationList=config_list("config:" + name, settings), buildPhases=phases,
        buildRules=[], dependencies=dependencies, name=name, productName=name, productReference=products[name],
        productType="com.apple.product-type.application" if name == "SC4R" else "com.apple.product-type.bundle.unit-test" if name == "SC4RTests" else "com.apple.product-type.bundle.ui-testing",
        packageProductDependencies=[product] if name == "SC4R" else [])

add("project", "PBXProject", attributes={"BuildIndependentTargetsInParallel": "YES", "LastUpgradeCheck": "1600",
    "TargetAttributes": {target_ids[name]: {"CreatedOnToolsVersion": "16.0", **({"TestTargetID": target_ids["SC4R"]} if name != "SC4R" else {})} for name in groups}},
    buildConfigurationList=project_config, compatibilityVersion="Xcode 14.0", developmentRegion="fr", hasScannedForEncodings=0,
    knownRegions=["fr", "en", "Base"], mainGroup=main_group, productRefGroup=product_group, projectDirPath="", projectRoot="",
    packageReferences=[package], targets=list(target_ids.values()))


def render(value, depth=0):
    if isinstance(value, dict):
        return "{\n" + "\n".join("\t" * (depth + 1) + render(str(k)) + " = " + render(v, depth + 1) + ";" for k, v in value.items()) + "\n" + "\t" * depth + "}"
    if isinstance(value, list):
        return "(\n" + "\n".join("\t" * (depth + 1) + render(v, depth + 1) + "," for v in value) + "\n" + "\t" * depth + ")"
    if isinstance(value, int): return str(value)
    if len(str(value)) == 24 and str(value) in objects: return str(value)
    return json.dumps(str(value), ensure_ascii=False)


project = ROOT / "SC4R.xcodeproj"
project.mkdir(exist_ok=True)
(project / "project.pbxproj").write_text("// !$*UTF8*$!\n" + render({"archiveVersion": 1, "classes": {}, "objectVersion": 56, "objects": objects, "rootObject": project_id}) + "\n")
workspace = project / "project.xcworkspace"
workspace.mkdir(exist_ok=True)
(workspace / "contents.xcworkspacedata").write_text('<?xml version="1.0" encoding="UTF-8"?><Workspace version="1.0"><FileRef location="self:"></FileRef></Workspace>\n')

scheme = ET.Element("Scheme", LastUpgradeVersion="1600", version="1.3")


def build_ref(parent, name):
    ET.SubElement(parent, "BuildableReference", BuildableIdentifier="primary", BlueprintIdentifier=target_ids[name],
                  BuildableName=name + (".app" if name == "SC4R" else ".xctest"), BlueprintName=name, ReferencedContainer="container:SC4R.xcodeproj")


action = ET.SubElement(scheme, "BuildAction", parallelizeBuildables="YES", buildImplicitDependencies="YES")
entries = ET.SubElement(action, "BuildActionEntries")
for name in groups:
    entry = ET.SubElement(entries, "BuildActionEntry", buildForTesting="YES", buildForRunning="YES" if name == "SC4R" else "NO",
                          buildForProfiling="YES" if name == "SC4R" else "NO", buildForArchiving="YES" if name == "SC4R" else "NO", buildForAnalyzing="YES")
    build_ref(entry, name)
action = ET.SubElement(scheme, "TestAction", buildConfiguration="Debug", selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB",
                       selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB", shouldUseLaunchSchemeArgsEnv="YES")
testables = ET.SubElement(action, "Testables")
for name in ["SC4RTests", "SC4RUITests"]: build_ref(ET.SubElement(testables, "TestableReference", skipped="NO"), name)
action = ET.SubElement(scheme, "LaunchAction", buildConfiguration="Debug", selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB",
                       selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB", launchStyle="0", useCustomWorkingDirectory="NO",
                       ignoresPersistentStateOnLaunch="NO", debugDocumentVersioning="YES", debugServiceExtension="internal", allowLocationSimulation="YES")
build_ref(ET.SubElement(action, "BuildableProductRunnable", runnableDebuggingMode="0"), "SC4R")
action = ET.SubElement(scheme, "ProfileAction", buildConfiguration="Release", shouldUseLaunchSchemeArgsEnv="YES", savedToolIdentifier="", useCustomWorkingDirectory="NO", debugDocumentVersioning="YES")
build_ref(ET.SubElement(action, "BuildableProductRunnable", runnableDebuggingMode="0"), "SC4R")
ET.SubElement(scheme, "AnalyzeAction", buildConfiguration="Debug")
ET.SubElement(scheme, "ArchiveAction", buildConfiguration="Release", revealArchiveInOrganizer="YES")
schemes = project / "xcshareddata/xcschemes"
schemes.mkdir(parents=True, exist_ok=True)
ET.indent(scheme)
ET.ElementTree(scheme).write(schemes / "SC4R.xcscheme", encoding="utf-8", xml_declaration=True)
print("Xcode project and shared SC4R scheme generated")
