# SC4R pour iPhone

Projet SwiftUI autonome, iPhone sous iOS 16+, avec une interface française, quatre onglets natifs, navigation tactile, apparence claire/sombre, import Photos/Fichiers et partage iOS. Le code ne charge pas le site Flask dans une vue web. Il n’appelle aucun serveur du PC.

**État de livraison : sources préparées, compilation iOS et tests XCTest non exécutés. Aucune IPA signée n’est fournie à ce stade.** Les vérifications locales de structure et de syntaxe ne remplacent pas une compilation Xcode ni un essai sur un iPhone. Voir `VALIDATION.md`.

## Commencer depuis Windows

Lire [INSTALLER_DEPUIS_WINDOWS.md](INSTALLER_DEPUIS_WINDOWS.md). Les workflows `.github/workflows/ios-build.yml` et `ios-testflight.yml` compilent sur un Mac distant. Ils sont déclenchés manuellement. Aucun dépôt n’a été créé et aucun workflow distant n’a été lancé pendant la préparation du projet.

## Fonctions natives

Huit outils ont une implémentation iOS ; trois nécessitent toujours l’environnement Python/Windows et sont signalés comme non portés dans l’app. La correspondance détaillée et les différences sont dans [FONCTIONS.md](FONCTIONS.md). L’assistant IA, les comptes/licences et l’administration du projet bureau restent dans le code Python de référence.

- Le générateur attend la quantité, puis un choix d’opérateur, avant de produire les résultats. Retour et nouvelle génération sont explicites.
- La photo est normalisée en JPEG, enregistrée atomiquement et relue depuis Application Support au lancement. L’import continue en changeant d’onglet. La suppression invalide les imports en cours.
- Le profil, les 60 dernières entrées du journal et les fiches sont stockés localement. L’historique conserve au maximum 50 000 caractères par résultat ; l’export depuis l’outil garde le résultat complet.
- Les fichiers sont traités hors de l’interface principale. Les PDF doivent contenir du texte ; aucun OCR n’est inclus.
- Les recherches réseau ont un délai limité, une annulation et une protection contre l’affichage de résultats d’une ancienne demande.

Les données locales restent dans le conteneur de l’app. Une mise à jour conservant l’identifiant d’application garde normalement les données ; supprimer l’app supprime son stockage local. Il n’y a pas de synchronisation des profils ou des comptes avec le projet bureau. Internet reste nécessaire pour IP, email, pseudo et les services externes ; TCP peut utiliser le réseau local.

## Compiler sur un Mac

Avec Xcode 26+ et un runtime de simulateur iPhone installé :

```bash
bash scripts/build-ios.sh all
```

Cette commande résout PhoneNumberKit, exécute les tests de modèle, de persistance et d’interface, puis archive pour un iPhone physique sans signature. Elle produit `build/SC4R-unsigned.ipa` **uniquement après compilation**. Cette IPA doit être signée avant installation. Les captures de l’interface produites par les tests sont dans `build/Tests.xcresult`.

Pour un essai local dans Xcode, ouvrir `SC4R.xcodeproj`, sélectionner le schéma `SC4R` et un simulateur iPhone. Pour un iPhone physique, choisir une équipe Apple et un identifiant d’application unique dans Signing & Capabilities. Pour TestFlight, utiliser la procédure dédiée et ses éléments de distribution.

## Organisation

| Chemin | Rôle |
| --- | --- |
| `SC4R/*.swift` | Application, interface, services locaux/réseau et stockage |
| `SC4R/Resources/operators.json` | Huit opérateurs et préfixes repris du jeu de secours du code original |
| `SC4RTests/` | Tests de parcours, stockage, annulation et validations |
| `SC4RUITests/` | Tests d’interface quantité → opérateur → résultats |
| `SC4R.xcodeproj/` | Projet Xcode et schéma partagé |
| `scripts/` | Compilation, signature et génération du projet |
| `.github/workflows/` | Compilation Mac distante depuis Windows |
| `Licenses/` | Licence de PhoneNumberKit |

PhoneNumberKit est fixé à **5.0.11**, avec sa révision dans `Package.resolved`. Il fournit ses métadonnées hors ligne au téléphone. Les ressources de l’app sont incluses dans la cible Xcode. `scripts/generate_project.py` permet de régénérer le projet si des fichiers Swift sont ajoutés ; la compilation normale ne nécessite pas de lancer ce script.

## Références de compilation

- [Runners macOS de GitHub](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
- [Signature Xcode dans GitHub Actions](https://docs.github.com/en/actions/how-tos/deploy/deploy-to-third-party-platforms/sign-xcode-applications)
- [Exigences SDK d’Apple depuis avril 2026](https://developer.apple.com/news/upcoming-requirements/?id=04282026a)
- [TestFlight](https://developer.apple.com/testflight/)
- [PhoneNumberKit](https://github.com/PhoneNumberKit/PhoneNumberKit)
