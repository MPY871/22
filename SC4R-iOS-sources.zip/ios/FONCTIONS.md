# Correspondance avec le projet Python

L’app iPhone fonctionne sans exécuter le code Python et sans contacter un PC. Les implémentations sont adaptées aux API iOS. Le projet Python corrigé est conservé séparément dans l’archive de livraison.

| N° | Outil original | Version native | Connexion et différences |
| --- | --- | --- | --- |
| 1 | Générateur de numéros | Quantité de 1 à 1 000, opérateur ou mixte, nombres uniques, export TXT, partage et journal | Hors ligne. Utilise les huit opérateurs et les préfixes du jeu de secours original ; pas de téléchargement ARCEP. Un numéro généré ne confirme ni une ligne active ni l’opérateur actuel après portabilité. |
| 2 | Informations numéro | Validation des métadonnées, formats E.164/national/international, indicatif, pays et type | Hors ligne via PhoneNumberKit. Pas d’identification du titulaire, de statut de ligne, de géolocalisation précise, de géocodeur ou de fournisseur actuel. |
| 3 | Création de dossier | Champs d’identité, contact, liens, famille, appareil et notes ; création, modification, suppression et export | Hors ligne. Saisie locale des champs ; aucune collecte automatique. Export texte simple. |
| 4 | Informations IP | IPv4/IPv6, IP publique de la connexion, pays, région, ville, réseau, ASN et fuseau | Internet via ipwho.is, sans reprendre la clé du projet bureau. Localisation approximative. Disponibilité dépendante du service. |
| 5 | Vérificateur de fichiers | Doublons, recherche avec numéros de lignes, fusion avec/sans doublons, SHA-256 et export JSON | Hors ligne. Import texte UTF-8/UTF-16, CSV, JSON ou PDF textuel ; 5 fichiers, 20 Mo chacun, 25 Mo au total pour fichiers et texte extrait. PDF non verrouillés de 500 pages maximum. Pas d’OCR. |
| 6 | Ports TCP | Listes/plages de ports, état de connexion, export et journal | Depuis la connexion de l’iPhone ; 256 ports maximum, 12 connexions simultanées et délai de 2 s par port. Accès réseau local autorisé par iOS si nécessaire. Pas d’UDP ni d’identification de service. |
| 7 | Obfuscateur Python | Non porté | Le module de bytecode Python est conservé dans l’archive de référence. |
| 8 | Recherche de pseudo | Vérification de huit pages publiques et liens vers les sites | Internet. GitHub utilise son API publique ; les autres sites peuvent bloquer la vérification ou répondre avec une page générique. Ces résultats sont marqués comme à vérifier, sans inventer une confirmation. |
| 9 | Informations email | Contrôle de format simple et interrogation DNS MX du domaine | Internet via DNS-over-HTTPS Cloudflare ; seul le domaine est envoyé. Domaines ASCII, y compris punycode. Pas de vérification SMTP ni de confirmation de boîte active. |
| 10 | Analyse Windows | Non porté | Les API et commandes Windows ne s’exécutent pas sur iOS. |
| 11 | Décompileur | Non porté | La chaîne de décompilation du projet Python reste dans le projet bureau. |

Le profil natif est local : nom, photo et thème. Il ne remplace pas le système de compte, licence et administration du projet bureau. L’assistant IA du projet bureau n’est pas porté dans cette version. Aucune clé personnelle n’est incluse dans les sources iOS.

Le journal garde 60 résultats avec un aperçu borné à 50 000 caractères chacun. Pour un résultat volumineux, exporter immédiatement depuis l’outil avant de quitter son écran. Les fichiers importés et les résultats temporaires restent en mémoire pour cet écran ; seuls le journal, le profil et les fiches sont persistants.
