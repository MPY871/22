import XCTest

final class GeneratorFlowTests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }

    @MainActor
    func testQuantityDoesNotSkipOperatorMenu() throws {
        let app = XCUIApplication(); app.launch()
        let open = app.buttons["generator.open"]
        XCTAssertTrue(open.waitForExistence(timeout: 10)); open.tap()
        let field = app.textFields["generator.quantity"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        app.buttons["10"].tap()
        app.buttons["generator.next"].tap()
        XCTAssertTrue(app.staticTexts["generator.operator.title"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.staticTexts["generator.results.title"].exists)
        screenshot(app, "Choix de l’opérateur")
        app.buttons["generator.operator.Orange"].tap()
        let result = app.staticTexts["generator.results.title"]
        XCTAssertTrue(result.waitForExistence(timeout: 3))
        XCTAssertEqual(result.label, "10 numéros générés")
        screenshot(app, "Résultats")
        app.buttons["generator.reset"].tap()
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        XCTAssertFalse(result.exists)
    }

    @MainActor
    func testOperatorBackButtonReturnsToQuantity() {
        let app = XCUIApplication(); app.launch()
        app.buttons["generator.open"].tap()
        app.buttons["20"].tap()
        app.buttons["generator.next"].tap()
        XCTAssertTrue(app.staticTexts["generator.operator.title"].waitForExistence(timeout: 3))
        let back = app.buttons["generator.back"]
        for _ in 0..<4 { if back.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(back.waitForExistence(timeout: 3)); back.tap()
        XCTAssertTrue(app.textFields["generator.quantity"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.staticTexts["generator.results.title"].exists)
    }

    @MainActor
    private func screenshot(_ app: XCUIApplication, _ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
}
